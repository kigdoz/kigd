 const net = require("net");
 const http2 = require("http2");
 const tls = require("tls");
 const cluster = require("cluster");
 const url = require("url");
 const crypto = require("crypto");
 const fs = require("fs");
 const gradient = require ("gradient-string");
 
 process.setMaxListeners(0);
 require("events").EventEmitter.defaultMaxListeners = 0;

 if (process.argv.length < 5){console.log(gradient.vice(`[!] node TLS.js <HOST> <TIME> <RPS> <THREADS>.`));; process.exit();}
 
 const defaultCiphers = crypto.constants.defaultCoreCipherList.split(":");
 const ciphers = "GREASE:" + [
     defaultCiphers[2],
     defaultCiphers[1],
     defaultCiphers[0],
     ...defaultCiphers.slice(3)
 ].join(":");
 
 
 MODAL DEK 🤣
 MODAL DEK 🤣
 MODAL DEK 🤣 
 MODAL DEK 🤣
 MODAL DEK 🤣
 MODAL DEK 🤣 
 MODAL DEK 🤣
 MODAL DEK 🤣
 MODAL DEK 🤣 
 MODAL DEK 🤣
 MODAL DEK 🤣
 MODAL DEK 🤣 
 MODAL DEK 🤣
 MODAL DEK 🤣
 MODAL DEK 🤣 
 MODAL DEK 🤣
 MODAL DEK 🤣
 MODAL DEK 🤣
 INI BUKAB METHODS FENG 
INI METHODS TLS NORMAL YG
GW POTONG
 
 MODAL DEK 🤣
 MODAL DEK 🤣
 MODAL DEK 🤣 
 MODAL DEK 🤣
 MODAL DEK 🤣
 MODAL DEK 🤣 
 MODAL DEK 🤣
 MODAL DEK 🤣
 MODAL DEK 🤣 
 MODAL DEK 🤣
 MODAL DEK 🤣
 MODAL DEK 🤣 
 MODAL DEK 🤣
 MODAL DEK 🤣
 MODAL DEK 🤣 
 MODAL DEK 🤣
 MODAL DEK 🤣
 MODAL DEK 🤣 
 MODAL DEK 🤣
 MODAL DEK 🤣
 MODAL DEK 🤣 
 MODAL DEK 🤣
 MODAL DEK 🤣
 MODAL DEK 🤣 
 MODAL DEK 🤣
 MODAL DEK 🤣
 MODAL DEK 🤣 
 MODAL DEK 🤣
 MODAL DEK 🤣
 MODAL DEK 🤣 
 MODAL DEK 🤣
 MODAL DEK 🤣
 MODAL DEK 🤣 
 MODAL DEK 🤣
 MODAL DEK 🤣
 MODAL DEK 🤣 
 MODAL DEK 🤣
 MODAL DEK 🤣
 MODAL DEK 🤣 
 MODAL DEK 🤣
 MODAL DEK 🤣
 MODAL DEK 🤣 
 MODAL DEK 🤣
 MODAL DEK 🤣
 MODAL DEK 🤣 
 MODAL DEK 🤣
 MODAL DEK 🤣
 MODAL DEK 🤣 
 MODAL DEK 🤣
 MODAL DEK 🤣
 MODAL DEK 🤣 
 MODAL DEK 🤣
 MODAL DEK 🤣
 MODAL DEK 🤣 
 MODAL DEK 🤣
 MODAL DEK 🤣
 MODAL DEK 🤣 
 MODAL DEK 🤣
 MODAL DEK 🤣
 MODAL DEK 🤣 
 MODAL DEK 🤣
 MODAL DEK 🤣
 MODAL DEK 🤣 
 MODAL DEK 🤣
 MODAL DEK 🤣
 MODAL DEK 🤣 
 MODAL DEK 🤣
 MODAL DEK 🤣
 MODAL DEK 🤣 
 MODAL DEK 🤣
 MODAL DEK 🤣
 MODAL DEK 🤣 
 MODAL DEK 🤣
 MODAL DEK 🤣
 MODAL DEK 🤣 
 MODAL DEK 🤣
 MODAL DEK 🤣
 MODAL DEK 🤣 
 MODAL DEK 🤣
 MODAL DEK 🤣
 MODAL DEK 🤣 
 MODAL DEK 🤣
 MODAL DEK 🤣
 MODAL DEK 🤣 
 MODAL DEK 🤣
 MODAL DEK 🤣
 MODAL DEK 🤣 
 MODAL DEK 🤣
 MODAL DEK 🤣
 MODAL DEK 🤣 
 MODAL DEK 🤣
 MODAL DEK 🤣
 MODAL DEK 🤣 
 MODAL DEK 🤣
 MODAL DEK 🤣
 MODAL DEK 🤣 
 MODAL DEK 🤣
 MODAL DEK 🤣
 MODAL DEK 🤣 
 MODAL DEK 🤣
 MODAL DEK 🤣
 MODAL DEK 🤣 
 MODAL DEK 🤣
 MODAL DEK 🤣
 MODAL DEK 🤣 
 MODAL DEK 🤣
 MODAL DEK 🤣
 MODAL DEK 🤣