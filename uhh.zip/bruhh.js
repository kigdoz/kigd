const axios = require('axios');
const readline = require('readline');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

function checkWebsiteStatus(url) {
  axios.get(url)
    .then(function (response) {
      if (response.status === 200) {
        console.log('Website is up (200 OK)');
      } else {
        console.log('Website is down (status code: ' + response.status + ')');
      }
    })
    .catch(function (error) {
      console.error('Error:', error.message);
    });
}

function startContinuousCheck(url, interval) {
  setInterval(function() {
    checkWebsiteStatus(url);
  }, interval);
}

rl.question('Enter website URL: ', function (url) {
  rl.question('Enter check interval (in milliseconds): ', function (interval) {
    startContinuousCheck(url, interval);
    rl.close();
  });
});
