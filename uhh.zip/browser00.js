if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
if (process.argv.length < 7) {
    console.log("node browser.js [url] [number of proxies] [threads] [cloudflare waiting time] [delay between concurrent] [number of cookies]");
    process.exit(0);
}
