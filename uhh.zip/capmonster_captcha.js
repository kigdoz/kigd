const request = require('request');
const querystring = require('querystring');

const API_KEY = 'YOUR_CAPMONSTER_API_KEY';
const CLIENT_KEY = 'YOUR_CAPMONSTER_CLIENT_KEY';
const WEBSITE_URL = 'URL_OF_THE_WEBSITE';
const CAPTCHA_ID = 'CAPTCHA_ID';
const CAPTCHA_FILE = 'CAPTCHA_FILE_PATH';

const uploadCaptcha = () => {
  const formData = {
    key: API_KEY,
    method: 'post',
    body: {
      clientKey: CLIENT_KEY,
      task: {
        type: 'ImageToTextTask',
        body: Buffer.from(CAPTCHA_FILE).toString('base64'),
        phrase: true,
        case: true,
        numeric: 1,
        math: false,
        minLength: 0,
        maxLength: 0
      }
    }
  };
  const url = 'https://api.capmonster.cloud/createTask';
  return new Promise((resolve, reject) => {
    request.post({ url, formData }, (err, resp, body) => {
      if (err) {
        reject(err);
      } else {
        const response = JSON.parse(body);
        if (response.errorId !== 0) {
          reject(response.errorDescription);
        } else {
          resolve(response.taskId);
        }
      }
    });
  });
};

const getResult = (taskId) => {
  const formData = {
    key: API_KEY,
    method: 'get',
    taskId,
    json: true
  };
  const url = 'https://api.capmonster.cloud/getTaskResult?' + querystring.stringify(formData);
  return new Promise((resolve, reject) => {
    request.get(url, (err, resp, body) => {
      if (err) {
        reject(err);
      } else {
        const response = JSON.parse(body);
        if (response.errorId !== 0) {
          reject(response.errorDescription);
        } else {
          resolve(response.solution.text);
        }
      }
    });
  });
};

(async () => {
  try {
    const taskId = await uploadCaptcha();
    console.log(`Captcha task ${taskId} uploaded to CapMonster.`);
    const result = await getResult(taskId);
    console.log(`Captcha solved: ${result}`);
  } catch (error) {
    console.error(error);
  }
})();